define(["exports"], (function(exports) {
	"use strict";
	// @ts-ignore
	try {
		self["workbox:core:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Claim any currently available clients once the service worker
	* becomes active. This is normally used in conjunction with `skipWaiting()`.
	*
	* @memberof workbox-core
	*/
	function clientsClaim() {
		self.addEventListener("activate", () => self.clients.claim());
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const logger = (() => {
		// Don't overwrite this value if it's already set.
		// See https://github.com/GoogleChrome/workbox/pull/2284#issuecomment-560470923
		if (!("__WB_DISABLE_DEV_LOGS" in globalThis)) {
			self.__WB_DISABLE_DEV_LOGS = false;
		}
		let inGroup = false;
		const methodToColorMap = {
			debug: `#7f8c8d`,
			log: `#2ecc71`,
			warn: `#f39c12`,
			error: `#c0392b`,
			groupCollapsed: `#3498db`,
			groupEnd: null
		};
		const print = function(method, args) {
			if (self.__WB_DISABLE_DEV_LOGS) {
				return;
			}
			if (method === "groupCollapsed") {
				// Safari doesn't print all console.groupCollapsed() arguments:
				// https://bugs.webkit.org/show_bug.cgi?id=182754
				if (/^((?!chrome|android).)*safari/i.test(navigator.userAgent)) {
					console[method](...args);
					return;
				}
			}
			const styles = [
				`background: ${methodToColorMap[method]}`,
				`border-radius: 0.5em`,
				`color: white`,
				`font-weight: bold`,
				`padding: 2px 0.5em`
			];
			// When in a group, the workbox prefix is not displayed.
			const logPrefix = inGroup ? [] : ["%cworkbox", styles.join(";")];
			console[method](...logPrefix, ...args);
			if (method === "groupCollapsed") {
				inGroup = true;
			}
			if (method === "groupEnd") {
				inGroup = false;
			}
		};
		// eslint-disable-next-line @typescript-eslint/ban-types
		const api = {};
		const loggerMethods = Object.keys(methodToColorMap);
		for (const key of loggerMethods) {
			const method = key;
			api[method] = (...args) => {
				print(method, args);
			};
		}
		return api;
	})();
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const messages = {
		"invalid-value": ({ paramName, validValueDescription, value }) => {
			if (!paramName || !validValueDescription) {
				throw new Error(`Unexpected input to 'invalid-value' error.`);
			}
			return `The '${paramName}' parameter was given a value with an ` + `unexpected value. ${validValueDescription} Received a value of ` + `${JSON.stringify(value)}.`;
		},
		"not-an-array": ({ moduleName, className, funcName, paramName }) => {
			if (!moduleName || !className || !funcName || !paramName) {
				throw new Error(`Unexpected input to 'not-an-array' error.`);
			}
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${className}.${funcName}()' must be an array.`;
		},
		"incorrect-type": ({ expectedType, paramName, moduleName, className, funcName }) => {
			if (!expectedType || !paramName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'incorrect-type' error.`);
			}
			const classNameStr = className ? `${className}.` : "";
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${classNameStr}` + `${funcName}()' must be of type ${expectedType}.`;
		},
		"incorrect-class": ({ expectedClassName, paramName, moduleName, className, funcName, isReturnValueProblem }) => {
			if (!expectedClassName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'incorrect-class' error.`);
			}
			const classNameStr = className ? `${className}.` : "";
			if (isReturnValueProblem) {
				return `The return value from ` + `'${moduleName}.${classNameStr}${funcName}()' ` + `must be an instance of class ${expectedClassName}.`;
			}
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${classNameStr}${funcName}()' ` + `must be an instance of class ${expectedClassName}.`;
		},
		"missing-a-method": ({ expectedMethod, paramName, moduleName, className, funcName }) => {
			if (!expectedMethod || !paramName || !moduleName || !className || !funcName) {
				throw new Error(`Unexpected input to 'missing-a-method' error.`);
			}
			return `${moduleName}.${className}.${funcName}() expected the ` + `'${paramName}' parameter to expose a '${expectedMethod}' method.`;
		},
		"add-to-cache-list-unexpected-type": ({ entry }) => {
			return `An unexpected entry was passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' The entry ` + `'${JSON.stringify(entry)}' isn't supported. You must supply an array of ` + `strings with one or more characters, objects with a url property or ` + `Request objects.`;
		},
		"add-to-cache-list-conflicting-entries": ({ firstEntry, secondEntry }) => {
			if (!firstEntry || !secondEntry) {
				throw new Error(`Unexpected input to ` + `'add-to-cache-list-duplicate-entries' error.`);
			}
			return `Two of the entries passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' had the URL ` + `${firstEntry} but different revision details. Workbox is ` + `unable to cache and version the asset correctly. Please remove one ` + `of the entries.`;
		},
		"plugin-error-request-will-fetch": ({ thrownErrorMessage }) => {
			if (!thrownErrorMessage) {
				throw new Error(`Unexpected input to ` + `'plugin-error-request-will-fetch', error.`);
			}
			return `An error was thrown by a plugins 'requestWillFetch()' method. ` + `The thrown error message was: '${thrownErrorMessage}'.`;
		},
		"invalid-cache-name": ({ cacheNameId, value }) => {
			if (!cacheNameId) {
				throw new Error(`Expected a 'cacheNameId' for error 'invalid-cache-name'`);
			}
			return `You must provide a name containing at least one character for ` + `setCacheDetails({${cacheNameId}: '...'}). Received a value of ` + `'${JSON.stringify(value)}'`;
		},
		"unregister-route-but-not-found-with-method": ({ method }) => {
			if (!method) {
				throw new Error(`Unexpected input to ` + `'unregister-route-but-not-found-with-method' error.`);
			}
			return `The route you're trying to unregister was not  previously ` + `registered for the method type '${method}'.`;
		},
		"unregister-route-route-not-registered": () => {
			return `The route you're trying to unregister was not previously ` + `registered.`;
		},
		"queue-replay-failed": ({ name }) => {
			return `Replaying the background sync queue '${name}' failed.`;
		},
		"duplicate-queue-name": ({ name }) => {
			return `The Queue name '${name}' is already being used. ` + `All instances of backgroundSync.Queue must be given unique names.`;
		},
		"expired-test-without-max-age": ({ methodName, paramName }) => {
			return `The '${methodName}()' method can only be used when the ` + `'${paramName}' is used in the constructor.`;
		},
		"unsupported-route-type": ({ moduleName, className, funcName, paramName }) => {
			return `The supplied '${paramName}' parameter was an unsupported type. ` + `Please check the docs for ${moduleName}.${className}.${funcName} for ` + `valid input types.`;
		},
		"not-array-of-class": ({ value, expectedClass, moduleName, className, funcName, paramName }) => {
			return `The supplied '${paramName}' parameter must be an array of ` + `'${expectedClass}' objects. Received '${JSON.stringify(value)},'. ` + `Please check the call to ${moduleName}.${className}.${funcName}() ` + `to fix the issue.`;
		},
		"max-entries-or-age-required": ({ moduleName, className, funcName }) => {
			return `You must define either config.maxEntries or config.maxAgeSeconds` + `in ${moduleName}.${className}.${funcName}`;
		},
		"statuses-or-headers-required": ({ moduleName, className, funcName }) => {
			return `You must define either config.statuses or config.headers` + `in ${moduleName}.${className}.${funcName}`;
		},
		"invalid-string": ({ moduleName, funcName, paramName }) => {
			if (!paramName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'invalid-string' error.`);
			}
			return `When using strings, the '${paramName}' parameter must start with ` + `'http' (for cross-origin matches) or '/' (for same-origin matches). ` + `Please see the docs for ${moduleName}.${funcName}() for ` + `more info.`;
		},
		"channel-name-required": () => {
			return `You must provide a channelName to construct a ` + `BroadcastCacheUpdate instance.`;
		},
		"invalid-responses-are-same-args": () => {
			return `The arguments passed into responsesAreSame() appear to be ` + `invalid. Please ensure valid Responses are used.`;
		},
		"expire-custom-caches-only": () => {
			return `You must provide a 'cacheName' property when using the ` + `expiration plugin with a runtime caching strategy.`;
		},
		"unit-must-be-bytes": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'unit-must-be-bytes' error.`);
			}
			return `The 'unit' portion of the Range header must be set to 'bytes'. ` + `The Range header provided was "${normalizedRangeHeader}"`;
		},
		"single-range-only": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'single-range-only' error.`);
			}
			return `Multiple ranges are not supported. Please use a  single start ` + `value, and optional end value. The Range header provided was ` + `"${normalizedRangeHeader}"`;
		},
		"invalid-range-values": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'invalid-range-values' error.`);
			}
			return `The Range header is missing both start and end values. At least ` + `one of those values is needed. The Range header provided was ` + `"${normalizedRangeHeader}"`;
		},
		"no-range-header": () => {
			return `No Range header was found in the Request provided.`;
		},
		"range-not-satisfiable": ({ size, start, end }) => {
			return `The start (${start}) and end (${end}) values in the Range are ` + `not satisfiable by the cached response, which is ${size} bytes.`;
		},
		"attempt-to-cache-non-get-request": ({ url, method }) => {
			return `Unable to cache '${url}' because it is a '${method}' request and ` + `only 'GET' requests can be cached.`;
		},
		"cache-put-with-no-response": ({ url }) => {
			return `There was an attempt to cache '${url}' but the response was not ` + `defined.`;
		},
		"no-response": ({ url, error }) => {
			let message = `The strategy could not generate a response for '${url}'.`;
			if (error) {
				message += ` The underlying error is ${error}.`;
			}
			return message;
		},
		"bad-precaching-response": ({ url, status }) => {
			return `The precaching request for '${url}' failed` + (status ? ` with an HTTP status of ${status}.` : `.`);
		},
		"non-precached-url": ({ url }) => {
			return `createHandlerBoundToURL('${url}') was called, but that URL is ` + `not precached. Please pass in a URL that is precached instead.`;
		},
		"add-to-cache-list-conflicting-integrities": ({ url }) => {
			return `Two of the entries passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' had the URL ` + `${url} with different integrity values. Please remove one of them.`;
		},
		"missing-precache-entry": ({ cacheName, url }) => {
			return `Unable to find a precached response in ${cacheName} for ${url}.`;
		},
		"cross-origin-copy-response": ({ origin }) => {
			return `workbox-core.copyResponse() can only be used with same-origin ` + `responses. It was passed a response with origin ${origin}.`;
		},
		"opaque-streams-source": ({ type }) => {
			const message = `One of the workbox-streams sources resulted in an ` + `'${type}' response.`;
			if (type === "opaqueredirect") {
				return `${message} Please do not use a navigation request that results ` + `in a redirect as a source.`;
			}
			return `${message} Please ensure your sources are CORS-enabled.`;
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const generatorFunction = (code, details = {}) => {
		const message = messages[code];
		if (!message) {
			throw new Error(`Unable to find message for code '${code}'.`);
		}
		return message(details);
	};
	const messageGenerator = generatorFunction;
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Workbox errors should be thrown with this class.
	* This allows use to ensure the type easily in tests,
	* helps developers identify errors from workbox
	* easily and allows use to optimise error
	* messages correctly.
	*
	* @private
	*/
	class WorkboxError extends Error {
		/**
		*
		* @param {string} errorCode The error code that
		* identifies this particular error.
		* @param {Object=} details Any relevant arguments
		* that will help developers identify issues should
		* be added as a key on the context object.
		*/
		constructor(errorCode, details) {
			const message = messageGenerator(errorCode, details);
			super(message);
			this.name = errorCode;
			this.details = details;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/*
	* This method throws if the supplied value is not an array.
	* The destructed values are required to produce a meaningful error for users.
	* The destructed and restructured object is so it's clear what is
	* needed.
	*/
	const isArray = (value, details) => {
		if (!Array.isArray(value)) {
			throw new WorkboxError("not-an-array", details);
		}
	};
	const hasMethod = (object, expectedMethod, details) => {
		const type = typeof object[expectedMethod];
		if (type !== "function") {
			details["expectedMethod"] = expectedMethod;
			throw new WorkboxError("missing-a-method", details);
		}
	};
	const isType = (object, expectedType, details) => {
		if (typeof object !== expectedType) {
			details["expectedType"] = expectedType;
			throw new WorkboxError("incorrect-type", details);
		}
	};
	const isInstance = (object, expectedClass, details) => {
		if (!(object instanceof expectedClass)) {
			details["expectedClassName"] = expectedClass.name;
			throw new WorkboxError("incorrect-class", details);
		}
	};
	const isOneOf = (value, validValues, details) => {
		if (!validValues.includes(value)) {
			details["validValueDescription"] = `Valid values are ${JSON.stringify(validValues)}.`;
			throw new WorkboxError("invalid-value", details);
		}
	};
	const isArrayOfClass = (value, expectedClass, details) => {
		const error = new WorkboxError("not-array-of-class", details);
		if (!Array.isArray(value)) {
			throw error;
		}
		for (const item of value) {
			if (!(item instanceof expectedClass)) {
				throw error;
			}
		}
	};
	const finalAssertExports = {
		hasMethod,
		isArray,
		isInstance,
		isOneOf,
		isType,
		isArrayOfClass
	};
	// @ts-ignore
	try {
		self["workbox:routing:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The default HTTP method, 'GET', used when there's no specific method
	* configured for a route.
	*
	* @type {string}
	*
	* @private
	*/
	const defaultMethod = "GET";
	/**
	* The list of valid HTTP methods associated with requests that could be routed.
	*
	* @type {Array<string>}
	*
	* @private
	*/
	const validMethods = [
		"DELETE",
		"GET",
		"HEAD",
		"PATCH",
		"POST",
		"PUT"
	];
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {function()|Object} handler Either a function, or an object with a
	* 'handle' method.
	* @return {Object} An object with a handle method.
	*
	* @private
	*/
	const normalizeHandler = (handler) => {
		if (handler && typeof handler === "object") {
			{
				finalAssertExports.hasMethod(handler, "handle", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "handler"
				});
			}
			return handler;
		} else {
			{
				finalAssertExports.isType(handler, "function", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "handler"
				});
			}
			return { handle: handler };
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A `Route` consists of a pair of callback functions, "match" and "handler".
	* The "match" callback determine if a route should be used to "handle" a
	* request by returning a non-falsy value if it can. The "handler" callback
	* is called when there is a match and should return a Promise that resolves
	* to a `Response`.
	*
	* @memberof workbox-routing
	*/
	class Route {
		/**
		* Constructor for Route class.
		*
		* @param {workbox-routing~matchCallback} match
		* A callback function that determines whether the route matches a given
		* `fetch` event by returning a non-falsy value.
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resolving to a Response.
		* @param {string} [method='GET'] The HTTP method to match the Route
		* against.
		*/
		constructor(match, handler, method = defaultMethod) {
			{
				finalAssertExports.isType(match, "function", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "match"
				});
				if (method) {
					finalAssertExports.isOneOf(method, validMethods, { paramName: "method" });
				}
			}
			// These values are referenced directly by Router so cannot be
			// altered by minificaton.
			this.handler = normalizeHandler(handler);
			this.match = match;
			this.method = method;
		}
		/**
		*
		* @param {workbox-routing-handlerCallback} handler A callback
		* function that returns a Promise resolving to a Response
		*/
		setCatchHandler(handler) {
			this.catchHandler = normalizeHandler(handler);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* RegExpRoute makes it easy to create a regular expression based
	* {@link workbox-routing.Route}.
	*
	* For same-origin requests the RegExp only needs to match part of the URL. For
	* requests against third-party servers, you must define a RegExp that matches
	* the start of the URL.
	*
	* @memberof workbox-routing
	* @extends workbox-routing.Route
	*/
	class RegExpRoute extends Route {
		/**
		* If the regular expression contains
		* [capture groups]{@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp#grouping-back-references},
		* the captured values will be passed to the
		* {@link workbox-routing~handlerCallback} `params`
		* argument.
		*
		* @param {RegExp} regExp The regular expression to match against URLs.
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {string} [method='GET'] The HTTP method to match the Route
		* against.
		*/
		constructor(regExp, handler, method) {
			{
				finalAssertExports.isInstance(regExp, RegExp, {
					moduleName: "workbox-routing",
					className: "RegExpRoute",
					funcName: "constructor",
					paramName: "pattern"
				});
			}
			const match = ({ url }) => {
				const result = regExp.exec(url.href);
				// Return immediately if there's no match.
				if (!result) {
					return;
				}
				// Require that the match start at the first character in the URL string
				// if it's a cross-origin request.
				// See https://github.com/GoogleChrome/workbox/issues/281 for the context
				// behind this behavior.
				if (url.origin !== location.origin && result.index !== 0) {
					{
						logger.debug(`The regular expression '${regExp.toString()}' only partially matched ` + `against the cross-origin URL '${url.toString()}'. RegExpRoute's will only ` + `handle cross-origin requests if they match the entire URL.`);
					}
					return;
				}
				// If the route matches, but there aren't any capture groups defined, then
				// this will return [], which is truthy and therefore sufficient to
				// indicate a match.
				// If there are capture groups, then it will return their values.
				return result.slice(1);
			};
			super(match, handler, method);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const getFriendlyURL = (url) => {
		const urlObj = new URL(String(url), location.href);
		// See https://github.com/GoogleChrome/workbox/issues/2323
		// We want to include everything, except for the origin if it's same-origin.
		return urlObj.href.replace(new RegExp(`^${location.origin}`), "");
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The Router can be used to process a `FetchEvent` using one or more
	* {@link workbox-routing.Route}, responding with a `Response` if
	* a matching route exists.
	*
	* If no route matches a given a request, the Router will use a "default"
	* handler if one is defined.
	*
	* Should the matching Route throw an error, the Router will use a "catch"
	* handler if one is defined to gracefully deal with issues and respond with a
	* Request.
	*
	* If a request matches multiple routes, the **earliest** registered route will
	* be used to respond to the request.
	*
	* @memberof workbox-routing
	*/
	class Router {
		/**
		* Initializes a new Router.
		*/
		constructor() {
			this._routes = new Map();
			this._defaultHandlerMap = new Map();
		}
		/**
		* @return {Map<string, Array<workbox-routing.Route>>} routes A `Map` of HTTP
		* method name ('GET', etc.) to an array of all the corresponding `Route`
		* instances that are registered.
		*/
		get routes() {
			return this._routes;
		}
		/**
		* Adds a fetch event listener to respond to events when a route matches
		* the event's request.
		*/
		addFetchListener() {
			// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
			self.addEventListener("fetch", (event) => {
				const { request } = event;
				const responsePromise = this.handleRequest({
					request,
					event
				});
				if (responsePromise) {
					event.respondWith(responsePromise);
				}
			});
		}
		/**
		* Adds a message event listener for URLs to cache from the window.
		* This is useful to cache resources loaded on the page prior to when the
		* service worker started controlling it.
		*
		* The format of the message data sent from the window should be as follows.
		* Where the `urlsToCache` array may consist of URL strings or an array of
		* URL string + `requestInit` object (the same as you'd pass to `fetch()`).
		*
		* ```
		* {
		*   type: 'CACHE_URLS',
		*   payload: {
		*     urlsToCache: [
		*       './script1.js',
		*       './script2.js',
		*       ['./script3.js', {mode: 'no-cors'}],
		*     ],
		*   },
		* }
		* ```
		*/
		addCacheListener() {
			// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
			self.addEventListener("message", (event) => {
				// event.data is type 'any'
				// eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
				if (event.data && event.data.type === "CACHE_URLS") {
					// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
					const { payload } = event.data;
					{
						logger.debug(`Caching URLs from the window`, payload.urlsToCache);
					}
					const requestPromises = Promise.all(payload.urlsToCache.map((entry) => {
						if (typeof entry === "string") {
							entry = [entry];
						}
						const request = new Request(...entry);
						return this.handleRequest({
							request,
							event
						});
						// TODO(philipwalton): TypeScript errors without this typecast for
						// some reason (probably a bug). The real type here should work but
						// doesn't: `Array<Promise<Response> | undefined>`.
					}));
					event.waitUntil(requestPromises);
					// If a MessageChannel was used, reply to the message on success.
					if (event.ports && event.ports[0]) {
						void requestPromises.then(() => event.ports[0].postMessage(true));
					}
				}
			});
		}
		/**
		* Apply the routing rules to a FetchEvent object to get a Response from an
		* appropriate Route's handler.
		*
		* @param {Object} options
		* @param {Request} options.request The request to handle.
		* @param {ExtendableEvent} options.event The event that triggered the
		*     request.
		* @return {Promise<Response>|undefined} A promise is returned if a
		*     registered route can handle the request. If there is no matching
		*     route and there's no `defaultHandler`, `undefined` is returned.
		*/
		handleRequest({ request, event }) {
			{
				finalAssertExports.isInstance(request, Request, {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "handleRequest",
					paramName: "options.request"
				});
			}
			const url = new URL(request.url, location.href);
			if (!url.protocol.startsWith("http")) {
				{
					logger.debug(`Workbox Router only supports URLs that start with 'http'.`);
				}
				return;
			}
			const sameOrigin = url.origin === location.origin;
			const { params, route } = this.findMatchingRoute({
				event,
				request,
				sameOrigin,
				url
			});
			let handler = route && route.handler;
			const debugMessages = [];
			{
				if (handler) {
					debugMessages.push([`Found a route to handle this request:`, route]);
					if (params) {
						debugMessages.push([`Passing the following params to the route's handler:`, params]);
					}
				}
			}
			// If we don't have a handler because there was no matching route, then
			// fall back to defaultHandler if that's defined.
			const method = request.method;
			if (!handler && this._defaultHandlerMap.has(method)) {
				{
					debugMessages.push(`Failed to find a matching route. Falling ` + `back to the default handler for ${method}.`);
				}
				handler = this._defaultHandlerMap.get(method);
			}
			if (!handler) {
				{
					// No handler so Workbox will do nothing. If logs is set of debug
					// i.e. verbose, we should print out this information.
					logger.debug(`No route found for: ${getFriendlyURL(url)}`);
				}
				return;
			}
			{
				// We have a handler, meaning Workbox is going to handle the route.
				// print the routing details to the console.
				logger.groupCollapsed(`Router is responding to: ${getFriendlyURL(url)}`);
				debugMessages.forEach((msg) => {
					if (Array.isArray(msg)) {
						logger.log(...msg);
					} else {
						logger.log(msg);
					}
				});
				logger.groupEnd();
			}
			// Wrap in try and catch in case the handle method throws a synchronous
			// error. It should still callback to the catch handler.
			let responsePromise;
			try {
				responsePromise = handler.handle({
					url,
					request,
					event,
					params
				});
			} catch (err) {
				responsePromise = Promise.reject(err);
			}
			// Get route's catch handler, if it exists
			const catchHandler = route && route.catchHandler;
			if (responsePromise instanceof Promise && (this._catchHandler || catchHandler)) {
				responsePromise = responsePromise.catch(async (err) => {
					// If there's a route catch handler, process that first
					if (catchHandler) {
						{
							// Still include URL here as it will be async from the console group
							// and may not make sense without the URL
							logger.groupCollapsed(`Error thrown when responding to: ` + ` ${getFriendlyURL(url)}. Falling back to route's Catch Handler.`);
							logger.error(`Error thrown by:`, route);
							logger.error(err);
							logger.groupEnd();
						}
						try {
							return await catchHandler.handle({
								url,
								request,
								event,
								params
							});
						} catch (catchErr) {
							if (catchErr instanceof Error) {
								err = catchErr;
							}
						}
					}
					if (this._catchHandler) {
						{
							// Still include URL here as it will be async from the console group
							// and may not make sense without the URL
							logger.groupCollapsed(`Error thrown when responding to: ` + ` ${getFriendlyURL(url)}. Falling back to global Catch Handler.`);
							logger.error(`Error thrown by:`, route);
							logger.error(err);
							logger.groupEnd();
						}
						return this._catchHandler.handle({
							url,
							request,
							event
						});
					}
					throw err;
				});
			}
			return responsePromise;
		}
		/**
		* Checks a request and URL (and optionally an event) against the list of
		* registered routes, and if there's a match, returns the corresponding
		* route along with any params generated by the match.
		*
		* @param {Object} options
		* @param {URL} options.url
		* @param {boolean} options.sameOrigin The result of comparing `url.origin`
		*     against the current origin.
		* @param {Request} options.request The request to match.
		* @param {Event} options.event The corresponding event.
		* @return {Object} An object with `route` and `params` properties.
		*     They are populated if a matching route was found or `undefined`
		*     otherwise.
		*/
		findMatchingRoute({ url, sameOrigin, request, event }) {
			const routes = this._routes.get(request.method) || [];
			for (const route of routes) {
				let params;
				// route.match returns type any, not possible to change right now.
				// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
				const matchResult = route.match({
					url,
					sameOrigin,
					request,
					event
				});
				if (matchResult) {
					{
						// Warn developers that using an async matchCallback is almost always
						// not the right thing to do.
						if (matchResult instanceof Promise) {
							logger.warn(`While routing ${getFriendlyURL(url)}, an async ` + `matchCallback function was used. Please convert the ` + `following route to use a synchronous matchCallback function:`, route);
						}
					}
					// See https://github.com/GoogleChrome/workbox/issues/2079
					// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
					params = matchResult;
					if (Array.isArray(params) && params.length === 0) {
						// Instead of passing an empty array in as params, use undefined.
						params = undefined;
					} else if (matchResult.constructor === Object && Object.keys(matchResult).length === 0) {
						// Instead of passing an empty object in as params, use undefined.
						params = undefined;
					} else if (typeof matchResult === "boolean") {
						// For the boolean value true (rather than just something truth-y),
						// don't set params.
						// See https://github.com/GoogleChrome/workbox/pull/2134#issuecomment-513924353
						params = undefined;
					}
					// Return early if have a match.
					return {
						route,
						params
					};
				}
			}
			// If no match was found above, return and empty object.
			return {};
		}
		/**
		* Define a default `handler` that's called when no routes explicitly
		* match the incoming request.
		*
		* Each HTTP method ('GET', 'POST', etc.) gets its own default handler.
		*
		* Without a default handler, unmatched requests will go against the
		* network as if there were no service worker present.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {string} [method='GET'] The HTTP method to associate with this
		* default handler. Each method has its own default.
		*/
		setDefaultHandler(handler, method = defaultMethod) {
			this._defaultHandlerMap.set(method, normalizeHandler(handler));
		}
		/**
		* If a Route throws an error while handling a request, this `handler`
		* will be called and given a chance to provide a response.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		*/
		setCatchHandler(handler) {
			this._catchHandler = normalizeHandler(handler);
		}
		/**
		* Registers a route with the router.
		*
		* @param {workbox-routing.Route} route The route to register.
		*/
		registerRoute(route) {
			{
				finalAssertExports.isType(route, "object", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.hasMethod(route, "match", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.isType(route.handler, "object", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.hasMethod(route.handler, "handle", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route.handler"
				});
				finalAssertExports.isType(route.method, "string", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route.method"
				});
			}
			if (!this._routes.has(route.method)) {
				this._routes.set(route.method, []);
			}
			// Give precedence to all of the earlier routes by adding this additional
			// route to the end of the array.
			this._routes.get(route.method).push(route);
		}
		/**
		* Unregisters a route with the router.
		*
		* @param {workbox-routing.Route} route The route to unregister.
		*/
		unregisterRoute(route) {
			if (!this._routes.has(route.method)) {
				throw new WorkboxError("unregister-route-but-not-found-with-method", { method: route.method });
			}
			const routeIndex = this._routes.get(route.method).indexOf(route);
			if (routeIndex > -1) {
				this._routes.get(route.method).splice(routeIndex, 1);
			} else {
				throw new WorkboxError("unregister-route-route-not-registered");
			}
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let defaultRouter;
	/**
	* Creates a new, singleton Router instance if one does not exist. If one
	* does already exist, that instance is returned.
	*
	* @private
	* @return {Router}
	*/
	const getOrCreateDefaultRouter = () => {
		if (!defaultRouter) {
			defaultRouter = new Router();
			// The helpers that use the default Router assume these listeners exist.
			defaultRouter.addFetchListener();
			defaultRouter.addCacheListener();
		}
		return defaultRouter;
	};
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Easily register a RegExp, string, or function with a caching
	* strategy to a singleton Router instance.
	*
	* This method will generate a Route for you if needed and
	* call {@link workbox-routing.Router#registerRoute}.
	*
	* @param {RegExp|string|workbox-routing.Route~matchCallback|workbox-routing.Route} capture
	* If the capture param is a `Route`, all other arguments will be ignored.
	* @param {workbox-routing~handlerCallback} [handler] A callback
	* function that returns a Promise resulting in a Response. This parameter
	* is required if `capture` is not a `Route` object.
	* @param {string} [method='GET'] The HTTP method to match the Route
	* against.
	* @return {workbox-routing.Route} The generated `Route`.
	*
	* @memberof workbox-routing
	*/
	function registerRoute(capture, handler, method) {
		let route;
		if (typeof capture === "string") {
			const captureUrl = new URL(capture, location.href);
			{
				if (!(capture.startsWith("/") || capture.startsWith("http"))) {
					throw new WorkboxError("invalid-string", {
						moduleName: "workbox-routing",
						funcName: "registerRoute",
						paramName: "capture"
					});
				}
				// We want to check if Express-style wildcards are in the pathname only.
				// TODO: Remove this log message in v4.
				const valueToCheck = capture.startsWith("http") ? captureUrl.pathname : capture;
				// See https://github.com/pillarjs/path-to-regexp#parameters
				const wildcards = "[*:?+]";
				if (new RegExp(`${wildcards}`).exec(valueToCheck)) {
					logger.debug(`The '$capture' parameter contains an Express-style wildcard ` + `character (${wildcards}). Strings are now always interpreted as ` + `exact matches; use a RegExp for partial or wildcard matches.`);
				}
			}
			const matchCallback = ({ url }) => {
				{
					if (url.pathname === captureUrl.pathname && url.origin !== captureUrl.origin) {
						logger.debug(`${capture} only partially matches the cross-origin URL ` + `${url.toString()}. This route will only handle cross-origin requests ` + `if they match the entire URL.`);
					}
				}
				return url.href === captureUrl.href;
			};
			// If `capture` is a string then `handler` and `method` must be present.
			route = new Route(matchCallback, handler, method);
		} else if (capture instanceof RegExp) {
			// If `capture` is a `RegExp` then `handler` and `method` must be present.
			route = new RegExpRoute(capture, handler, method);
		} else if (typeof capture === "function") {
			// If `capture` is a function then `handler` and `method` must be present.
			route = new Route(capture, handler, method);
		} else if (capture instanceof Route) {
			route = capture;
		} else {
			throw new WorkboxError("unsupported-route-type", {
				moduleName: "workbox-routing",
				funcName: "registerRoute",
				paramName: "capture"
			});
		}
		const defaultRouter = getOrCreateDefaultRouter();
		defaultRouter.registerRoute(route);
		return route;
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const _cacheNameDetails = {
		googleAnalytics: "googleAnalytics",
		precache: "precache-v2",
		prefix: "workbox",
		runtime: "runtime",
		suffix: typeof registration !== "undefined" ? registration.scope : ""
	};
	const _createCacheName = (cacheName) => {
		return [
			_cacheNameDetails.prefix,
			cacheName,
			_cacheNameDetails.suffix
		].filter((value) => value && value.length > 0).join("-");
	};
	const eachCacheNameDetail = (fn) => {
		for (const key of Object.keys(_cacheNameDetails)) {
			fn(key);
		}
	};
	const cacheNames = {
		updateDetails: (details) => {
			eachCacheNameDetail((key) => {
				if (typeof details[key] === "string") {
					_cacheNameDetails[key] = details[key];
				}
			});
		},
		getGoogleAnalyticsName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.googleAnalytics);
		},
		getPrecacheName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.precache);
		},
		getPrefix: () => {
			return _cacheNameDetails.prefix;
		},
		getRuntimeName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.runtime);
		},
		getSuffix: () => {
			return _cacheNameDetails.suffix;
		}
	};
	/*
	Copyright 2020 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A utility method that makes it easier to use `event.waitUntil` with
	* async functions and return the result.
	*
	* @param {ExtendableEvent} event
	* @param {Function} asyncFn
	* @return {Function}
	* @private
	*/
	function waitUntil(event, asyncFn) {
		const returnPromise = asyncFn();
		event.waitUntil(returnPromise);
		return returnPromise;
	}
	// @ts-ignore
	try {
		self["workbox:precaching:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	// Name of the search parameter used to store revision info.
	const REVISION_SEARCH_PARAM = "__WB_REVISION__";
	/**
	* Converts a manifest entry into a versioned URL suitable for precaching.
	*
	* @param {Object|string} entry
	* @return {string} A URL with versioning info.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function createCacheKey(entry) {
		if (!entry) {
			throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		}
		// If a precache manifest entry is a string, it's assumed to be a versioned
		// URL, like '/app.abcd1234.js'. Return as-is.
		if (typeof entry === "string") {
			const urlObject = new URL(entry, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		const { revision, url } = entry;
		if (!url) {
			throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		}
		// If there's just a URL and no revision, then it's also assumed to be a
		// versioned URL.
		if (!revision) {
			const urlObject = new URL(url, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		// Otherwise, construct a properly versioned URL using the custom Workbox
		// search parameter along with the revision info.
		const cacheKeyURL = new URL(url, location.href);
		const originalURL = new URL(url, location.href);
		cacheKeyURL.searchParams.set(REVISION_SEARCH_PARAM, revision);
		return {
			cacheKey: cacheKeyURL.href,
			url: originalURL.href
		};
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A plugin, designed to be used with PrecacheController, to determine the
	* of assets that were updated (or not updated) during the install event.
	*
	* @private
	*/
	class PrecacheInstallReportPlugin {
		constructor() {
			this.updatedURLs = [];
			this.notUpdatedURLs = [];
			this.handlerWillStart = async ({ request, state }) => {
				// TODO: `state` should never be undefined...
				if (state) {
					state.originalRequest = request;
				}
			};
			this.cachedResponseWillBeUsed = async ({ event, state, cachedResponse }) => {
				if (event.type === "install") {
					if (state && state.originalRequest && state.originalRequest instanceof Request) {
						// TODO: `state` should never be undefined...
						const url = state.originalRequest.url;
						if (cachedResponse) {
							this.notUpdatedURLs.push(url);
						} else {
							this.updatedURLs.push(url);
						}
					}
				}
				return cachedResponse;
			};
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A plugin, designed to be used with PrecacheController, to translate URLs into
	* the corresponding cache key, based on the current revision info.
	*
	* @private
	*/
	class PrecacheCacheKeyPlugin {
		constructor({ precacheController }) {
			this.cacheKeyWillBeUsed = async ({ request, params }) => {
				// Params is type any, can't change right now.
				/* eslint-disable */
				const cacheKey = (params === null || params === void 0 ? void 0 : params.cacheKey) || this._precacheController.getCacheKeyForURL(request.url);
				/* eslint-enable */
				return cacheKey ? new Request(cacheKey, { headers: request.headers }) : request;
			};
			this._precacheController = precacheController;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {string} groupTitle
	* @param {Array<string>} deletedURLs
	*
	* @private
	*/
	const logGroup = (groupTitle, deletedURLs) => {
		logger.groupCollapsed(groupTitle);
		for (const url of deletedURLs) {
			logger.log(url);
		}
		logger.groupEnd();
	};
	/**
	* @param {Array<string>} deletedURLs
	*
	* @private
	* @memberof workbox-precaching
	*/
	function printCleanupDetails(deletedURLs) {
		const deletionCount = deletedURLs.length;
		if (deletionCount > 0) {
			logger.groupCollapsed(`During precaching cleanup, ` + `${deletionCount} cached ` + `request${deletionCount === 1 ? " was" : "s were"} deleted.`);
			logGroup("Deleted Cache Requests", deletedURLs);
			logger.groupEnd();
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {string} groupTitle
	* @param {Array<string>} urls
	*
	* @private
	*/
	function _nestedGroup(groupTitle, urls) {
		if (urls.length === 0) {
			return;
		}
		logger.groupCollapsed(groupTitle);
		for (const url of urls) {
			logger.log(url);
		}
		logger.groupEnd();
	}
	/**
	* @param {Array<string>} urlsToPrecache
	* @param {Array<string>} urlsAlreadyPrecached
	*
	* @private
	* @memberof workbox-precaching
	*/
	function printInstallDetails(urlsToPrecache, urlsAlreadyPrecached) {
		const precachedCount = urlsToPrecache.length;
		const alreadyPrecachedCount = urlsAlreadyPrecached.length;
		if (precachedCount || alreadyPrecachedCount) {
			let message = `Precaching ${precachedCount} file${precachedCount === 1 ? "" : "s"}.`;
			if (alreadyPrecachedCount > 0) {
				message += ` ${alreadyPrecachedCount} ` + `file${alreadyPrecachedCount === 1 ? " is" : "s are"} already cached.`;
			}
			logger.groupCollapsed(message);
			_nestedGroup(`View newly precached URLs.`, urlsToPrecache);
			_nestedGroup(`View previously precached URLs.`, urlsAlreadyPrecached);
			logger.groupEnd();
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let supportStatus;
	/**
	* A utility function that determines whether the current browser supports
	* constructing a new `Response` from a `response.body` stream.
	*
	* @return {boolean} `true`, if the current browser can successfully
	*     construct a `Response` from a `response.body` stream, `false` otherwise.
	*
	* @private
	*/
	function canConstructResponseFromBodyStream() {
		if (supportStatus === undefined) {
			const testResponse = new Response("");
			if ("body" in testResponse) {
				try {
					new Response(testResponse.body);
					supportStatus = true;
				} catch (error) {
					supportStatus = false;
				}
			}
			supportStatus = false;
		}
		return supportStatus;
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Allows developers to copy a response and modify its `headers`, `status`,
	* or `statusText` values (the values settable via a
	* [`ResponseInit`]{@link https://developer.mozilla.org/en-US/docs/Web/API/Response/Response#Syntax}
	* object in the constructor).
	* To modify these values, pass a function as the second argument. That
	* function will be invoked with a single object with the response properties
	* `{headers, status, statusText}`. The return value of this function will
	* be used as the `ResponseInit` for the new `Response`. To change the values
	* either modify the passed parameter(s) and return it, or return a totally
	* new object.
	*
	* This method is intentionally limited to same-origin responses, regardless of
	* whether CORS was used or not.
	*
	* @param {Response} response
	* @param {Function} modifier
	* @memberof workbox-core
	*/
	async function copyResponse(response, modifier) {
		let origin = null;
		// If response.url isn't set, assume it's cross-origin and keep origin null.
		if (response.url) {
			const responseURL = new URL(response.url);
			origin = responseURL.origin;
		}
		if (origin !== self.location.origin) {
			throw new WorkboxError("cross-origin-copy-response", { origin });
		}
		const clonedResponse = response.clone();
		// Create a fresh `ResponseInit` object by cloning the headers.
		const responseInit = {
			headers: new Headers(clonedResponse.headers),
			status: clonedResponse.status,
			statusText: clonedResponse.statusText
		};
		// Apply any user modifications.
		const modifiedResponseInit = responseInit;
		// Create the new response from the body stream and `ResponseInit`
		// modifications. Note: not all browsers support the Response.body stream,
		// so fall back to reading the entire body into memory as a blob.
		const body = canConstructResponseFromBodyStream() ? clonedResponse.body : await clonedResponse.blob();
		return new Response(body, modifiedResponseInit);
	}
	/*
	Copyright 2020 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	function stripParams(fullURL, ignoreParams) {
		const strippedURL = new URL(fullURL);
		for (const param of ignoreParams) {
			strippedURL.searchParams.delete(param);
		}
		return strippedURL.href;
	}
	/**
	* Matches an item in the cache, ignoring specific URL params. This is similar
	* to the `ignoreSearch` option, but it allows you to ignore just specific
	* params (while continuing to match on the others).
	*
	* @private
	* @param {Cache} cache
	* @param {Request} request
	* @param {Object} matchOptions
	* @param {Array<string>} ignoreParams
	* @return {Promise<Response|undefined>}
	*/
	async function cacheMatchIgnoreParams(cache, request, ignoreParams, matchOptions) {
		const strippedRequestURL = stripParams(request.url, ignoreParams);
		// If the request doesn't include any ignored params, match as normal.
		if (request.url === strippedRequestURL) {
			return cache.match(request, matchOptions);
		}
		// Otherwise, match by comparing keys
		const keysOptions = Object.assign(Object.assign({}, matchOptions), { ignoreSearch: true });
		const cacheKeys = await cache.keys(request, keysOptions);
		for (const cacheKey of cacheKeys) {
			const strippedCacheKeyURL = stripParams(cacheKey.url, ignoreParams);
			if (strippedRequestURL === strippedCacheKeyURL) {
				return cache.match(cacheKey, matchOptions);
			}
		}
		return;
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The Deferred class composes Promises in a way that allows for them to be
	* resolved or rejected from outside the constructor. In most cases promises
	* should be used directly, but Deferreds can be necessary when the logic to
	* resolve a promise must be separate.
	*
	* @private
	*/
	class Deferred {
		/**
		* Creates a promise and exposes its resolve and reject functions as methods.
		*/
		constructor() {
			this.promise = new Promise((resolve, reject) => {
				this.resolve = resolve;
				this.reject = reject;
			});
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	// Callbacks to be executed whenever there's a quota error.
	// Can't change Function type right now.
	// eslint-disable-next-line @typescript-eslint/ban-types
	const quotaErrorCallbacks = new Set();
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Runs all of the callback functions, one at a time sequentially, in the order
	* in which they were registered.
	*
	* @memberof workbox-core
	* @private
	*/
	async function executeQuotaErrorCallbacks() {
		{
			logger.log(`About to run ${quotaErrorCallbacks.size} ` + `callbacks to clean up caches.`);
		}
		for (const callback of quotaErrorCallbacks) {
			await callback();
			{
				logger.log(callback, "is complete.");
			}
		}
		{
			logger.log("Finished running callbacks.");
		}
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Returns a promise that resolves and the passed number of milliseconds.
	* This utility is an async/await-friendly version of `setTimeout`.
	*
	* @param {number} ms
	* @return {Promise}
	* @private
	*/
	function timeout(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	// @ts-ignore
	try {
		self["workbox:strategies:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	function toRequest(input) {
		return typeof input === "string" ? new Request(input) : input;
	}
	/**
	* A class created every time a Strategy instance calls
	* {@link workbox-strategies.Strategy~handle} or
	* {@link workbox-strategies.Strategy~handleAll} that wraps all fetch and
	* cache actions around plugin callbacks and keeps track of when the strategy
	* is "done" (i.e. all added `event.waitUntil()` promises have resolved).
	*
	* @memberof workbox-strategies
	*/
	class StrategyHandler {
		/**
		* Creates a new instance associated with the passed strategy and event
		* that's handling the request.
		*
		* The constructor also initializes the state that will be passed to each of
		* the plugins handling this request.
		*
		* @param {workbox-strategies.Strategy} strategy
		* @param {Object} options
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params] The return value from the
		*     {@link workbox-routing~matchCallback} (if applicable).
		*/
		constructor(strategy, options) {
			this._cacheKeys = {};
			/**
			* The request the strategy is performing (passed to the strategy's
			* `handle()` or `handleAll()` method).
			* @name request
			* @instance
			* @type {Request}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* The event associated with this request.
			* @name event
			* @instance
			* @type {ExtendableEvent}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* A `URL` instance of `request.url` (if passed to the strategy's
			* `handle()` or `handleAll()` method).
			* Note: the `url` param will be present if the strategy was invoked
			* from a workbox `Route` object.
			* @name url
			* @instance
			* @type {URL|undefined}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* A `param` value (if passed to the strategy's
			* `handle()` or `handleAll()` method).
			* Note: the `param` param will be present if the strategy was invoked
			* from a workbox `Route` object and the
			* {@link workbox-routing~matchCallback} returned
			* a truthy value (it will be that value).
			* @name params
			* @instance
			* @type {*|undefined}
			* @memberof workbox-strategies.StrategyHandler
			*/
			{
				finalAssertExports.isInstance(options.event, ExtendableEvent, {
					moduleName: "workbox-strategies",
					className: "StrategyHandler",
					funcName: "constructor",
					paramName: "options.event"
				});
			}
			Object.assign(this, options);
			this.event = options.event;
			this._strategy = strategy;
			this._handlerDeferred = new Deferred();
			this._extendLifetimePromises = [];
			// Copy the plugins list (since it's mutable on the strategy),
			// so any mutations don't affect this handler instance.
			this._plugins = [...strategy.plugins];
			this._pluginStateMap = new Map();
			for (const plugin of this._plugins) {
				this._pluginStateMap.set(plugin, {});
			}
			this.event.waitUntil(this._handlerDeferred.promise);
		}
		/**
		* Fetches a given request (and invokes any applicable plugin callback
		* methods) using the `fetchOptions` (for non-navigation requests) and
		* `plugins` defined on the `Strategy` object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - `requestWillFetch()`
		* - `fetchDidSucceed()`
		* - `fetchDidFail()`
		*
		* @param {Request|string} input The URL or request to fetch.
		* @return {Promise<Response>}
		*/
		async fetch(input) {
			const { event } = this;
			let request = toRequest(input);
			if (request.mode === "navigate" && event instanceof FetchEvent && event.preloadResponse) {
				const possiblePreloadResponse = await event.preloadResponse;
				if (possiblePreloadResponse) {
					{
						logger.log(`Using a preloaded navigation response for ` + `'${getFriendlyURL(request.url)}'`);
					}
					return possiblePreloadResponse;
				}
			}
			// If there is a fetchDidFail plugin, we need to save a clone of the
			// original request before it's either modified by a requestWillFetch
			// plugin or before the original request's body is consumed via fetch().
			const originalRequest = this.hasCallback("fetchDidFail") ? request.clone() : null;
			try {
				for (const cb of this.iterateCallbacks("requestWillFetch")) {
					request = await cb({
						request: request.clone(),
						event
					});
				}
			} catch (err) {
				if (err instanceof Error) {
					throw new WorkboxError("plugin-error-request-will-fetch", { thrownErrorMessage: err.message });
				}
			}
			// The request can be altered by plugins with `requestWillFetch` making
			// the original request (most likely from a `fetch` event) different
			// from the Request we make. Pass both to `fetchDidFail` to aid debugging.
			const pluginFilteredRequest = request.clone();
			try {
				let fetchResponse;
				// See https://github.com/GoogleChrome/workbox/issues/1796
				fetchResponse = await fetch(request, request.mode === "navigate" ? undefined : this._strategy.fetchOptions);
				if ("development" !== "production") {
					logger.debug(`Network request for ` + `'${getFriendlyURL(request.url)}' returned a response with ` + `status '${fetchResponse.status}'.`);
				}
				for (const callback of this.iterateCallbacks("fetchDidSucceed")) {
					fetchResponse = await callback({
						event,
						request: pluginFilteredRequest,
						response: fetchResponse
					});
				}
				return fetchResponse;
			} catch (error) {
				{
					logger.log(`Network request for ` + `'${getFriendlyURL(request.url)}' threw an error.`, error);
				}
				// `originalRequest` will only exist if a `fetchDidFail` callback
				// is being used (see above).
				if (originalRequest) {
					await this.runCallbacks("fetchDidFail", {
						error,
						event,
						originalRequest: originalRequest.clone(),
						request: pluginFilteredRequest.clone()
					});
				}
				throw error;
			}
		}
		/**
		* Calls `this.fetch()` and (in the background) runs `this.cachePut()` on
		* the response generated by `this.fetch()`.
		*
		* The call to `this.cachePut()` automatically invokes `this.waitUntil()`,
		* so you do not have to manually call `waitUntil()` on the event.
		*
		* @param {Request|string} input The request or URL to fetch and cache.
		* @return {Promise<Response>}
		*/
		async fetchAndCachePut(input) {
			const response = await this.fetch(input);
			const responseClone = response.clone();
			void this.waitUntil(this.cachePut(input, responseClone));
			return response;
		}
		/**
		* Matches a request from the cache (and invokes any applicable plugin
		* callback methods) using the `cacheName`, `matchOptions`, and `plugins`
		* defined on the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cachedResponseWillBeUsed()
		*
		* @param {Request|string} key The Request or URL to use as the cache key.
		* @return {Promise<Response|undefined>} A matching response, if found.
		*/
		async cacheMatch(key) {
			const request = toRequest(key);
			let cachedResponse;
			const { cacheName, matchOptions } = this._strategy;
			const effectiveRequest = await this.getCacheKey(request, "read");
			const multiMatchOptions = Object.assign(Object.assign({}, matchOptions), { cacheName });
			cachedResponse = await caches.match(effectiveRequest, multiMatchOptions);
			{
				if (cachedResponse) {
					logger.debug(`Found a cached response in '${cacheName}'.`);
				} else {
					logger.debug(`No cached response found in '${cacheName}'.`);
				}
			}
			for (const callback of this.iterateCallbacks("cachedResponseWillBeUsed")) {
				cachedResponse = await callback({
					cacheName,
					matchOptions,
					cachedResponse,
					request: effectiveRequest,
					event: this.event
				}) || undefined;
			}
			return cachedResponse;
		}
		/**
		* Puts a request/response pair in the cache (and invokes any applicable
		* plugin callback methods) using the `cacheName` and `plugins` defined on
		* the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cacheWillUpdate()
		* - cacheDidUpdate()
		*
		* @param {Request|string} key The request or URL to use as the cache key.
		* @param {Response} response The response to cache.
		* @return {Promise<boolean>} `false` if a cacheWillUpdate caused the response
		* not be cached, and `true` otherwise.
		*/
		async cachePut(key, response) {
			const request = toRequest(key);
			// Run in the next task to avoid blocking other cache reads.
			// https://github.com/w3c/ServiceWorker/issues/1397
			await timeout(0);
			const effectiveRequest = await this.getCacheKey(request, "write");
			{
				if (effectiveRequest.method && effectiveRequest.method !== "GET") {
					throw new WorkboxError("attempt-to-cache-non-get-request", {
						url: getFriendlyURL(effectiveRequest.url),
						method: effectiveRequest.method
					});
				}
				// See https://github.com/GoogleChrome/workbox/issues/2818
				const vary = response.headers.get("Vary");
				if (vary) {
					logger.debug(`The response for ${getFriendlyURL(effectiveRequest.url)} ` + `has a 'Vary: ${vary}' header. ` + `Consider setting the {ignoreVary: true} option on your strategy ` + `to ensure cache matching and deletion works as expected.`);
				}
			}
			if (!response) {
				{
					logger.error(`Cannot cache non-existent response for ` + `'${getFriendlyURL(effectiveRequest.url)}'.`);
				}
				throw new WorkboxError("cache-put-with-no-response", { url: getFriendlyURL(effectiveRequest.url) });
			}
			const responseToCache = await this._ensureResponseSafeToCache(response);
			if (!responseToCache) {
				{
					logger.debug(`Response '${getFriendlyURL(effectiveRequest.url)}' ` + `will not be cached.`, responseToCache);
				}
				return false;
			}
			const { cacheName, matchOptions } = this._strategy;
			const cache = await self.caches.open(cacheName);
			const hasCacheUpdateCallback = this.hasCallback("cacheDidUpdate");
			const oldResponse = hasCacheUpdateCallback ? await cacheMatchIgnoreParams(
				// TODO(philipwalton): the `__WB_REVISION__` param is a precaching
				// feature. Consider into ways to only add this behavior if using
				// precaching.
				cache,
				effectiveRequest.clone(),
				["__WB_REVISION__"],
				matchOptions
			) : null;
			{
				logger.debug(`Updating the '${cacheName}' cache with a new Response ` + `for ${getFriendlyURL(effectiveRequest.url)}.`);
			}
			try {
				await cache.put(effectiveRequest, hasCacheUpdateCallback ? responseToCache.clone() : responseToCache);
			} catch (error) {
				if (error instanceof Error) {
					// See https://developer.mozilla.org/en-US/docs/Web/API/DOMException#exception-QuotaExceededError
					if (error.name === "QuotaExceededError") {
						await executeQuotaErrorCallbacks();
					}
					throw error;
				}
			}
			for (const callback of this.iterateCallbacks("cacheDidUpdate")) {
				await callback({
					cacheName,
					oldResponse,
					newResponse: responseToCache.clone(),
					request: effectiveRequest,
					event: this.event
				});
			}
			return true;
		}
		/**
		* Checks the list of plugins for the `cacheKeyWillBeUsed` callback, and
		* executes any of those callbacks found in sequence. The final `Request`
		* object returned by the last plugin is treated as the cache key for cache
		* reads and/or writes. If no `cacheKeyWillBeUsed` plugin callbacks have
		* been registered, the passed request is returned unmodified
		*
		* @param {Request} request
		* @param {string} mode
		* @return {Promise<Request>}
		*/
		async getCacheKey(request, mode) {
			const key = `${request.url} | ${mode}`;
			if (!this._cacheKeys[key]) {
				let effectiveRequest = request;
				for (const callback of this.iterateCallbacks("cacheKeyWillBeUsed")) {
					effectiveRequest = toRequest(await callback({
						mode,
						request: effectiveRequest,
						event: this.event,
						// params has a type any can't change right now.
						params: this.params
					}));
				}
				this._cacheKeys[key] = effectiveRequest;
			}
			return this._cacheKeys[key];
		}
		/**
		* Returns true if the strategy has at least one plugin with the given
		* callback.
		*
		* @param {string} name The name of the callback to check for.
		* @return {boolean}
		*/
		hasCallback(name) {
			for (const plugin of this._strategy.plugins) {
				if (name in plugin) {
					return true;
				}
			}
			return false;
		}
		/**
		* Runs all plugin callbacks matching the given name, in order, passing the
		* given param object (merged ith the current plugin state) as the only
		* argument.
		*
		* Note: since this method runs all plugins, it's not suitable for cases
		* where the return value of a callback needs to be applied prior to calling
		* the next callback. See
		* {@link workbox-strategies.StrategyHandler#iterateCallbacks}
		* below for how to handle that case.
		*
		* @param {string} name The name of the callback to run within each plugin.
		* @param {Object} param The object to pass as the first (and only) param
		*     when executing each callback. This object will be merged with the
		*     current plugin state prior to callback execution.
		*/
		async runCallbacks(name, param) {
			for (const callback of this.iterateCallbacks(name)) {
				// TODO(philipwalton): not sure why `any` is needed. It seems like
				// this should work with `as WorkboxPluginCallbackParam[C]`.
				await callback(param);
			}
		}
		/**
		* Accepts a callback and returns an iterable of matching plugin callbacks,
		* where each callback is wrapped with the current handler state (i.e. when
		* you call each callback, whatever object parameter you pass it will
		* be merged with the plugin's current state).
		*
		* @param {string} name The name fo the callback to run
		* @return {Array<Function>}
		*/
		*iterateCallbacks(name) {
			for (const plugin of this._strategy.plugins) {
				if (typeof plugin[name] === "function") {
					const state = this._pluginStateMap.get(plugin);
					const statefulCallback = (param) => {
						const statefulParam = Object.assign(Object.assign({}, param), { state });
						// TODO(philipwalton): not sure why `any` is needed. It seems like
						// this should work with `as WorkboxPluginCallbackParam[C]`.
						return plugin[name](statefulParam);
					};
					yield statefulCallback;
				}
			}
		}
		/**
		* Adds a promise to the
		* [extend lifetime promises]{@link https://w3c.github.io/ServiceWorker/#extendableevent-extend-lifetime-promises}
		* of the event associated with the request being handled (usually a
		* `FetchEvent`).
		*
		* Note: you can await
		* {@link workbox-strategies.StrategyHandler~doneWaiting}
		* to know when all added promises have settled.
		*
		* @param {Promise} promise A promise to add to the extend lifetime promises
		*     of the event that triggered the request.
		*/
		waitUntil(promise) {
			this._extendLifetimePromises.push(promise);
			return promise;
		}
		/**
		* Returns a promise that resolves once all promises passed to
		* {@link workbox-strategies.StrategyHandler~waitUntil}
		* have settled.
		*
		* Note: any work done after `doneWaiting()` settles should be manually
		* passed to an event's `waitUntil()` method (not this handler's
		* `waitUntil()` method), otherwise the service worker thread may be killed
		* prior to your work completing.
		*/
		async doneWaiting() {
			while (this._extendLifetimePromises.length) {
				const promises = this._extendLifetimePromises.splice(0);
				const result = await Promise.allSettled(promises);
				const firstRejection = result.find((i) => i.status === "rejected");
				if (firstRejection) {
					throw firstRejection.reason;
				}
			}
		}
		/**
		* Stops running the strategy and immediately resolves any pending
		* `waitUntil()` promises.
		*/
		destroy() {
			this._handlerDeferred.resolve(null);
		}
		/**
		* This method will call cacheWillUpdate on the available plugins (or use
		* status === 200) to determine if the Response is safe and valid to cache.
		*
		* @param {Request} options.request
		* @param {Response} options.response
		* @return {Promise<Response|undefined>}
		*
		* @private
		*/
		async _ensureResponseSafeToCache(response) {
			let responseToCache = response;
			let pluginsUsed = false;
			for (const callback of this.iterateCallbacks("cacheWillUpdate")) {
				responseToCache = await callback({
					request: this.request,
					response: responseToCache,
					event: this.event
				}) || undefined;
				pluginsUsed = true;
				if (!responseToCache) {
					break;
				}
			}
			if (!pluginsUsed) {
				if (responseToCache && responseToCache.status !== 200) {
					responseToCache = undefined;
				}
				{
					if (responseToCache) {
						if (responseToCache.status !== 200) {
							if (responseToCache.status === 0) {
								logger.warn(`The response for '${this.request.url}' ` + `is an opaque response. The caching strategy that you're ` + `using will not cache opaque responses by default.`);
							} else {
								logger.debug(`The response for '${this.request.url}' ` + `returned a status code of '${response.status}' and won't ` + `be cached as a result.`);
							}
						}
					}
				}
			}
			return responseToCache;
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* An abstract base class that all other strategy classes must extend from:
	*
	* @memberof workbox-strategies
	*/
	class Strategy {
		/**
		* Creates a new instance of the strategy and sets all documented option
		* properties as public instance properties.
		*
		* Note: if a custom strategy class extends the base Strategy class and does
		* not need more than these properties, it does not need to define its own
		* constructor.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		*/
		constructor(options = {}) {
			/**
			* Cache name to store and retrieve
			* requests. Defaults to the cache names provided by
			* {@link workbox-core.cacheNames}.
			*
			* @type {string}
			*/
			this.cacheName = cacheNames.getRuntimeName(options.cacheName);
			/**
			* The list
			* [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
			* used by this strategy.
			*
			* @type {Array<Object>}
			*/
			this.plugins = options.plugins || [];
			/**
			* Values passed along to the
			* [`init`]{@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters}
			* of all fetch() requests made by this strategy.
			*
			* @type {Object}
			*/
			this.fetchOptions = options.fetchOptions;
			/**
			* The
			* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
			* for any `cache.match()` or `cache.put()` calls made by this strategy.
			*
			* @type {Object}
			*/
			this.matchOptions = options.matchOptions;
		}
		/**
		* Perform a request strategy and returns a `Promise` that will resolve with
		* a `Response`, invoking all relevant plugin callbacks.
		*
		* When a strategy instance is registered with a Workbox
		* {@link workbox-routing.Route}, this method is automatically
		* called when the route matches.
		*
		* Alternatively, this method can be used in a standalone `FetchEvent`
		* listener by passing it to `event.respondWith()`.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		*/
		handle(options) {
			const [responseDone] = this.handleAll(options);
			return responseDone;
		}
		/**
		* Similar to {@link workbox-strategies.Strategy~handle}, but
		* instead of just returning a `Promise` that resolves to a `Response` it
		* it will return an tuple of `[response, done]` promises, where the former
		* (`response`) is equivalent to what `handle()` returns, and the latter is a
		* Promise that will resolve once any promises that were added to
		* `event.waitUntil()` as part of performing the strategy have completed.
		*
		* You can await the `done` promise to ensure any extra work performed by
		* the strategy (usually caching responses) completes successfully.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		* @return {Array<Promise>} A tuple of [response, done]
		*     promises that can be used to determine when the response resolves as
		*     well as when the handler has completed all its work.
		*/
		handleAll(options) {
			// Allow for flexible options to be passed.
			if (options instanceof FetchEvent) {
				options = {
					event: options,
					request: options.request
				};
			}
			const event = options.event;
			const request = typeof options.request === "string" ? new Request(options.request) : options.request;
			const params = "params" in options ? options.params : undefined;
			const handler = new StrategyHandler(this, {
				event,
				request,
				params
			});
			const responseDone = this._getResponse(handler, request, event);
			const handlerDone = this._awaitComplete(responseDone, handler, request, event);
			// Return an array of promises, suitable for use with Promise.all().
			return [responseDone, handlerDone];
		}
		async _getResponse(handler, request, event) {
			await handler.runCallbacks("handlerWillStart", {
				event,
				request
			});
			let response = undefined;
			try {
				response = await this._handle(request, handler);
				// The "official" Strategy subclasses all throw this error automatically,
				// but in case a third-party Strategy doesn't, ensure that we have a
				// consistent failure when there's no response or an error response.
				if (!response || response.type === "error") {
					throw new WorkboxError("no-response", { url: request.url });
				}
			} catch (error) {
				if (error instanceof Error) {
					for (const callback of handler.iterateCallbacks("handlerDidError")) {
						response = await callback({
							error,
							event,
							request
						});
						if (response) {
							break;
						}
					}
				}
				if (!response) {
					throw error;
				} else {
					logger.log(`While responding to '${getFriendlyURL(request.url)}', ` + `an ${error instanceof Error ? error.toString() : ""} error occurred. Using a fallback response provided by ` + `a handlerDidError plugin.`);
				}
			}
			for (const callback of handler.iterateCallbacks("handlerWillRespond")) {
				response = await callback({
					event,
					request,
					response
				});
			}
			return response;
		}
		async _awaitComplete(responseDone, handler, request, event) {
			let response;
			let error;
			try {
				response = await responseDone;
			} catch (error) {}
			try {
				await handler.runCallbacks("handlerDidRespond", {
					event,
					request,
					response
				});
				await handler.doneWaiting();
			} catch (waitUntilError) {
				if (waitUntilError instanceof Error) {
					error = waitUntilError;
				}
			}
			await handler.runCallbacks("handlerDidComplete", {
				event,
				request,
				response,
				error
			});
			handler.destroy();
			if (error) {
				throw error;
			}
		}
	}
	/**
	* Classes extending the `Strategy` based class should implement this method,
	* and leverage the {@link workbox-strategies.StrategyHandler}
	* arg to perform all fetching and cache logic, which will ensure all relevant
	* cache, cache options, fetch options and plugins are used (per the current
	* strategy instance).
	*
	* @name _handle
	* @instance
	* @abstract
	* @function
	* @param {Request} request
	* @param {workbox-strategies.StrategyHandler} handler
	* @return {Promise<Response>}
	*
	* @memberof workbox-strategies.Strategy
	*/
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A {@link workbox-strategies.Strategy} implementation
	* specifically designed to work with
	* {@link workbox-precaching.PrecacheController}
	* to both cache and fetch precached assets.
	*
	* Note: an instance of this class is created automatically when creating a
	* `PrecacheController`; it's generally not necessary to create this yourself.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-precaching
	*/
	class PrecacheStrategy extends Strategy {
		/**
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] {@link https://developers.google.com/web/tools/workbox/guides/using-plugins|Plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* {@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters|init}
		* of all fetch() requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* {@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions|CacheQueryOptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor(options = {}) {
			options.cacheName = cacheNames.getPrecacheName(options.cacheName);
			super(options);
			this._fallbackToNetwork = options.fallbackToNetwork === false ? false : true;
			// Redirected responses cannot be used to satisfy a navigation request, so
			// any redirected response must be "copied" rather than cloned, so the new
			// response doesn't contain the `redirected` flag. See:
			// https://bugs.chromium.org/p/chromium/issues/detail?id=669363&desc=2#c1
			this.plugins.push(PrecacheStrategy.copyRedirectedCacheableResponsesPlugin);
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const response = await handler.cacheMatch(request);
			if (response) {
				return response;
			}
			// If this is an `install` event for an entry that isn't already cached,
			// then populate the cache.
			if (handler.event && handler.event.type === "install") {
				return await this._handleInstall(request, handler);
			}
			// Getting here means something went wrong. An entry that should have been
			// precached wasn't found in the cache.
			return await this._handleFetch(request, handler);
		}
		async _handleFetch(request, handler) {
			let response;
			const params = handler.params || {};
			// Fall back to the network if we're configured to do so.
			if (this._fallbackToNetwork) {
				{
					logger.warn(`The precached response for ` + `${getFriendlyURL(request.url)} in ${this.cacheName} was not ` + `found. Falling back to the network.`);
				}
				const integrityInManifest = params.integrity;
				const integrityInRequest = request.integrity;
				const noIntegrityConflict = !integrityInRequest || integrityInRequest === integrityInManifest;
				// Do not add integrity if the original request is no-cors
				// See https://github.com/GoogleChrome/workbox/issues/3096
				response = await handler.fetch(new Request(request, { integrity: request.mode !== "no-cors" ? integrityInRequest || integrityInManifest : undefined }));
				// It's only "safe" to repair the cache if we're using SRI to guarantee
				// that the response matches the precache manifest's expectations,
				// and there's either a) no integrity property in the incoming request
				// or b) there is an integrity, and it matches the precache manifest.
				// See https://github.com/GoogleChrome/workbox/issues/2858
				// Also if the original request users no-cors we don't use integrity.
				// See https://github.com/GoogleChrome/workbox/issues/3096
				if (integrityInManifest && noIntegrityConflict && request.mode !== "no-cors") {
					this._useDefaultCacheabilityPluginIfNeeded();
					const wasCached = await handler.cachePut(request, response.clone());
					{
						if (wasCached) {
							logger.log(`A response for ${getFriendlyURL(request.url)} ` + `was used to "repair" the precache.`);
						}
					}
				}
			} else {
				// This shouldn't normally happen, but there are edge cases:
				// https://github.com/GoogleChrome/workbox/issues/1441
				throw new WorkboxError("missing-precache-entry", {
					cacheName: this.cacheName,
					url: request.url
				});
			}
			{
				const cacheKey = params.cacheKey || await handler.getCacheKey(request, "read");
				// Workbox is going to handle the route.
				// print the routing details to the console.
				logger.groupCollapsed(`Precaching is responding to: ` + getFriendlyURL(request.url));
				logger.log(`Serving the precached url: ${getFriendlyURL(cacheKey instanceof Request ? cacheKey.url : cacheKey)}`);
				logger.groupCollapsed(`View request details here.`);
				logger.log(request);
				logger.groupEnd();
				logger.groupCollapsed(`View response details here.`);
				logger.log(response);
				logger.groupEnd();
				logger.groupEnd();
			}
			return response;
		}
		async _handleInstall(request, handler) {
			this._useDefaultCacheabilityPluginIfNeeded();
			const response = await handler.fetch(request);
			// Make sure we defer cachePut() until after we know the response
			// should be cached; see https://github.com/GoogleChrome/workbox/issues/2737
			const wasCached = await handler.cachePut(request, response.clone());
			if (!wasCached) {
				// Throwing here will lead to the `install` handler failing, which
				// we want to do if *any* of the responses aren't safe to cache.
				throw new WorkboxError("bad-precaching-response", {
					url: request.url,
					status: response.status
				});
			}
			return response;
		}
		/**
		* This method is complex, as there a number of things to account for:
		*
		* The `plugins` array can be set at construction, and/or it might be added to
		* to at any time before the strategy is used.
		*
		* At the time the strategy is used (i.e. during an `install` event), there
		* needs to be at least one plugin that implements `cacheWillUpdate` in the
		* array, other than `copyRedirectedCacheableResponsesPlugin`.
		*
		* - If this method is called and there are no suitable `cacheWillUpdate`
		* plugins, we need to add `defaultPrecacheCacheabilityPlugin`.
		*
		* - If this method is called and there is exactly one `cacheWillUpdate`, then
		* we don't have to do anything (this might be a previously added
		* `defaultPrecacheCacheabilityPlugin`, or it might be a custom plugin).
		*
		* - If this method is called and there is more than one `cacheWillUpdate`,
		* then we need to check if one is `defaultPrecacheCacheabilityPlugin`. If so,
		* we need to remove it. (This situation is unlikely, but it could happen if
		* the strategy is used multiple times, the first without a `cacheWillUpdate`,
		* and then later on after manually adding a custom `cacheWillUpdate`.)
		*
		* See https://github.com/GoogleChrome/workbox/issues/2737 for more context.
		*
		* @private
		*/
		_useDefaultCacheabilityPluginIfNeeded() {
			let defaultPluginIndex = null;
			let cacheWillUpdatePluginCount = 0;
			for (const [index, plugin] of this.plugins.entries()) {
				// Ignore the copy redirected plugin when determining what to do.
				if (plugin === PrecacheStrategy.copyRedirectedCacheableResponsesPlugin) {
					continue;
				}
				// Save the default plugin's index, in case it needs to be removed.
				if (plugin === PrecacheStrategy.defaultPrecacheCacheabilityPlugin) {
					defaultPluginIndex = index;
				}
				if (plugin.cacheWillUpdate) {
					cacheWillUpdatePluginCount++;
				}
			}
			if (cacheWillUpdatePluginCount === 0) {
				this.plugins.push(PrecacheStrategy.defaultPrecacheCacheabilityPlugin);
			} else if (cacheWillUpdatePluginCount > 1 && defaultPluginIndex !== null) {
				// Only remove the default plugin; multiple custom plugins are allowed.
				this.plugins.splice(defaultPluginIndex, 1);
			}
			// Nothing needs to be done if cacheWillUpdatePluginCount is 1
		}
	}
	PrecacheStrategy.defaultPrecacheCacheabilityPlugin = { async cacheWillUpdate({ response }) {
		if (!response || response.status >= 400) {
			return null;
		}
		return response;
	} };
	PrecacheStrategy.copyRedirectedCacheableResponsesPlugin = { async cacheWillUpdate({ response }) {
		return response.redirected ? await copyResponse(response) : response;
	} };
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Performs efficient precaching of assets.
	*
	* @memberof workbox-precaching
	*/
	class PrecacheController {
		/**
		* Create a new PrecacheController.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] The cache to use for precaching.
		* @param {string} [options.plugins] Plugins to use when precaching as well
		* as responding to fetch events for precached assets.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor({ cacheName, plugins = [], fallbackToNetwork = true } = {}) {
			this._urlsToCacheKeys = new Map();
			this._urlsToCacheModes = new Map();
			this._cacheKeysToIntegrities = new Map();
			this._strategy = new PrecacheStrategy({
				cacheName: cacheNames.getPrecacheName(cacheName),
				plugins: [...plugins, new PrecacheCacheKeyPlugin({ precacheController: this })],
				fallbackToNetwork
			});
			// Bind the install and activate methods to the instance.
			this.install = this.install.bind(this);
			this.activate = this.activate.bind(this);
		}
		/**
		* @type {workbox-precaching.PrecacheStrategy} The strategy created by this controller and
		* used to cache assets and respond to fetch events.
		*/
		get strategy() {
			return this._strategy;
		}
		/**
		* Adds items to the precache list, removing any duplicates and
		* stores the files in the
		* {@link workbox-core.cacheNames|"precache cache"} when the service
		* worker installs.
		*
		* This method can be called multiple times.
		*
		* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
		*/
		precache(entries) {
			this.addToCacheList(entries);
			if (!this._installAndActiveListenersAdded) {
				self.addEventListener("install", this.install);
				self.addEventListener("activate", this.activate);
				this._installAndActiveListenersAdded = true;
			}
		}
		/**
		* This method will add items to the precache list, removing duplicates
		* and ensuring the information is valid.
		*
		* @param {Array<workbox-precaching.PrecacheController.PrecacheEntry|string>} entries
		*     Array of entries to precache.
		*/
		addToCacheList(entries) {
			{
				finalAssertExports.isArray(entries, {
					moduleName: "workbox-precaching",
					className: "PrecacheController",
					funcName: "addToCacheList",
					paramName: "entries"
				});
			}
			const urlsToWarnAbout = [];
			for (const entry of entries) {
				// See https://github.com/GoogleChrome/workbox/issues/2259
				if (typeof entry === "string") {
					urlsToWarnAbout.push(entry);
				} else if (entry && entry.revision === undefined) {
					urlsToWarnAbout.push(entry.url);
				}
				const { cacheKey, url } = createCacheKey(entry);
				const cacheMode = typeof entry !== "string" && entry.revision ? "reload" : "default";
				if (this._urlsToCacheKeys.has(url) && this._urlsToCacheKeys.get(url) !== cacheKey) {
					throw new WorkboxError("add-to-cache-list-conflicting-entries", {
						firstEntry: this._urlsToCacheKeys.get(url),
						secondEntry: cacheKey
					});
				}
				if (typeof entry !== "string" && entry.integrity) {
					if (this._cacheKeysToIntegrities.has(cacheKey) && this._cacheKeysToIntegrities.get(cacheKey) !== entry.integrity) {
						throw new WorkboxError("add-to-cache-list-conflicting-integrities", { url });
					}
					this._cacheKeysToIntegrities.set(cacheKey, entry.integrity);
				}
				this._urlsToCacheKeys.set(url, cacheKey);
				this._urlsToCacheModes.set(url, cacheMode);
				if (urlsToWarnAbout.length > 0) {
					const warningMessage = `Workbox is precaching URLs without revision ` + `info: ${urlsToWarnAbout.join(", ")}\nThis is generally NOT safe. ` + `Learn more at https://bit.ly/wb-precache`;
					{
						logger.warn(warningMessage);
					}
				}
			}
		}
		/**
		* Precaches new and updated assets. Call this method from the service worker
		* install event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.InstallResult>}
		*/
		install(event) {
			// waitUntil returns Promise<any>
			// eslint-disable-next-line @typescript-eslint/no-unsafe-return
			return waitUntil(event, async () => {
				const installReportPlugin = new PrecacheInstallReportPlugin();
				this.strategy.plugins.push(installReportPlugin);
				// Cache entries one at a time.
				// See https://github.com/GoogleChrome/workbox/issues/2528
				for (const [url, cacheKey] of this._urlsToCacheKeys) {
					const integrity = this._cacheKeysToIntegrities.get(cacheKey);
					const cacheMode = this._urlsToCacheModes.get(url);
					const request = new Request(url, {
						integrity,
						cache: cacheMode,
						credentials: "same-origin"
					});
					await Promise.all(this.strategy.handleAll({
						params: { cacheKey },
						request,
						event
					}));
				}
				const { updatedURLs, notUpdatedURLs } = installReportPlugin;
				{
					printInstallDetails(updatedURLs, notUpdatedURLs);
				}
				return {
					updatedURLs,
					notUpdatedURLs
				};
			});
		}
		/**
		* Deletes assets that are no longer present in the current precache manifest.
		* Call this method from the service worker activate event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.CleanupResult>}
		*/
		activate(event) {
			// waitUntil returns Promise<any>
			// eslint-disable-next-line @typescript-eslint/no-unsafe-return
			return waitUntil(event, async () => {
				const cache = await self.caches.open(this.strategy.cacheName);
				const currentlyCachedRequests = await cache.keys();
				const expectedCacheKeys = new Set(this._urlsToCacheKeys.values());
				const deletedURLs = [];
				for (const request of currentlyCachedRequests) {
					if (!expectedCacheKeys.has(request.url)) {
						await cache.delete(request);
						deletedURLs.push(request.url);
					}
				}
				{
					printCleanupDetails(deletedURLs);
				}
				return { deletedURLs };
			});
		}
		/**
		* Returns a mapping of a precached URL to the corresponding cache key, taking
		* into account the revision information for the URL.
		*
		* @return {Map<string, string>} A URL to cache key mapping.
		*/
		getURLsToCacheKeys() {
			return this._urlsToCacheKeys;
		}
		/**
		* Returns a list of all the URLs that have been precached by the current
		* service worker.
		*
		* @return {Array<string>} The precached URLs.
		*/
		getCachedURLs() {
			return [...this._urlsToCacheKeys.keys()];
		}
		/**
		* Returns the cache key used for storing a given URL. If that URL is
		* unversioned, like `/index.html', then the cache key will be the original
		* URL with a search parameter appended to it.
		*
		* @param {string} url A URL whose cache key you want to look up.
		* @return {string} The versioned URL that corresponds to a cache key
		* for the original URL, or undefined if that URL isn't precached.
		*/
		getCacheKeyForURL(url) {
			const urlObject = new URL(url, location.href);
			return this._urlsToCacheKeys.get(urlObject.href);
		}
		/**
		* @param {string} url A cache key whose SRI you want to look up.
		* @return {string} The subresource integrity associated with the cache key,
		* or undefined if it's not set.
		*/
		getIntegrityForCacheKey(cacheKey) {
			return this._cacheKeysToIntegrities.get(cacheKey);
		}
		/**
		* This acts as a drop-in replacement for
		* [`cache.match()`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/match)
		* with the following differences:
		*
		* - It knows what the name of the precache is, and only checks in that cache.
		* - It allows you to pass in an "original" URL without versioning parameters,
		* and it will automatically look up the correct cache key for the currently
		* active revision of that URL.
		*
		* E.g., `matchPrecache('index.html')` will find the correct precached
		* response for the currently active service worker, even if the actual cache
		* key is `'/index.html?__WB_REVISION__=1234abcd'`.
		*
		* @param {string|Request} request The key (without revisioning parameters)
		* to look up in the precache.
		* @return {Promise<Response|undefined>}
		*/
		async matchPrecache(request) {
			const url = request instanceof Request ? request.url : request;
			const cacheKey = this.getCacheKeyForURL(url);
			if (cacheKey) {
				const cache = await self.caches.open(this.strategy.cacheName);
				return cache.match(cacheKey);
			}
			return undefined;
		}
		/**
		* Returns a function that looks up `url` in the precache (taking into
		* account revision information), and returns the corresponding `Response`.
		*
		* @param {string} url The precached URL which will be used to lookup the
		* `Response`.
		* @return {workbox-routing~handlerCallback}
		*/
		createHandlerBoundToURL(url) {
			const cacheKey = this.getCacheKeyForURL(url);
			if (!cacheKey) {
				throw new WorkboxError("non-precached-url", { url });
			}
			return (options) => {
				options.request = new Request(url);
				options.params = Object.assign({ cacheKey }, options.params);
				return this.strategy.handle(options);
			};
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let precacheController;
	/**
	* @return {PrecacheController}
	* @private
	*/
	const getOrCreatePrecacheController = () => {
		if (!precacheController) {
			precacheController = new PrecacheController();
		}
		return precacheController;
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Removes any URL search parameters that should be ignored.
	*
	* @param {URL} urlObject The original URL.
	* @param {Array<RegExp>} ignoreURLParametersMatching RegExps to test against
	* each search parameter name. Matches mean that the search parameter should be
	* ignored.
	* @return {URL} The URL with any ignored search parameters removed.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching = []) {
		// Convert the iterable into an array at the start of the loop to make sure
		// deletion doesn't mess up iteration.
		for (const paramName of [...urlObject.searchParams.keys()]) {
			if (ignoreURLParametersMatching.some((regExp) => regExp.test(paramName))) {
				urlObject.searchParams.delete(paramName);
			}
		}
		return urlObject;
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Generator function that yields possible variations on the original URL to
	* check, one at a time.
	*
	* @param {string} url
	* @param {Object} options
	*
	* @private
	* @memberof workbox-precaching
	*/
	function* generateURLVariations(url, { ignoreURLParametersMatching = [/^utm_/, /^fbclid$/], directoryIndex = "index.html", cleanURLs = true, urlManipulation } = {}) {
		const urlObject = new URL(url, location.href);
		urlObject.hash = "";
		yield urlObject.href;
		const urlWithoutIgnoredParams = removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching);
		yield urlWithoutIgnoredParams.href;
		if (directoryIndex && urlWithoutIgnoredParams.pathname.endsWith("/")) {
			const directoryURL = new URL(urlWithoutIgnoredParams.href);
			directoryURL.pathname += directoryIndex;
			yield directoryURL.href;
		}
		if (cleanURLs) {
			const cleanURL = new URL(urlWithoutIgnoredParams.href);
			cleanURL.pathname += ".html";
			yield cleanURL.href;
		}
		if (urlManipulation) {
			const additionalURLs = urlManipulation({ url: urlObject });
			for (const urlToAttempt of additionalURLs) {
				yield urlToAttempt.href;
			}
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A subclass of {@link workbox-routing.Route} that takes a
	* {@link workbox-precaching.PrecacheController}
	* instance and uses it to match incoming requests and handle fetching
	* responses from the precache.
	*
	* @memberof workbox-precaching
	* @extends workbox-routing.Route
	*/
	class PrecacheRoute extends Route {
		/**
		* @param {PrecacheController} precacheController A `PrecacheController`
		* instance used to both match requests and respond to fetch events.
		* @param {Object} [options] Options to control how requests are matched
		* against the list of precached URLs.
		* @param {string} [options.directoryIndex=index.html] The `directoryIndex` will
		* check cache entries for a URLs ending with '/' to see if there is a hit when
		* appending the `directoryIndex` value.
		* @param {Array<RegExp>} [options.ignoreURLParametersMatching=[/^utm_/, /^fbclid$/]] An
		* array of regex's to remove search params when looking for a cache match.
		* @param {boolean} [options.cleanURLs=true] The `cleanURLs` option will
		* check the cache for the URL with a `.html` added to the end of the end.
		* @param {workbox-precaching~urlManipulation} [options.urlManipulation]
		* This is a function that should take a URL and return an array of
		* alternative URLs that should be checked for precache matches.
		*/
		constructor(precacheController, options) {
			const match = ({ request }) => {
				const urlsToCacheKeys = precacheController.getURLsToCacheKeys();
				for (const possibleURL of generateURLVariations(request.url, options)) {
					const cacheKey = urlsToCacheKeys.get(possibleURL);
					if (cacheKey) {
						const integrity = precacheController.getIntegrityForCacheKey(cacheKey);
						return {
							cacheKey,
							integrity
						};
					}
				}
				{
					logger.debug(`Precaching did not find a match for ` + getFriendlyURL(request.url));
				}
				return;
			};
			super(match, precacheController.strategy);
		}
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Add a `fetch` listener to the service worker that will
	* respond to
	* [network requests]{@link https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers#Custom_responses_to_requests}
	* with precached assets.
	*
	* Requests for assets that aren't precached, the `FetchEvent` will not be
	* responded to, allowing the event to fall through to other `fetch` event
	* listeners.
	*
	* @param {Object} [options] See the {@link workbox-precaching.PrecacheRoute}
	* options.
	*
	* @memberof workbox-precaching
	*/
	function addRoute(options) {
		const precacheController = getOrCreatePrecacheController();
		const precacheRoute = new PrecacheRoute(precacheController, options);
		registerRoute(precacheRoute);
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds items to the precache list, removing any duplicates and
	* stores the files in the
	* {@link workbox-core.cacheNames|"precache cache"} when the service
	* worker installs.
	*
	* This method can be called multiple times.
	*
	* Please note: This method **will not** serve any of the cached files for you.
	* It only precaches files. To respond to a network request you call
	* {@link workbox-precaching.addRoute}.
	*
	* If you have a single array of files to precache, you can just call
	* {@link workbox-precaching.precacheAndRoute}.
	*
	* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
	*
	* @memberof workbox-precaching
	*/
	function precache(entries) {
		const precacheController = getOrCreatePrecacheController();
		precacheController.precache(entries);
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* This method will add entries to the precache list and add a route to
	* respond to fetch events.
	*
	* This is a convenience method that will call
	* {@link workbox-precaching.precache} and
	* {@link workbox-precaching.addRoute} in a single call.
	*
	* @param {Array<Object|string>} entries Array of entries to precache.
	* @param {Object} [options] See the
	* {@link workbox-precaching.PrecacheRoute} options.
	*
	* @memberof workbox-precaching
	*/
	function precacheAndRoute(entries, options) {
		precache(entries);
		addRoute(options);
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const SUBSTRING_TO_FIND = "-precache-";
	/**
	* Cleans up incompatible precaches that were created by older versions of
	* Workbox, by a service worker registered under the current scope.
	*
	* This is meant to be called as part of the `activate` event.
	*
	* This should be safe to use as long as you don't include `substringToFind`
	* (defaulting to `-precache-`) in your non-precache cache names.
	*
	* @param {string} currentPrecacheName The cache name currently in use for
	* precaching. This cache won't be deleted.
	* @param {string} [substringToFind='-precache-'] Cache names which include this
	* substring will be deleted (excluding `currentPrecacheName`).
	* @return {Array<string>} A list of all the cache names that were deleted.
	*
	* @private
	* @memberof workbox-precaching
	*/
	const deleteOutdatedCaches = async (currentPrecacheName, substringToFind = SUBSTRING_TO_FIND) => {
		const cacheNames = await self.caches.keys();
		const cacheNamesToDelete = cacheNames.filter((cacheName) => {
			return cacheName.includes(substringToFind) && cacheName.includes(self.registration.scope) && cacheName !== currentPrecacheName;
		});
		await Promise.all(cacheNamesToDelete.map((cacheName) => self.caches.delete(cacheName)));
		return cacheNamesToDelete;
	};
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds an `activate` event listener which will clean up incompatible
	* precaches that were created by older versions of Workbox.
	*
	* @memberof workbox-precaching
	*/
	function cleanupOutdatedCaches() {
		// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
		self.addEventListener("activate", (event) => {
			const cacheName = cacheNames.getPrecacheName();
			event.waitUntil(deleteOutdatedCaches(cacheName).then((cachesDeleted) => {
				{
					if (cachesDeleted.length > 0) {
						logger.log(`The following out-of-date precaches were cleaned up ` + `automatically:`, cachesDeleted);
					}
				}
			}));
		});
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* NavigationRoute makes it easy to create a
	* {@link workbox-routing.Route} that matches for browser
	* [navigation requests]{@link https://developers.google.com/web/fundamentals/primers/service-workers/high-performance-loading#first_what_are_navigation_requests}.
	*
	* It will only match incoming Requests whose
	* {@link https://fetch.spec.whatwg.org/#concept-request-mode|mode}
	* is set to `navigate`.
	*
	* You can optionally only apply this route to a subset of navigation requests
	* by using one or both of the `denylist` and `allowlist` parameters.
	*
	* @memberof workbox-routing
	* @extends workbox-routing.Route
	*/
	class NavigationRoute extends Route {
		/**
		* If both `denylist` and `allowlist` are provided, the `denylist` will
		* take precedence and the request will not match this route.
		*
		* The regular expressions in `allowlist` and `denylist`
		* are matched against the concatenated
		* [`pathname`]{@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/pathname}
		* and [`search`]{@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/search}
		* portions of the requested URL.
		*
		* *Note*: These RegExps may be evaluated against every destination URL during
		* a navigation. Avoid using
		* [complex RegExps](https://github.com/GoogleChrome/workbox/issues/3077),
		* or else your users may see delays when navigating your site.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {Object} options
		* @param {Array<RegExp>} [options.denylist] If any of these patterns match,
		* the route will not handle the request (even if a allowlist RegExp matches).
		* @param {Array<RegExp>} [options.allowlist=[/./]] If any of these patterns
		* match the URL's pathname and search parameter, the route will handle the
		* request (assuming the denylist doesn't match).
		*/
		constructor(handler, { allowlist = [/./], denylist = [] } = {}) {
			{
				finalAssertExports.isArrayOfClass(allowlist, RegExp, {
					moduleName: "workbox-routing",
					className: "NavigationRoute",
					funcName: "constructor",
					paramName: "options.allowlist"
				});
				finalAssertExports.isArrayOfClass(denylist, RegExp, {
					moduleName: "workbox-routing",
					className: "NavigationRoute",
					funcName: "constructor",
					paramName: "options.denylist"
				});
			}
			super((options) => this._match(options), handler);
			this._allowlist = allowlist;
			this._denylist = denylist;
		}
		/**
		* Routes match handler.
		*
		* @param {Object} options
		* @param {URL} options.url
		* @param {Request} options.request
		* @return {boolean}
		*
		* @private
		*/
		_match({ url, request }) {
			if (request && request.mode !== "navigate") {
				return false;
			}
			const pathnameAndSearch = url.pathname + url.search;
			for (const regExp of this._denylist) {
				if (regExp.test(pathnameAndSearch)) {
					{
						logger.log(`The navigation route ${pathnameAndSearch} is not ` + `being used, since the URL matches this denylist pattern: ` + `${regExp.toString()}`);
					}
					return false;
				}
			}
			if (this._allowlist.some((regExp) => regExp.test(pathnameAndSearch))) {
				{
					logger.debug(`The navigation route ${pathnameAndSearch} ` + `is being used.`);
				}
				return true;
			}
			{
				logger.log(`The navigation route ${pathnameAndSearch} is not ` + `being used, since the URL being navigated to doesn't ` + `match the allowlist.`);
			}
			return false;
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Helper function that calls
	* {@link PrecacheController#createHandlerBoundToURL} on the default
	* {@link PrecacheController} instance.
	*
	* If you are creating your own {@link PrecacheController}, then call the
	* {@link PrecacheController#createHandlerBoundToURL} on that instance,
	* instead of using this function.
	*
	* @param {string} url The precached URL which will be used to lookup the
	* `Response`.
	* @param {boolean} [fallbackToNetwork=true] Whether to attempt to get the
	* response from the network if there's a precache miss.
	* @return {workbox-routing~handlerCallback}
	*
	* @memberof workbox-precaching
	*/
	function createHandlerBoundToURL(url) {
		const precacheController = getOrCreatePrecacheController();
		return precacheController.createHandlerBoundToURL(url);
	}
	exports.NavigationRoute = NavigationRoute;
	exports.cleanupOutdatedCaches = cleanupOutdatedCaches;
	exports.clientsClaim = clientsClaim;
	exports.createHandlerBoundToURL = createHandlerBoundToURL;
	exports.precacheAndRoute = precacheAndRoute;
	exports.registerRoute = registerRoute;
}));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxDQUFDLFNBQVMsSUFBSSxTQUFVLFNBQVM7Q0FBRTs7Q0FHdEMsSUFBSTtFQUNGLEtBQUsseUJBQXlCLEVBQUU7Q0FDbEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7O0NBZWIsU0FBUyxlQUFlO0VBQ3RCLEtBQUssaUJBQWlCLGtCQUFrQixLQUFLLFFBQVEsTUFBTSxDQUFDO0NBQzlEOzs7Ozs7O0NBUUEsTUFBTSxnQkFBZ0I7OztFQUdwQixJQUFJLEVBQUUsMkJBQTJCLGFBQWE7R0FDNUMsS0FBSyx3QkFBd0I7RUFDL0I7RUFDQSxJQUFJLFVBQVU7RUFDZCxNQUFNLG1CQUFtQjtHQUN2QixPQUFPO0dBQ1AsS0FBSztHQUNMLE1BQU07R0FDTixPQUFPO0dBQ1AsZ0JBQWdCO0dBQ2hCLFVBQVU7RUFDWjtFQUNBLE1BQU0sUUFBUSxTQUFVLFFBQVEsTUFBTTtHQUNwQyxJQUFJLEtBQUssdUJBQXVCO0lBQzlCO0dBQ0Y7R0FDQSxJQUFJLFdBQVcsa0JBQWtCOzs7SUFHL0IsSUFBSSxpQ0FBaUMsS0FBSyxVQUFVLFNBQVMsR0FBRztLQUM5RCxRQUFRLE9BQU8sQ0FBQyxHQUFHLElBQUk7S0FDdkI7SUFDRjtHQUNGO0dBQ0EsTUFBTSxTQUFTO0lBQUMsZUFBZSxpQkFBaUI7SUFBVztJQUF3QjtJQUFnQjtJQUFxQjtHQUFvQjs7R0FFNUksTUFBTSxZQUFZLFVBQVUsQ0FBQyxJQUFJLENBQUMsYUFBYSxPQUFPLEtBQUssR0FBRyxDQUFDO0dBQy9ELFFBQVEsT0FBTyxDQUFDLEdBQUcsV0FBVyxHQUFHLElBQUk7R0FDckMsSUFBSSxXQUFXLGtCQUFrQjtJQUMvQixVQUFVO0dBQ1o7R0FDQSxJQUFJLFdBQVcsWUFBWTtJQUN6QixVQUFVO0dBQ1o7RUFDRjs7RUFFQSxNQUFNLE1BQU0sQ0FBQztFQUNiLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxnQkFBZ0I7RUFDbEQsS0FBSyxNQUFNLE9BQU8sZUFBZTtHQUMvQixNQUFNLFNBQVM7R0FDZixJQUFJLFdBQVcsR0FBRyxTQUFTO0lBQ3pCLE1BQU0sUUFBUSxJQUFJO0dBQ3BCO0VBQ0Y7RUFDQSxPQUFPO0NBQ1QsRUFBQyxBQUFDLENBQUM7Ozs7Ozs7O0NBU0gsTUFBTSxXQUFXO0VBQ2Ysa0JBQWtCLEVBQ2hCLFdBQ0EsdUJBQ0EsWUFDSTtHQUNKLElBQUksQ0FBQyxhQUFhLENBQUMsdUJBQXVCO0lBQ3hDLE1BQU0sSUFBSSxNQUFNLDRDQUE0QztHQUM5RDtHQUNBLE9BQU8sUUFBUSxVQUFVLDBDQUEwQyxxQkFBcUIsc0JBQXNCLHlCQUF5QixHQUFHLEtBQUssVUFBVSxLQUFLLEVBQUU7RUFDbEs7RUFDQSxpQkFBaUIsRUFDZixZQUNBLFdBQ0EsVUFDQSxnQkFDSTtHQUNKLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxXQUFXO0lBQ3hELE1BQU0sSUFBSSxNQUFNLDJDQUEyQztHQUM3RDtHQUNBLE9BQU8sa0JBQWtCLFVBQVUsa0JBQWtCLElBQUksV0FBVyxHQUFHLFVBQVUsR0FBRyxTQUFTO0VBQy9GO0VBQ0EsbUJBQW1CLEVBQ2pCLGNBQ0EsV0FDQSxZQUNBLFdBQ0EsZUFDSTtHQUNKLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLFVBQVU7SUFDM0QsTUFBTSxJQUFJLE1BQU0sNkNBQTZDO0dBQy9EO0dBQ0EsTUFBTSxlQUFlLFlBQVksR0FBRyxVQUFVLEtBQUs7R0FDbkQsT0FBTyxrQkFBa0IsVUFBVSxrQkFBa0IsSUFBSSxXQUFXLEdBQUcsaUJBQWlCLEdBQUcsU0FBUyxzQkFBc0IsYUFBYTtFQUN6STtFQUNBLG9CQUFvQixFQUNsQixtQkFDQSxXQUNBLFlBQ0EsV0FDQSxVQUNBLDJCQUNJO0dBQ0osSUFBSSxDQUFDLHFCQUFxQixDQUFDLGNBQWMsQ0FBQyxVQUFVO0lBQ2xELE1BQU0sSUFBSSxNQUFNLDhDQUE4QztHQUNoRTtHQUNBLE1BQU0sZUFBZSxZQUFZLEdBQUcsVUFBVSxLQUFLO0dBQ25ELElBQUksc0JBQXNCO0lBQ3hCLE9BQU8sMkJBQTJCLElBQUksV0FBVyxHQUFHLGVBQWUsU0FBUyxRQUFRLGdDQUFnQyxrQkFBa0I7R0FDeEk7R0FDQSxPQUFPLGtCQUFrQixVQUFVLGtCQUFrQixJQUFJLFdBQVcsR0FBRyxlQUFlLFNBQVMsUUFBUSxnQ0FBZ0Msa0JBQWtCO0VBQzNKO0VBQ0EscUJBQXFCLEVBQ25CLGdCQUNBLFdBQ0EsWUFDQSxXQUNBLGVBQ0k7R0FDSixJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsVUFBVTtJQUMzRSxNQUFNLElBQUksTUFBTSwrQ0FBK0M7R0FDakU7R0FDQSxPQUFPLEdBQUcsV0FBVyxHQUFHLFVBQVUsR0FBRyxTQUFTLG9CQUFvQixJQUFJLFVBQVUsMkJBQTJCLGVBQWU7RUFDNUg7RUFDQSxzQ0FBc0MsRUFDcEMsWUFDSTtHQUNKLE9BQU8sdUNBQXVDLHdFQUF3RSxJQUFJLEtBQUssVUFBVSxLQUFLLEVBQUUsbURBQW1ELHlFQUF5RTtFQUM5UTtFQUNBLDBDQUEwQyxFQUN4QyxZQUNBLGtCQUNJO0dBQ0osSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhO0lBQy9CLE1BQU0sSUFBSSxNQUFNLHlCQUF5Qiw4Q0FBOEM7R0FDekY7R0FDQSxPQUFPLGtDQUFrQywwRUFBMEUsR0FBRyxXQUFXLGdEQUFnRCx3RUFBd0U7RUFDM1A7RUFDQSxvQ0FBb0MsRUFDbEMseUJBQ0k7R0FDSixJQUFJLENBQUMsb0JBQW9CO0lBQ3ZCLE1BQU0sSUFBSSxNQUFNLHlCQUF5QiwyQ0FBMkM7R0FDdEY7R0FDQSxPQUFPLG1FQUFtRSxrQ0FBa0MsbUJBQW1CO0VBQ2pJO0VBQ0EsdUJBQXVCLEVBQ3JCLGFBQ0EsWUFDSTtHQUNKLElBQUksQ0FBQyxhQUFhO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLHlEQUF5RDtHQUMzRTtHQUNBLE9BQU8sbUVBQW1FLG9CQUFvQixZQUFZLG1DQUFtQyxJQUFJLEtBQUssVUFBVSxLQUFLLEVBQUU7RUFDeks7RUFDQSwrQ0FBK0MsRUFDN0MsYUFDSTtHQUNKLElBQUksQ0FBQyxRQUFRO0lBQ1gsTUFBTSxJQUFJLE1BQU0seUJBQXlCLHFEQUFxRDtHQUNoRztHQUNBLE9BQU8sK0RBQStELG1DQUFtQyxPQUFPO0VBQ2xIO0VBQ0EsK0NBQStDO0dBQzdDLE9BQU8sOERBQThEO0VBQ3ZFO0VBQ0Esd0JBQXdCLEVBQ3RCLFdBQ0k7R0FDSixPQUFPLHdDQUF3QyxLQUFLO0VBQ3REO0VBQ0EseUJBQXlCLEVBQ3ZCLFdBQ0k7R0FDSixPQUFPLG1CQUFtQixLQUFLLDZCQUE2QjtFQUM5RDtFQUNBLGlDQUFpQyxFQUMvQixZQUNBLGdCQUNJO0dBQ0osT0FBTyxRQUFRLFdBQVcseUNBQXlDLElBQUksVUFBVTtFQUNuRjtFQUNBLDJCQUEyQixFQUN6QixZQUNBLFdBQ0EsVUFDQSxnQkFDSTtHQUNKLE9BQU8saUJBQWlCLFVBQVUseUNBQXlDLDZCQUE2QixXQUFXLEdBQUcsVUFBVSxHQUFHLFNBQVMsU0FBUztFQUN2SjtFQUNBLHVCQUF1QixFQUNyQixPQUNBLGVBQ0EsWUFDQSxXQUNBLFVBQ0EsZ0JBQ0k7R0FDSixPQUFPLGlCQUFpQixVQUFVLG9DQUFvQyxJQUFJLGNBQWMsdUJBQXVCLEtBQUssVUFBVSxLQUFLLEVBQUUsUUFBUSw0QkFBNEIsV0FBVyxHQUFHLFVBQVUsR0FBRyxTQUFTLE9BQU87RUFDdE47RUFDQSxnQ0FBZ0MsRUFDOUIsWUFDQSxXQUNBLGVBQ0k7R0FDSixPQUFPLHFFQUFxRSxNQUFNLFdBQVcsR0FBRyxVQUFVLEdBQUc7RUFDL0c7RUFDQSxpQ0FBaUMsRUFDL0IsWUFDQSxXQUNBLGVBQ0k7R0FDSixPQUFPLDZEQUE2RCxNQUFNLFdBQVcsR0FBRyxVQUFVLEdBQUc7RUFDdkc7RUFDQSxtQkFBbUIsRUFDakIsWUFDQSxVQUNBLGdCQUNJO0dBQ0osSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsVUFBVTtJQUMxQyxNQUFNLElBQUksTUFBTSw2Q0FBNkM7R0FDL0Q7R0FDQSxPQUFPLDRCQUE0QixVQUFVLGdDQUFnQyx5RUFBeUUsMkJBQTJCLFdBQVcsR0FBRyxTQUFTLFdBQVc7RUFDck47RUFDQSwrQkFBK0I7R0FDN0IsT0FBTyxtREFBbUQ7RUFDNUQ7RUFDQSx5Q0FBeUM7R0FDdkMsT0FBTywrREFBK0Q7RUFDeEU7RUFDQSxtQ0FBbUM7R0FDakMsT0FBTyw0REFBNEQ7RUFDckU7RUFDQSx1QkFBdUIsRUFDckIsNEJBQ0k7R0FDSixJQUFJLENBQUMsdUJBQXVCO0lBQzFCLE1BQU0sSUFBSSxNQUFNLGlEQUFpRDtHQUNuRTtHQUNBLE9BQU8sb0VBQW9FLGtDQUFrQyxzQkFBc0I7RUFDckk7RUFDQSxzQkFBc0IsRUFDcEIsNEJBQ0k7R0FDSixJQUFJLENBQUMsdUJBQXVCO0lBQzFCLE1BQU0sSUFBSSxNQUFNLGdEQUFnRDtHQUNsRTtHQUNBLE9BQU8sbUVBQW1FLGtFQUFrRSxJQUFJLHNCQUFzQjtFQUN4SztFQUNBLHlCQUF5QixFQUN2Qiw0QkFDSTtHQUNKLElBQUksQ0FBQyx1QkFBdUI7SUFDMUIsTUFBTSxJQUFJLE1BQU0sbURBQW1EO0dBQ3JFO0dBQ0EsT0FBTyxxRUFBcUUsa0VBQWtFLElBQUksc0JBQXNCO0VBQzFLO0VBQ0EseUJBQXlCO0dBQ3ZCLE9BQU87RUFDVDtFQUNBLDBCQUEwQixFQUN4QixNQUNBLE9BQ0EsVUFDSTtHQUNKLE9BQU8sY0FBYyxNQUFNLGFBQWEsSUFBSSw4QkFBOEIsb0RBQW9ELEtBQUs7RUFDckk7RUFDQSxxQ0FBcUMsRUFDbkMsS0FDQSxhQUNJO0dBQ0osT0FBTyxvQkFBb0IsSUFBSSxxQkFBcUIsT0FBTyxrQkFBa0I7RUFDL0U7RUFDQSwrQkFBK0IsRUFDN0IsVUFDSTtHQUNKLE9BQU8sa0NBQWtDLElBQUksK0JBQStCO0VBQzlFO0VBQ0EsZ0JBQWdCLEVBQ2QsS0FDQSxZQUNJO0dBQ0osSUFBSSxVQUFVLG1EQUFtRCxJQUFJO0dBQ3JFLElBQUksT0FBTztJQUNULFdBQVcsNEJBQTRCLE1BQU07R0FDL0M7R0FDQSxPQUFPO0VBQ1Q7RUFDQSw0QkFBNEIsRUFDMUIsS0FDQSxhQUNJO0dBQ0osT0FBTywrQkFBK0IsSUFBSSxhQUFhLFNBQVMsMkJBQTJCLE9BQU8sS0FBSztFQUN6RztFQUNBLHNCQUFzQixFQUNwQixVQUNJO0dBQ0osT0FBTyw0QkFBNEIsSUFBSSxtQ0FBbUM7RUFDNUU7RUFDQSw4Q0FBOEMsRUFDNUMsVUFDSTtHQUNKLE9BQU8sa0NBQWtDLDBFQUEwRSxHQUFHLElBQUk7RUFDNUg7RUFDQSwyQkFBMkIsRUFDekIsV0FDQSxVQUNJO0dBQ0osT0FBTywwQ0FBMEMsVUFBVSxPQUFPLElBQUk7RUFDeEU7RUFDQSwrQkFBK0IsRUFDN0IsYUFDSTtHQUNKLE9BQU8sbUVBQW1FLG1EQUFtRCxPQUFPO0VBQ3RJO0VBQ0EsMEJBQTBCLEVBQ3hCLFdBQ0k7R0FDSixNQUFNLFVBQVUsdURBQXVELElBQUksS0FBSztHQUNoRixJQUFJLFNBQVMsa0JBQWtCO0lBQzdCLE9BQU8sR0FBRyxRQUFRLHlEQUF5RDtHQUM3RTtHQUNBLE9BQU8sR0FBRyxRQUFRO0VBQ3BCO0NBQ0Y7Ozs7Ozs7O0NBU0EsTUFBTSxxQkFBcUIsTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNoRCxNQUFNLFVBQVUsU0FBUztFQUN6QixJQUFJLENBQUMsU0FBUztHQUNaLE1BQU0sSUFBSSxNQUFNLG9DQUFvQyxLQUFLLEdBQUc7RUFDOUQ7RUFDQSxPQUFPLFFBQVEsT0FBTztDQUN4QjtDQUNBLE1BQU0sbUJBQW1COzs7Ozs7Ozs7Ozs7Ozs7OztDQWtCekIsTUFBTSxxQkFBcUIsTUFBTTs7Ozs7Ozs7O0VBUy9CLFlBQVksV0FBVyxTQUFTO0dBQzlCLE1BQU0sVUFBVSxpQkFBaUIsV0FBVyxPQUFPO0dBQ25ELE1BQU0sT0FBTztHQUNiLEtBQUssT0FBTztHQUNaLEtBQUssVUFBVTtFQUNqQjtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLE1BQU0sV0FBVyxPQUFPLFlBQVk7RUFDbEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUc7R0FDekIsTUFBTSxJQUFJLGFBQWEsZ0JBQWdCLE9BQU87RUFDaEQ7Q0FDRjtDQUNBLE1BQU0sYUFBYSxRQUFRLGdCQUFnQixZQUFZO0VBQ3JELE1BQU0sT0FBTyxPQUFPLE9BQU87RUFDM0IsSUFBSSxTQUFTLFlBQVk7R0FDdkIsUUFBUSxvQkFBb0I7R0FDNUIsTUFBTSxJQUFJLGFBQWEsb0JBQW9CLE9BQU87RUFDcEQ7Q0FDRjtDQUNBLE1BQU0sVUFBVSxRQUFRLGNBQWMsWUFBWTtFQUNoRCxJQUFJLE9BQU8sV0FBVyxjQUFjO0dBQ2xDLFFBQVEsa0JBQWtCO0dBQzFCLE1BQU0sSUFBSSxhQUFhLGtCQUFrQixPQUFPO0VBQ2xEO0NBQ0Y7Q0FDQSxNQUFNLGNBQWMsUUFHcEIsZUFBZSxZQUFZO0VBQ3pCLElBQUksRUFBRSxrQkFBa0IsZ0JBQWdCO0dBQ3RDLFFBQVEsdUJBQXVCLGNBQWM7R0FDN0MsTUFBTSxJQUFJLGFBQWEsbUJBQW1CLE9BQU87RUFDbkQ7Q0FDRjtDQUNBLE1BQU0sV0FBVyxPQUFPLGFBQWEsWUFBWTtFQUMvQyxJQUFJLENBQUMsWUFBWSxTQUFTLEtBQUssR0FBRztHQUNoQyxRQUFRLDJCQUEyQixvQkFBb0IsS0FBSyxVQUFVLFdBQVcsRUFBRTtHQUNuRixNQUFNLElBQUksYUFBYSxpQkFBaUIsT0FBTztFQUNqRDtDQUNGO0NBQ0EsTUFBTSxrQkFBa0IsT0FFeEIsZUFFQSxZQUFZO0VBQ1YsTUFBTSxRQUFRLElBQUksYUFBYSxzQkFBc0IsT0FBTztFQUM1RCxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssR0FBRztHQUN6QixNQUFNO0VBQ1I7RUFDQSxLQUFLLE1BQU0sUUFBUSxPQUFPO0dBQ3hCLElBQUksRUFBRSxnQkFBZ0IsZ0JBQWdCO0lBQ3BDLE1BQU07R0FDUjtFQUNGO0NBQ0Y7Q0FDQSxNQUFNLHFCQUFxQjtFQUN6QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjs7Q0FHQSxJQUFJO0VBQ0YsS0FBSyw0QkFBNEIsRUFBRTtDQUNyQyxTQUFTLEdBQUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCYixNQUFNLGdCQUFnQjs7Ozs7Ozs7Q0FRdEIsTUFBTSxlQUFlO0VBQUM7RUFBVTtFQUFPO0VBQVE7RUFBUztFQUFRO0NBQUs7Ozs7Ozs7Ozs7Ozs7OztDQWdCckUsTUFBTSxvQkFBbUIsWUFBVztFQUNsQyxJQUFJLFdBQVcsT0FBTyxZQUFZLFVBQVU7R0FDMUM7SUFDRSxtQkFBbUIsVUFBVSxTQUFTLFVBQVU7S0FDOUMsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVCxPQUFPO0dBQ0w7SUFDRSxtQkFBbUIsT0FBTyxTQUFTLFlBQVk7S0FDN0MsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLE9BQU8sRUFDTCxRQUFRLFFBQ1Y7RUFDRjtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxNQUFNLE1BQU07Ozs7Ozs7Ozs7OztFQVlWLFlBQVksT0FBTyxTQUFTLFNBQVMsZUFBZTtHQUNsRDtJQUNFLG1CQUFtQixPQUFPLE9BQU8sWUFBWTtLQUMzQyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELElBQUksUUFBUTtLQUNWLG1CQUFtQixRQUFRLFFBQVEsY0FBYyxFQUMvQyxXQUFXLFNBQ2IsQ0FBQztJQUNIO0dBQ0Y7OztHQUdBLEtBQUssVUFBVSxpQkFBaUIsT0FBTztHQUN2QyxLQUFLLFFBQVE7R0FDYixLQUFLLFNBQVM7RUFDaEI7Ozs7OztFQU1BLGdCQUFnQixTQUFTO0dBQ3ZCLEtBQUssZUFBZSxpQkFBaUIsT0FBTztFQUM5QztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLE1BQU0sb0JBQW9CLE1BQU07Ozs7Ozs7Ozs7Ozs7O0VBYzlCLFlBQVksUUFBUSxTQUFTLFFBQVE7R0FDbkM7SUFDRSxtQkFBbUIsV0FBVyxRQUFRLFFBQVE7S0FDNUMsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLE1BQU0sU0FBUyxFQUNiLFVBQ0k7SUFDSixNQUFNLFNBQVMsT0FBTyxLQUFLLElBQUksSUFBSTs7SUFFbkMsSUFBSSxDQUFDLFFBQVE7S0FDWDtJQUNGOzs7OztJQUtBLElBQUksSUFBSSxXQUFXLFNBQVMsVUFBVSxPQUFPLFVBQVUsR0FBRztLQUN4RDtNQUNFLE9BQU8sTUFBTSwyQkFBMkIsT0FBTyxTQUFTLEVBQUUsNkJBQTZCLGlDQUFpQyxJQUFJLFNBQVMsRUFBRSwrQkFBK0IsNERBQTREO0tBQ3BPO0tBQ0E7SUFDRjs7Ozs7SUFLQSxPQUFPLE9BQU8sTUFBTSxDQUFDO0dBQ3ZCO0dBQ0EsTUFBTSxPQUFPLFNBQVMsTUFBTTtFQUM5QjtDQUNGOzs7Ozs7OztDQVNBLE1BQU0sa0JBQWlCLFFBQU87RUFDNUIsTUFBTSxTQUFTLElBQUksSUFBSSxPQUFPLEdBQUcsR0FBRyxTQUFTLElBQUk7OztFQUdqRCxPQUFPLE9BQU8sS0FBSyxRQUFRLElBQUksT0FBTyxJQUFJLFNBQVMsUUFBUSxHQUFHLEVBQUU7Q0FDbEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQkEsTUFBTSxPQUFPOzs7O0VBSVgsY0FBYztHQUNaLEtBQUssVUFBVSxJQUFJLElBQUk7R0FDdkIsS0FBSyxxQkFBcUIsSUFBSSxJQUFJO0VBQ3BDOzs7Ozs7RUFNQSxJQUFJLFNBQVM7R0FDWCxPQUFPLEtBQUs7RUFDZDs7Ozs7RUFLQSxtQkFBbUI7O0dBRWpCLEtBQUssaUJBQWlCLFVBQVMsVUFBUztJQUN0QyxNQUFNLEVBQ0osWUFDRTtJQUNKLE1BQU0sa0JBQWtCLEtBQUssY0FBYztLQUN6QztLQUNBO0lBQ0YsQ0FBQztJQUNELElBQUksaUJBQWlCO0tBQ25CLE1BQU0sWUFBWSxlQUFlO0lBQ25DO0dBQ0YsQ0FBQztFQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXVCQSxtQkFBbUI7O0dBRWpCLEtBQUssaUJBQWlCLFlBQVcsVUFBUzs7O0lBR3hDLElBQUksTUFBTSxRQUFRLE1BQU0sS0FBSyxTQUFTLGNBQWM7O0tBRWxELE1BQU0sRUFDSixZQUNFLE1BQU07S0FDVjtNQUNFLE9BQU8sTUFBTSxnQ0FBZ0MsUUFBUSxXQUFXO0tBQ2xFO0tBQ0EsTUFBTSxrQkFBa0IsUUFBUSxJQUFJLFFBQVEsWUFBWSxLQUFJLFVBQVM7TUFDbkUsSUFBSSxPQUFPLFVBQVUsVUFBVTtPQUM3QixRQUFRLENBQUMsS0FBSztNQUNoQjtNQUNBLE1BQU0sVUFBVSxJQUFJLFFBQVEsR0FBRyxLQUFLO01BQ3BDLE9BQU8sS0FBSyxjQUFjO09BQ3hCO09BQ0E7TUFDRixDQUFDOzs7O0tBSUgsQ0FBQyxDQUFDO0tBQ0YsTUFBTSxVQUFVLGVBQWU7O0tBRS9CLElBQUksTUFBTSxTQUFTLE1BQU0sTUFBTSxJQUFJO01BQ2pDLEtBQUssZ0JBQWdCLFdBQVcsTUFBTSxNQUFNLEVBQUUsQ0FBQyxZQUFZLElBQUksQ0FBQztLQUNsRTtJQUNGO0dBQ0YsQ0FBQztFQUNIOzs7Ozs7Ozs7Ozs7O0VBYUEsY0FBYyxFQUNaLFNBQ0EsU0FDQztHQUNEO0lBQ0UsbUJBQW1CLFdBQVcsU0FBUyxTQUFTO0tBQzlDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxNQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsS0FBSyxTQUFTLElBQUk7R0FDOUMsSUFBSSxDQUFDLElBQUksU0FBUyxXQUFXLE1BQU0sR0FBRztJQUNwQztLQUNFLE9BQU8sTUFBTSwyREFBMkQ7SUFDMUU7SUFDQTtHQUNGO0dBQ0EsTUFBTSxhQUFhLElBQUksV0FBVyxTQUFTO0dBQzNDLE1BQU0sRUFDSixRQUNBLFVBQ0UsS0FBSyxrQkFBa0I7SUFDekI7SUFDQTtJQUNBO0lBQ0E7R0FDRixDQUFDO0dBQ0QsSUFBSSxVQUFVLFNBQVMsTUFBTTtHQUM3QixNQUFNLGdCQUFnQixDQUFDO0dBQ3ZCO0lBQ0UsSUFBSSxTQUFTO0tBQ1gsY0FBYyxLQUFLLENBQUMseUNBQXlDLEtBQUssQ0FBQztLQUNuRSxJQUFJLFFBQVE7TUFDVixjQUFjLEtBQUssQ0FBQyx3REFBd0QsTUFBTSxDQUFDO0tBQ3JGO0lBQ0Y7R0FDRjs7O0dBR0EsTUFBTSxTQUFTLFFBQVE7R0FDdkIsSUFBSSxDQUFDLFdBQVcsS0FBSyxtQkFBbUIsSUFBSSxNQUFNLEdBQUc7SUFDbkQ7S0FDRSxjQUFjLEtBQUssOENBQThDLG1DQUFtQyxPQUFPLEVBQUU7SUFDL0c7SUFDQSxVQUFVLEtBQUssbUJBQW1CLElBQUksTUFBTTtHQUM5QztHQUNBLElBQUksQ0FBQyxTQUFTO0lBQ1o7OztLQUdFLE9BQU8sTUFBTSx1QkFBdUIsZUFBZSxHQUFHLEdBQUc7SUFDM0Q7SUFDQTtHQUNGO0dBQ0E7OztJQUdFLE9BQU8sZUFBZSw0QkFBNEIsZUFBZSxHQUFHLEdBQUc7SUFDdkUsY0FBYyxTQUFRLFFBQU87S0FDM0IsSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO01BQ3RCLE9BQU8sSUFBSSxHQUFHLEdBQUc7S0FDbkIsT0FBTztNQUNMLE9BQU8sSUFBSSxHQUFHO0tBQ2hCO0lBQ0YsQ0FBQztJQUNELE9BQU8sU0FBUztHQUNsQjs7O0dBR0EsSUFBSTtHQUNKLElBQUk7SUFDRixrQkFBa0IsUUFBUSxPQUFPO0tBQy9CO0tBQ0E7S0FDQTtLQUNBO0lBQ0YsQ0FBQztHQUNILFNBQVMsS0FBSztJQUNaLGtCQUFrQixRQUFRLE9BQU8sR0FBRztHQUN0Qzs7R0FFQSxNQUFNLGVBQWUsU0FBUyxNQUFNO0dBQ3BDLElBQUksMkJBQTJCLFlBQVksS0FBSyxpQkFBaUIsZUFBZTtJQUM5RSxrQkFBa0IsZ0JBQWdCLE1BQU0sT0FBTSxRQUFPOztLQUVuRCxJQUFJLGNBQWM7TUFDaEI7OztPQUdFLE9BQU8sZUFBZSxzQ0FBc0MsSUFBSSxlQUFlLEdBQUcsRUFBRSx5Q0FBeUM7T0FDN0gsT0FBTyxNQUFNLG9CQUFvQixLQUFLO09BQ3RDLE9BQU8sTUFBTSxHQUFHO09BQ2hCLE9BQU8sU0FBUztNQUNsQjtNQUNBLElBQUk7T0FDRixPQUFPLE1BQU0sYUFBYSxPQUFPO1FBQy9CO1FBQ0E7UUFDQTtRQUNBO09BQ0YsQ0FBQztNQUNILFNBQVMsVUFBVTtPQUNqQixJQUFJLG9CQUFvQixPQUFPO1FBQzdCLE1BQU07T0FDUjtNQUNGO0tBQ0Y7S0FDQSxJQUFJLEtBQUssZUFBZTtNQUN0Qjs7O09BR0UsT0FBTyxlQUFlLHNDQUFzQyxJQUFJLGVBQWUsR0FBRyxFQUFFLHdDQUF3QztPQUM1SCxPQUFPLE1BQU0sb0JBQW9CLEtBQUs7T0FDdEMsT0FBTyxNQUFNLEdBQUc7T0FDaEIsT0FBTyxTQUFTO01BQ2xCO01BQ0EsT0FBTyxLQUFLLGNBQWMsT0FBTztPQUMvQjtPQUNBO09BQ0E7TUFDRixDQUFDO0tBQ0g7S0FDQSxNQUFNO0lBQ1IsQ0FBQztHQUNIO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7O0VBZ0JBLGtCQUFrQixFQUNoQixLQUNBLFlBQ0EsU0FDQSxTQUNDO0dBQ0QsTUFBTSxTQUFTLEtBQUssUUFBUSxJQUFJLFFBQVEsTUFBTSxLQUFLLENBQUM7R0FDcEQsS0FBSyxNQUFNLFNBQVMsUUFBUTtJQUMxQixJQUFJOzs7SUFHSixNQUFNLGNBQWMsTUFBTSxNQUFNO0tBQzlCO0tBQ0E7S0FDQTtLQUNBO0lBQ0YsQ0FBQztJQUNELElBQUksYUFBYTtLQUNmOzs7TUFHRSxJQUFJLHVCQUF1QixTQUFTO09BQ2xDLE9BQU8sS0FBSyxpQkFBaUIsZUFBZSxHQUFHLEVBQUUsZUFBZSx5REFBeUQsZ0VBQWdFLEtBQUs7TUFDaE07S0FDRjs7O0tBR0EsU0FBUztLQUNULElBQUksTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLFdBQVcsR0FBRzs7TUFFaEQsU0FBUztLQUNYLE9BQU8sSUFBSSxZQUFZLGdCQUFnQixVQUV2QyxPQUFPLEtBQUssV0FBVyxDQUFDLENBQUMsV0FBVyxHQUFHOztNQUVyQyxTQUFTO0tBQ1gsT0FBTyxJQUFJLE9BQU8sZ0JBQWdCLFdBQVc7Ozs7TUFJM0MsU0FBUztLQUNYOztLQUVBLE9BQU87TUFDTDtNQUNBO0tBQ0Y7SUFDRjtHQUNGOztHQUVBLE9BQU8sQ0FBQztFQUNWOzs7Ozs7Ozs7Ozs7Ozs7RUFlQSxrQkFBa0IsU0FBUyxTQUFTLGVBQWU7R0FDakQsS0FBSyxtQkFBbUIsSUFBSSxRQUFRLGlCQUFpQixPQUFPLENBQUM7RUFDL0Q7Ozs7Ozs7O0VBUUEsZ0JBQWdCLFNBQVM7R0FDdkIsS0FBSyxnQkFBZ0IsaUJBQWlCLE9BQU87RUFDL0M7Ozs7OztFQU1BLGNBQWMsT0FBTztHQUNuQjtJQUNFLG1CQUFtQixPQUFPLE9BQU8sVUFBVTtLQUN6QyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELG1CQUFtQixVQUFVLE9BQU8sU0FBUztLQUMzQyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELG1CQUFtQixPQUFPLE1BQU0sU0FBUyxVQUFVO0tBQ2pELFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0lBQ0QsbUJBQW1CLFVBQVUsTUFBTSxTQUFTLFVBQVU7S0FDcEQsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxtQkFBbUIsT0FBTyxNQUFNLFFBQVEsVUFBVTtLQUNoRCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsSUFBSSxDQUFDLEtBQUssUUFBUSxJQUFJLE1BQU0sTUFBTSxHQUFHO0lBQ25DLEtBQUssUUFBUSxJQUFJLE1BQU0sUUFBUSxDQUFDLENBQUM7R0FDbkM7OztHQUdBLEtBQUssUUFBUSxJQUFJLE1BQU0sTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLO0VBQzNDOzs7Ozs7RUFNQSxnQkFBZ0IsT0FBTztHQUNyQixJQUFJLENBQUMsS0FBSyxRQUFRLElBQUksTUFBTSxNQUFNLEdBQUc7SUFDbkMsTUFBTSxJQUFJLGFBQWEsOENBQThDLEVBQ25FLFFBQVEsTUFBTSxPQUNoQixDQUFDO0dBQ0g7R0FDQSxNQUFNLGFBQWEsS0FBSyxRQUFRLElBQUksTUFBTSxNQUFNLENBQUMsQ0FBQyxRQUFRLEtBQUs7R0FDL0QsSUFBSSxhQUFhLENBQUMsR0FBRztJQUNuQixLQUFLLFFBQVEsSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDLE9BQU8sWUFBWSxDQUFDO0dBQ3JELE9BQU87SUFDTCxNQUFNLElBQUksYUFBYSx1Q0FBdUM7R0FDaEU7RUFDRjtDQUNGOzs7Ozs7OztDQVNBLElBQUk7Ozs7Ozs7O0NBUUosTUFBTSxpQ0FBaUM7RUFDckMsSUFBSSxDQUFDLGVBQWU7R0FDbEIsZ0JBQWdCLElBQUksT0FBTzs7R0FFM0IsY0FBYyxpQkFBaUI7R0FDL0IsY0FBYyxpQkFBaUI7RUFDakM7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJBLFNBQVMsY0FBYyxTQUFTLFNBQVMsUUFBUTtFQUMvQyxJQUFJO0VBQ0osSUFBSSxPQUFPLFlBQVksVUFBVTtHQUMvQixNQUFNLGFBQWEsSUFBSSxJQUFJLFNBQVMsU0FBUyxJQUFJO0dBQ2pEO0lBQ0UsSUFBSSxFQUFFLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxXQUFXLE1BQU0sSUFBSTtLQUM1RCxNQUFNLElBQUksYUFBYSxrQkFBa0I7TUFDdkMsWUFBWTtNQUNaLFVBQVU7TUFDVixXQUFXO0tBQ2IsQ0FBQztJQUNIOzs7SUFHQSxNQUFNLGVBQWUsUUFBUSxXQUFXLE1BQU0sSUFBSSxXQUFXLFdBQVc7O0lBRXhFLE1BQU0sWUFBWTtJQUNsQixJQUFJLElBQUksT0FBTyxHQUFHLFdBQVcsQ0FBQyxDQUFDLEtBQUssWUFBWSxHQUFHO0tBQ2pELE9BQU8sTUFBTSxpRUFBaUUsY0FBYyxVQUFVLDZDQUE2Qyw4REFBOEQ7SUFDbk47R0FDRjtHQUNBLE1BQU0saUJBQWlCLEVBQ3JCLFVBQ0k7SUFDSjtLQUNFLElBQUksSUFBSSxhQUFhLFdBQVcsWUFBWSxJQUFJLFdBQVcsV0FBVyxRQUFRO01BQzVFLE9BQU8sTUFBTSxHQUFHLFFBQVEsaURBQWlELEdBQUcsSUFBSSxTQUFTLEVBQUUsd0RBQXdELCtCQUErQjtLQUNwTDtJQUNGO0lBQ0EsT0FBTyxJQUFJLFNBQVMsV0FBVztHQUNqQzs7R0FFQSxRQUFRLElBQUksTUFBTSxlQUFlLFNBQVMsTUFBTTtFQUNsRCxPQUFPLElBQUksbUJBQW1CLFFBQVE7O0dBRXBDLFFBQVEsSUFBSSxZQUFZLFNBQVMsU0FBUyxNQUFNO0VBQ2xELE9BQU8sSUFBSSxPQUFPLFlBQVksWUFBWTs7R0FFeEMsUUFBUSxJQUFJLE1BQU0sU0FBUyxTQUFTLE1BQU07RUFDNUMsT0FBTyxJQUFJLG1CQUFtQixPQUFPO0dBQ25DLFFBQVE7RUFDVixPQUFPO0dBQ0wsTUFBTSxJQUFJLGFBQWEsMEJBQTBCO0lBQy9DLFlBQVk7SUFDWixVQUFVO0lBQ1YsV0FBVztHQUNiLENBQUM7RUFDSDtFQUNBLE1BQU0sZ0JBQWdCLHlCQUF5QjtFQUMvQyxjQUFjLGNBQWMsS0FBSztFQUNqQyxPQUFPO0NBQ1Q7Ozs7Ozs7O0NBU0EsTUFBTSxvQkFBb0I7RUFDeEIsaUJBQWlCO0VBQ2pCLFVBQVU7RUFDVixRQUFRO0VBQ1IsU0FBUztFQUNULFFBQVEsT0FBTyxpQkFBaUIsY0FBYyxhQUFhLFFBQVE7Q0FDckU7Q0FDQSxNQUFNLG9CQUFtQixjQUFhO0VBQ3BDLE9BQU87R0FBQyxrQkFBa0I7R0FBUTtHQUFXLGtCQUFrQjtFQUFNLENBQUMsQ0FBQyxRQUFPLFVBQVMsU0FBUyxNQUFNLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQzVIO0NBQ0EsTUFBTSx1QkFBc0IsT0FBTTtFQUNoQyxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssaUJBQWlCLEdBQUc7R0FDaEQsR0FBRyxHQUFHO0VBQ1I7Q0FDRjtDQUNBLE1BQU0sYUFBYTtFQUNqQixnQkFBZSxZQUFXO0dBQ3hCLHFCQUFvQixRQUFPO0lBQ3pCLElBQUksT0FBTyxRQUFRLFNBQVMsVUFBVTtLQUNwQyxrQkFBa0IsT0FBTyxRQUFRO0lBQ25DO0dBQ0YsQ0FBQztFQUNIO0VBQ0EseUJBQXdCLGtCQUFpQjtHQUN2QyxPQUFPLGlCQUFpQixpQkFBaUIsa0JBQWtCLGVBQWU7RUFDNUU7RUFDQSxrQkFBaUIsa0JBQWlCO0dBQ2hDLE9BQU8saUJBQWlCLGlCQUFpQixrQkFBa0IsUUFBUTtFQUNyRTtFQUNBLGlCQUFpQjtHQUNmLE9BQU8sa0JBQWtCO0VBQzNCO0VBQ0EsaUJBQWdCLGtCQUFpQjtHQUMvQixPQUFPLGlCQUFpQixpQkFBaUIsa0JBQWtCLE9BQU87RUFDcEU7RUFDQSxpQkFBaUI7R0FDZixPQUFPLGtCQUFrQjtFQUMzQjtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFNBQVMsVUFBVSxPQUFPLFNBQVM7RUFDakMsTUFBTSxnQkFBZ0IsUUFBUTtFQUM5QixNQUFNLFVBQVUsYUFBYTtFQUM3QixPQUFPO0NBQ1Q7O0NBR0EsSUFBSTtFQUNGLEtBQUssK0JBQStCLEVBQUU7Q0FDeEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7OztDQVViLE1BQU0sd0JBQXdCOzs7Ozs7Ozs7O0NBVTlCLFNBQVMsZUFBZSxPQUFPO0VBQzdCLElBQUksQ0FBQyxPQUFPO0dBQ1YsTUFBTSxJQUFJLGFBQWEscUNBQXFDLEVBQzFELE1BQ0YsQ0FBQztFQUNIOzs7RUFHQSxJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzdCLE1BQU0sWUFBWSxJQUFJLElBQUksT0FBTyxTQUFTLElBQUk7R0FDOUMsT0FBTztJQUNMLFVBQVUsVUFBVTtJQUNwQixLQUFLLFVBQVU7R0FDakI7RUFDRjtFQUNBLE1BQU0sRUFDSixVQUNBLFFBQ0U7RUFDSixJQUFJLENBQUMsS0FBSztHQUNSLE1BQU0sSUFBSSxhQUFhLHFDQUFxQyxFQUMxRCxNQUNGLENBQUM7RUFDSDs7O0VBR0EsSUFBSSxDQUFDLFVBQVU7R0FDYixNQUFNLFlBQVksSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJO0dBQzVDLE9BQU87SUFDTCxVQUFVLFVBQVU7SUFDcEIsS0FBSyxVQUFVO0dBQ2pCO0VBQ0Y7OztFQUdBLE1BQU0sY0FBYyxJQUFJLElBQUksS0FBSyxTQUFTLElBQUk7RUFDOUMsTUFBTSxjQUFjLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSTtFQUM5QyxZQUFZLGFBQWEsSUFBSSx1QkFBdUIsUUFBUTtFQUM1RCxPQUFPO0dBQ0wsVUFBVSxZQUFZO0dBQ3RCLEtBQUssWUFBWTtFQUNuQjtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLE1BQU0sNEJBQTRCO0VBQ2hDLGNBQWM7R0FDWixLQUFLLGNBQWMsQ0FBQztHQUNwQixLQUFLLGlCQUFpQixDQUFDO0dBQ3ZCLEtBQUssbUJBQW1CLE9BQU8sRUFDN0IsU0FDQSxZQUNJOztJQUVKLElBQUksT0FBTztLQUNULE1BQU0sa0JBQWtCO0lBQzFCO0dBQ0Y7R0FDQSxLQUFLLDJCQUEyQixPQUFPLEVBQ3JDLE9BQ0EsT0FDQSxxQkFDSTtJQUNKLElBQUksTUFBTSxTQUFTLFdBQVc7S0FDNUIsSUFBSSxTQUFTLE1BQU0sbUJBQW1CLE1BQU0sMkJBQTJCLFNBQVM7O01BRTlFLE1BQU0sTUFBTSxNQUFNLGdCQUFnQjtNQUNsQyxJQUFJLGdCQUFnQjtPQUNsQixLQUFLLGVBQWUsS0FBSyxHQUFHO01BQzlCLE9BQU87T0FDTCxLQUFLLFlBQVksS0FBSyxHQUFHO01BQzNCO0tBQ0Y7SUFDRjtJQUNBLE9BQU87R0FDVDtFQUNGO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7O0NBZUEsTUFBTSx1QkFBdUI7RUFDM0IsWUFBWSxFQUNWLHNCQUNDO0dBQ0QsS0FBSyxxQkFBcUIsT0FBTyxFQUMvQixTQUNBLGFBQ0k7OztJQUdKLE1BQU0sWUFBWSxXQUFXLFFBQVEsV0FBVyxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sYUFBYSxLQUFLLG9CQUFvQixrQkFBa0IsUUFBUSxHQUFHOztJQUU1SSxPQUFPLFdBQVcsSUFBSSxRQUFRLFVBQVUsRUFDdEMsU0FBUyxRQUFRLFFBQ25CLENBQUMsSUFBSTtHQUNQO0dBQ0EsS0FBSyxzQkFBc0I7RUFDN0I7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxNQUFNLFlBQVksWUFBWSxnQkFBZ0I7RUFDNUMsT0FBTyxlQUFlLFVBQVU7RUFDaEMsS0FBSyxNQUFNLE9BQU8sYUFBYTtHQUM3QixPQUFPLElBQUksR0FBRztFQUNoQjtFQUNBLE9BQU8sU0FBUztDQUNsQjs7Ozs7OztDQU9BLFNBQVMsb0JBQW9CLGFBQWE7RUFDeEMsTUFBTSxnQkFBZ0IsWUFBWTtFQUNsQyxJQUFJLGdCQUFnQixHQUFHO0dBQ3JCLE9BQU8sZUFBZSxnQ0FBZ0MsR0FBRyxjQUFjLFlBQVksVUFBVSxrQkFBa0IsSUFBSSxTQUFTLFNBQVMsVUFBVTtHQUMvSSxTQUFTLDBCQUEwQixXQUFXO0dBQzlDLE9BQU8sU0FBUztFQUNsQjtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLFNBQVMsYUFBYSxZQUFZLE1BQU07RUFDdEMsSUFBSSxLQUFLLFdBQVcsR0FBRztHQUNyQjtFQUNGO0VBQ0EsT0FBTyxlQUFlLFVBQVU7RUFDaEMsS0FBSyxNQUFNLE9BQU8sTUFBTTtHQUN0QixPQUFPLElBQUksR0FBRztFQUNoQjtFQUNBLE9BQU8sU0FBUztDQUNsQjs7Ozs7Ozs7Q0FRQSxTQUFTLG9CQUFvQixnQkFBZ0Isc0JBQXNCO0VBQ2pFLE1BQU0saUJBQWlCLGVBQWU7RUFDdEMsTUFBTSx3QkFBd0IscUJBQXFCO0VBQ25ELElBQUksa0JBQWtCLHVCQUF1QjtHQUMzQyxJQUFJLFVBQVUsY0FBYyxlQUFlLE9BQU8sbUJBQW1CLElBQUksS0FBSyxJQUFJO0dBQ2xGLElBQUksd0JBQXdCLEdBQUc7SUFDN0IsV0FBVyxJQUFJLHNCQUFzQixLQUFLLE9BQU8sMEJBQTBCLElBQUksUUFBUSxRQUFRO0dBQ2pHO0dBQ0EsT0FBTyxlQUFlLE9BQU87R0FDN0IsYUFBYSw4QkFBOEIsY0FBYztHQUN6RCxhQUFhLG1DQUFtQyxvQkFBb0I7R0FDcEUsT0FBTyxTQUFTO0VBQ2xCO0NBQ0Y7Ozs7Ozs7O0NBU0EsSUFBSTs7Ozs7Ozs7OztDQVVKLFNBQVMscUNBQXFDO0VBQzVDLElBQUksa0JBQWtCLFdBQVc7R0FDL0IsTUFBTSxlQUFlLElBQUksU0FBUyxFQUFFO0dBQ3BDLElBQUksVUFBVSxjQUFjO0lBQzFCLElBQUk7S0FDRixJQUFJLFNBQVMsYUFBYSxJQUFJO0tBQzlCLGdCQUFnQjtJQUNsQixTQUFTLE9BQU87S0FDZCxnQkFBZ0I7SUFDbEI7R0FDRjtHQUNBLGdCQUFnQjtFQUNsQjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNEJBLGVBQWUsYUFBYSxVQUFVLFVBQVU7RUFDOUMsSUFBSSxTQUFTOztFQUViLElBQUksU0FBUyxLQUFLO0dBQ2hCLE1BQU0sY0FBYyxJQUFJLElBQUksU0FBUyxHQUFHO0dBQ3hDLFNBQVMsWUFBWTtFQUN2QjtFQUNBLElBQUksV0FBVyxLQUFLLFNBQVMsUUFBUTtHQUNuQyxNQUFNLElBQUksYUFBYSw4QkFBOEIsRUFDbkQsT0FDRixDQUFDO0VBQ0g7RUFDQSxNQUFNLGlCQUFpQixTQUFTLE1BQU07O0VBRXRDLE1BQU0sZUFBZTtHQUNuQixTQUFTLElBQUksUUFBUSxlQUFlLE9BQU87R0FDM0MsUUFBUSxlQUFlO0dBQ3ZCLFlBQVksZUFBZTtFQUM3Qjs7RUFFQSxNQUFNLHVCQUF1Qjs7OztFQUk3QixNQUFNLE9BQU8sbUNBQW1DLElBQUksZUFBZSxPQUFPLE1BQU0sZUFBZSxLQUFLO0VBQ3BHLE9BQU8sSUFBSSxTQUFTLE1BQU0sb0JBQW9CO0NBQ2hEOzs7Ozs7O0NBUUEsU0FBUyxZQUFZLFNBQVMsY0FBYztFQUMxQyxNQUFNLGNBQWMsSUFBSSxJQUFJLE9BQU87RUFDbkMsS0FBSyxNQUFNLFNBQVMsY0FBYztHQUNoQyxZQUFZLGFBQWEsT0FBTyxLQUFLO0VBQ3ZDO0VBQ0EsT0FBTyxZQUFZO0NBQ3JCOzs7Ozs7Ozs7Ozs7O0NBYUEsZUFBZSx1QkFBdUIsT0FBTyxTQUFTLGNBQWMsY0FBYztFQUNoRixNQUFNLHFCQUFxQixZQUFZLFFBQVEsS0FBSyxZQUFZOztFQUVoRSxJQUFJLFFBQVEsUUFBUSxvQkFBb0I7R0FDdEMsT0FBTyxNQUFNLE1BQU0sU0FBUyxZQUFZO0VBQzFDOztFQUVBLE1BQU0sY0FBYyxPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxZQUFZLEdBQUcsRUFDakUsY0FBYyxLQUNoQixDQUFDO0VBQ0QsTUFBTSxZQUFZLE1BQU0sTUFBTSxLQUFLLFNBQVMsV0FBVztFQUN2RCxLQUFLLE1BQU0sWUFBWSxXQUFXO0dBQ2hDLE1BQU0sc0JBQXNCLFlBQVksU0FBUyxLQUFLLFlBQVk7R0FDbEUsSUFBSSx1QkFBdUIscUJBQXFCO0lBQzlDLE9BQU8sTUFBTSxNQUFNLFVBQVUsWUFBWTtHQUMzQztFQUNGO0VBQ0E7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxNQUFNLFNBQVM7Ozs7RUFJYixjQUFjO0dBQ1osS0FBSyxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7SUFDOUMsS0FBSyxVQUFVO0lBQ2YsS0FBSyxTQUFTO0dBQ2hCLENBQUM7RUFDSDtDQUNGOzs7Ozs7Ozs7OztDQVlBLE1BQU0sc0JBQXNCLElBQUksSUFBSTs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JwQyxlQUFlLDZCQUE2QjtFQUMxQztHQUNFLE9BQU8sSUFBSSxnQkFBZ0Isb0JBQW9CLEtBQUssS0FBSywrQkFBK0I7RUFDMUY7RUFDQSxLQUFLLE1BQU0sWUFBWSxxQkFBcUI7R0FDMUMsTUFBTSxTQUFTO0dBQ2Y7SUFDRSxPQUFPLElBQUksVUFBVSxjQUFjO0dBQ3JDO0VBQ0Y7RUFDQTtHQUNFLE9BQU8sSUFBSSw2QkFBNkI7RUFDMUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFNBQVMsUUFBUSxJQUFJO0VBQ25CLE9BQU8sSUFBSSxTQUFRLFlBQVcsV0FBVyxTQUFTLEVBQUUsQ0FBQztDQUN2RDs7Q0FHQSxJQUFJO0VBQ0YsS0FBSywrQkFBK0IsRUFBRTtDQUN4QyxTQUFTLEdBQUcsQ0FBQzs7Ozs7Ozs7Q0FTYixTQUFTLFVBQVUsT0FBTztFQUN4QixPQUFPLE9BQU8sVUFBVSxXQUFXLElBQUksUUFBUSxLQUFLLElBQUk7Q0FDMUQ7Ozs7Ozs7Ozs7Q0FVQSxNQUFNLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFpQnBCLFlBQVksVUFBVSxTQUFTO0dBQzdCLEtBQUssYUFBYSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXNDbkI7SUFDRSxtQkFBbUIsV0FBVyxRQUFRLE9BQU8saUJBQWlCO0tBQzVELFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxPQUFPLE9BQU8sTUFBTSxPQUFPO0dBQzNCLEtBQUssUUFBUSxRQUFRO0dBQ3JCLEtBQUssWUFBWTtHQUNqQixLQUFLLG1CQUFtQixJQUFJLFNBQVM7R0FDckMsS0FBSywwQkFBMEIsQ0FBQzs7O0dBR2hDLEtBQUssV0FBVyxDQUFDLEdBQUcsU0FBUyxPQUFPO0dBQ3BDLEtBQUssa0JBQWtCLElBQUksSUFBSTtHQUMvQixLQUFLLE1BQU0sVUFBVSxLQUFLLFVBQVU7SUFDbEMsS0FBSyxnQkFBZ0IsSUFBSSxRQUFRLENBQUMsQ0FBQztHQUNyQztHQUNBLEtBQUssTUFBTSxVQUFVLEtBQUssaUJBQWlCLE9BQU87RUFDcEQ7Ozs7Ozs7Ozs7Ozs7O0VBY0EsTUFBTSxNQUFNLE9BQU87R0FDakIsTUFBTSxFQUNKLFVBQ0U7R0FDSixJQUFJLFVBQVUsVUFBVSxLQUFLO0dBQzdCLElBQUksUUFBUSxTQUFTLGNBQWMsaUJBQWlCLGNBQWMsTUFBTSxpQkFBaUI7SUFDdkYsTUFBTSwwQkFBMEIsTUFBTSxNQUFNO0lBQzVDLElBQUkseUJBQXlCO0tBQzNCO01BQ0UsT0FBTyxJQUFJLCtDQUErQyxJQUFJLGVBQWUsUUFBUSxHQUFHLEVBQUUsRUFBRTtLQUM5RjtLQUNBLE9BQU87SUFDVDtHQUNGOzs7O0dBSUEsTUFBTSxrQkFBa0IsS0FBSyxZQUFZLGNBQWMsSUFBSSxRQUFRLE1BQU0sSUFBSTtHQUM3RSxJQUFJO0lBQ0YsS0FBSyxNQUFNLE1BQU0sS0FBSyxpQkFBaUIsa0JBQWtCLEdBQUc7S0FDMUQsVUFBVSxNQUFNLEdBQUc7TUFDakIsU0FBUyxRQUFRLE1BQU07TUFDdkI7S0FDRixDQUFDO0lBQ0g7R0FDRixTQUFTLEtBQUs7SUFDWixJQUFJLGVBQWUsT0FBTztLQUN4QixNQUFNLElBQUksYUFBYSxtQ0FBbUMsRUFDeEQsb0JBQW9CLElBQUksUUFDMUIsQ0FBQztJQUNIO0dBQ0Y7Ozs7R0FJQSxNQUFNLHdCQUF3QixRQUFRLE1BQU07R0FDNUMsSUFBSTtJQUNGLElBQUk7O0lBRUosZ0JBQWdCLE1BQU0sTUFBTSxTQUFTLFFBQVEsU0FBUyxhQUFhLFlBQVksS0FBSyxVQUFVLFlBQVk7SUFDMUcsSUFBSSxrQkFBa0IsY0FBYztLQUNsQyxPQUFPLE1BQU0seUJBQXlCLElBQUksZUFBZSxRQUFRLEdBQUcsRUFBRSwrQkFBK0IsV0FBVyxjQUFjLE9BQU8sR0FBRztJQUMxSTtJQUNBLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLGlCQUFpQixHQUFHO0tBQy9ELGdCQUFnQixNQUFNLFNBQVM7TUFDN0I7TUFDQSxTQUFTO01BQ1QsVUFBVTtLQUNaLENBQUM7SUFDSDtJQUNBLE9BQU87R0FDVCxTQUFTLE9BQU87SUFDZDtLQUNFLE9BQU8sSUFBSSx5QkFBeUIsSUFBSSxlQUFlLFFBQVEsR0FBRyxFQUFFLG9CQUFvQixLQUFLO0lBQy9GOzs7SUFHQSxJQUFJLGlCQUFpQjtLQUNuQixNQUFNLEtBQUssYUFBYSxnQkFBZ0I7TUFDL0I7TUFDUDtNQUNBLGlCQUFpQixnQkFBZ0IsTUFBTTtNQUN2QyxTQUFTLHNCQUFzQixNQUFNO0tBQ3ZDLENBQUM7SUFDSDtJQUNBLE1BQU07R0FDUjtFQUNGOzs7Ozs7Ozs7OztFQVdBLE1BQU0saUJBQWlCLE9BQU87R0FDNUIsTUFBTSxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUs7R0FDdkMsTUFBTSxnQkFBZ0IsU0FBUyxNQUFNO0dBQ3JDLEtBQUssS0FBSyxVQUFVLEtBQUssU0FBUyxPQUFPLGFBQWEsQ0FBQztHQUN2RCxPQUFPO0VBQ1Q7Ozs7Ozs7Ozs7Ozs7RUFhQSxNQUFNLFdBQVcsS0FBSztHQUNwQixNQUFNLFVBQVUsVUFBVSxHQUFHO0dBQzdCLElBQUk7R0FDSixNQUFNLEVBQ0osV0FDQSxpQkFDRSxLQUFLO0dBQ1QsTUFBTSxtQkFBbUIsTUFBTSxLQUFLLFlBQVksU0FBUyxNQUFNO0dBQy9ELE1BQU0sb0JBQW9CLE9BQU8sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLFlBQVksR0FBRyxFQUN2RSxVQUNGLENBQUM7R0FDRCxpQkFBaUIsTUFBTSxPQUFPLE1BQU0sa0JBQWtCLGlCQUFpQjtHQUN2RTtJQUNFLElBQUksZ0JBQWdCO0tBQ2xCLE9BQU8sTUFBTSwrQkFBK0IsVUFBVSxHQUFHO0lBQzNELE9BQU87S0FDTCxPQUFPLE1BQU0sZ0NBQWdDLFVBQVUsR0FBRztJQUM1RDtHQUNGO0dBQ0EsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsMEJBQTBCLEdBQUc7SUFDeEUsaUJBQWtCLE1BQU0sU0FBUztLQUMvQjtLQUNBO0tBQ0E7S0FDQSxTQUFTO0tBQ1QsT0FBTyxLQUFLO0lBQ2QsQ0FBQyxLQUFNO0dBQ1Q7R0FDQSxPQUFPO0VBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7RUFnQkEsTUFBTSxTQUFTLEtBQUssVUFBVTtHQUM1QixNQUFNLFVBQVUsVUFBVSxHQUFHOzs7R0FHN0IsTUFBTSxRQUFRLENBQUM7R0FDZixNQUFNLG1CQUFtQixNQUFNLEtBQUssWUFBWSxTQUFTLE9BQU87R0FDaEU7SUFDRSxJQUFJLGlCQUFpQixVQUFVLGlCQUFpQixXQUFXLE9BQU87S0FDaEUsTUFBTSxJQUFJLGFBQWEsb0NBQW9DO01BQ3pELEtBQUssZUFBZSxpQkFBaUIsR0FBRztNQUN4QyxRQUFRLGlCQUFpQjtLQUMzQixDQUFDO0lBQ0g7O0lBRUEsTUFBTSxPQUFPLFNBQVMsUUFBUSxJQUFJLE1BQU07SUFDeEMsSUFBSSxNQUFNO0tBQ1IsT0FBTyxNQUFNLG9CQUFvQixlQUFlLGlCQUFpQixHQUFHLEVBQUUsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjLHFFQUFxRSwwREFBMEQ7SUFDL087R0FDRjtHQUNBLElBQUksQ0FBQyxVQUFVO0lBQ2I7S0FDRSxPQUFPLE1BQU0sNENBQTRDLElBQUksZUFBZSxpQkFBaUIsR0FBRyxFQUFFLEdBQUc7SUFDdkc7SUFDQSxNQUFNLElBQUksYUFBYSw4QkFBOEIsRUFDbkQsS0FBSyxlQUFlLGlCQUFpQixHQUFHLEVBQzFDLENBQUM7R0FDSDtHQUNBLE1BQU0sa0JBQWtCLE1BQU0sS0FBSywyQkFBMkIsUUFBUTtHQUN0RSxJQUFJLENBQUMsaUJBQWlCO0lBQ3BCO0tBQ0UsT0FBTyxNQUFNLGFBQWEsZUFBZSxpQkFBaUIsR0FBRyxFQUFFLE1BQU0sdUJBQXVCLGVBQWU7SUFDN0c7SUFDQSxPQUFPO0dBQ1Q7R0FDQSxNQUFNLEVBQ0osV0FDQSxpQkFDRSxLQUFLO0dBQ1QsTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLEtBQUssU0FBUztHQUM5QyxNQUFNLHlCQUF5QixLQUFLLFlBQVksZ0JBQWdCO0dBQ2hFLE1BQU0sY0FBYyx5QkFBeUIsTUFBTTs7OztJQUluRDtJQUFPLGlCQUFpQixNQUFNO0lBQUcsQ0FBQyxpQkFBaUI7SUFBRztHQUFZLElBQUk7R0FDdEU7SUFDRSxPQUFPLE1BQU0saUJBQWlCLFVBQVUsZ0NBQWdDLE9BQU8sZUFBZSxpQkFBaUIsR0FBRyxFQUFFLEVBQUU7R0FDeEg7R0FDQSxJQUFJO0lBQ0YsTUFBTSxNQUFNLElBQUksa0JBQWtCLHlCQUF5QixnQkFBZ0IsTUFBTSxJQUFJLGVBQWU7R0FDdEcsU0FBUyxPQUFPO0lBQ2QsSUFBSSxpQkFBaUIsT0FBTzs7S0FFMUIsSUFBSSxNQUFNLFNBQVMsc0JBQXNCO01BQ3ZDLE1BQU0sMkJBQTJCO0tBQ25DO0tBQ0EsTUFBTTtJQUNSO0dBQ0Y7R0FDQSxLQUFLLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixnQkFBZ0IsR0FBRztJQUM5RCxNQUFNLFNBQVM7S0FDYjtLQUNBO0tBQ0EsYUFBYSxnQkFBZ0IsTUFBTTtLQUNuQyxTQUFTO0tBQ1QsT0FBTyxLQUFLO0lBQ2QsQ0FBQztHQUNIO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7RUFZQSxNQUFNLFlBQVksU0FBUyxNQUFNO0dBQy9CLE1BQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxLQUFLO0dBQ2hDLElBQUksQ0FBQyxLQUFLLFdBQVcsTUFBTTtJQUN6QixJQUFJLG1CQUFtQjtJQUN2QixLQUFLLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixvQkFBb0IsR0FBRztLQUNsRSxtQkFBbUIsVUFBVSxNQUFNLFNBQVM7TUFDMUM7TUFDQSxTQUFTO01BQ1QsT0FBTyxLQUFLOztNQUVaLFFBQVEsS0FBSztLQUNmLENBQUMsQ0FBQztJQUNKO0lBQ0EsS0FBSyxXQUFXLE9BQU87R0FDekI7R0FDQSxPQUFPLEtBQUssV0FBVztFQUN6Qjs7Ozs7Ozs7RUFRQSxZQUFZLE1BQU07R0FDaEIsS0FBSyxNQUFNLFVBQVUsS0FBSyxVQUFVLFNBQVM7SUFDM0MsSUFBSSxRQUFRLFFBQVE7S0FDbEIsT0FBTztJQUNUO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaUJBLE1BQU0sYUFBYSxNQUFNLE9BQU87R0FDOUIsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsSUFBSSxHQUFHOzs7SUFHbEQsTUFBTSxTQUFTLEtBQUs7R0FDdEI7RUFDRjs7Ozs7Ozs7OztFQVVBLENBQUMsaUJBQWlCLE1BQU07R0FDdEIsS0FBSyxNQUFNLFVBQVUsS0FBSyxVQUFVLFNBQVM7SUFDM0MsSUFBSSxPQUFPLE9BQU8sVUFBVSxZQUFZO0tBQ3RDLE1BQU0sUUFBUSxLQUFLLGdCQUFnQixJQUFJLE1BQU07S0FDN0MsTUFBTSxvQkFBbUIsVUFBUztNQUNoQyxNQUFNLGdCQUFnQixPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxLQUFLLEdBQUcsRUFDNUQsTUFDRixDQUFDOzs7TUFHRCxPQUFPLE9BQU8sS0FBSyxDQUFDLGFBQWE7S0FDbkM7S0FDQSxNQUFNO0lBQ1I7R0FDRjtFQUNGOzs7Ozs7Ozs7Ozs7OztFQWNBLFVBQVUsU0FBUztHQUNqQixLQUFLLHdCQUF3QixLQUFLLE9BQU87R0FDekMsT0FBTztFQUNUOzs7Ozs7Ozs7OztFQVdBLE1BQU0sY0FBYztHQUNsQixPQUFPLEtBQUssd0JBQXdCLFFBQVE7SUFDMUMsTUFBTSxXQUFXLEtBQUssd0JBQXdCLE9BQU8sQ0FBQztJQUN0RCxNQUFNLFNBQVMsTUFBTSxRQUFRLFdBQVcsUUFBUTtJQUNoRCxNQUFNLGlCQUFpQixPQUFPLE1BQUssTUFBSyxFQUFFLFdBQVcsVUFBVTtJQUMvRCxJQUFJLGdCQUFnQjtLQUNsQixNQUFNLGVBQWU7SUFDdkI7R0FDRjtFQUNGOzs7OztFQUtBLFVBQVU7R0FDUixLQUFLLGlCQUFpQixRQUFRLElBQUk7RUFDcEM7Ozs7Ozs7Ozs7O0VBV0EsTUFBTSwyQkFBMkIsVUFBVTtHQUN6QyxJQUFJLGtCQUFrQjtHQUN0QixJQUFJLGNBQWM7R0FDbEIsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsaUJBQWlCLEdBQUc7SUFDL0Qsa0JBQW1CLE1BQU0sU0FBUztLQUNoQyxTQUFTLEtBQUs7S0FDZCxVQUFVO0tBQ1YsT0FBTyxLQUFLO0lBQ2QsQ0FBQyxLQUFNO0lBQ1AsY0FBYztJQUNkLElBQUksQ0FBQyxpQkFBaUI7S0FDcEI7SUFDRjtHQUNGO0dBQ0EsSUFBSSxDQUFDLGFBQWE7SUFDaEIsSUFBSSxtQkFBbUIsZ0JBQWdCLFdBQVcsS0FBSztLQUNyRCxrQkFBa0I7SUFDcEI7SUFDQTtLQUNFLElBQUksaUJBQWlCO01BQ25CLElBQUksZ0JBQWdCLFdBQVcsS0FBSztPQUNsQyxJQUFJLGdCQUFnQixXQUFXLEdBQUc7UUFDaEMsT0FBTyxLQUFLLHFCQUFxQixLQUFLLFFBQVEsSUFBSSxNQUFNLDZEQUE2RCxtREFBbUQ7T0FDMUssT0FBTztRQUNMLE9BQU8sTUFBTSxxQkFBcUIsS0FBSyxRQUFRLElBQUksTUFBTSw4QkFBOEIsU0FBUyxPQUFPLGdCQUFnQix3QkFBd0I7T0FDako7TUFDRjtLQUNGO0lBQ0Y7R0FDRjtHQUNBLE9BQU87RUFDVDtDQUNGOzs7Ozs7Ozs7Ozs7O0NBY0EsTUFBTSxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXVCYixZQUFZLFVBQVUsQ0FBQyxHQUFHOzs7Ozs7OztHQVF4QixLQUFLLFlBQVksV0FBVyxlQUFlLFFBQVEsU0FBUzs7Ozs7Ozs7R0FRNUQsS0FBSyxVQUFVLFFBQVEsV0FBVyxDQUFDOzs7Ozs7OztHQVFuQyxLQUFLLGVBQWUsUUFBUTs7Ozs7Ozs7R0FRNUIsS0FBSyxlQUFlLFFBQVE7RUFDOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBb0JBLE9BQU8sU0FBUztHQUNkLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxVQUFVLE9BQU87R0FDN0MsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXVCQSxVQUFVLFNBQVM7O0dBRWpCLElBQUksbUJBQW1CLFlBQVk7SUFDakMsVUFBVTtLQUNSLE9BQU87S0FDUCxTQUFTLFFBQVE7SUFDbkI7R0FDRjtHQUNBLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE1BQU0sVUFBVSxPQUFPLFFBQVEsWUFBWSxXQUFXLElBQUksUUFBUSxRQUFRLE9BQU8sSUFBSSxRQUFRO0dBQzdGLE1BQU0sU0FBUyxZQUFZLFVBQVUsUUFBUSxTQUFTO0dBQ3RELE1BQU0sVUFBVSxJQUFJLGdCQUFnQixNQUFNO0lBQ3hDO0lBQ0E7SUFDQTtHQUNGLENBQUM7R0FDRCxNQUFNLGVBQWUsS0FBSyxhQUFhLFNBQVMsU0FBUyxLQUFLO0dBQzlELE1BQU0sY0FBYyxLQUFLLGVBQWUsY0FBYyxTQUFTLFNBQVMsS0FBSzs7R0FFN0UsT0FBTyxDQUFDLGNBQWMsV0FBVztFQUNuQztFQUNBLE1BQU0sYUFBYSxTQUFTLFNBQVMsT0FBTztHQUMxQyxNQUFNLFFBQVEsYUFBYSxvQkFBb0I7SUFDN0M7SUFDQTtHQUNGLENBQUM7R0FDRCxJQUFJLFdBQVc7R0FDZixJQUFJO0lBQ0YsV0FBVyxNQUFNLEtBQUssUUFBUSxTQUFTLE9BQU87Ozs7SUFJOUMsSUFBSSxDQUFDLFlBQVksU0FBUyxTQUFTLFNBQVM7S0FDMUMsTUFBTSxJQUFJLGFBQWEsZUFBZSxFQUNwQyxLQUFLLFFBQVEsSUFDZixDQUFDO0lBQ0g7R0FDRixTQUFTLE9BQU87SUFDZCxJQUFJLGlCQUFpQixPQUFPO0tBQzFCLEtBQUssTUFBTSxZQUFZLFFBQVEsaUJBQWlCLGlCQUFpQixHQUFHO01BQ2xFLFdBQVcsTUFBTSxTQUFTO09BQ3hCO09BQ0E7T0FDQTtNQUNGLENBQUM7TUFDRCxJQUFJLFVBQVU7T0FDWjtNQUNGO0tBQ0Y7SUFDRjtJQUNBLElBQUksQ0FBQyxVQUFVO0tBQ2IsTUFBTTtJQUNSLE9BQU87S0FDTCxPQUFPLElBQUksd0JBQXdCLGVBQWUsUUFBUSxHQUFHLEVBQUUsT0FBTyxNQUFNLGlCQUFpQixRQUFRLE1BQU0sU0FBUyxJQUFJLEdBQUcsMkRBQTJELDJCQUEyQjtJQUNuTjtHQUNGO0dBQ0EsS0FBSyxNQUFNLFlBQVksUUFBUSxpQkFBaUIsb0JBQW9CLEdBQUc7SUFDckUsV0FBVyxNQUFNLFNBQVM7S0FDeEI7S0FDQTtLQUNBO0lBQ0YsQ0FBQztHQUNIO0dBQ0EsT0FBTztFQUNUO0VBQ0EsTUFBTSxlQUFlLGNBQWMsU0FBUyxTQUFTLE9BQU87R0FDMUQsSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0lBQ0YsV0FBVyxNQUFNO0dBQ25CLFNBQVMsT0FBTyxDQUloQjtHQUNBLElBQUk7SUFDRixNQUFNLFFBQVEsYUFBYSxxQkFBcUI7S0FDOUM7S0FDQTtLQUNBO0lBQ0YsQ0FBQztJQUNELE1BQU0sUUFBUSxZQUFZO0dBQzVCLFNBQVMsZ0JBQWdCO0lBQ3ZCLElBQUksMEJBQTBCLE9BQU87S0FDbkMsUUFBUTtJQUNWO0dBQ0Y7R0FDQSxNQUFNLFFBQVEsYUFBYSxzQkFBc0I7SUFDL0M7SUFDQTtJQUNBO0lBQ087R0FDVCxDQUFDO0dBQ0QsUUFBUSxRQUFRO0dBQ2hCLElBQUksT0FBTztJQUNULE1BQU07R0FDUjtFQUNGO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQ0EsTUFBTSx5QkFBeUIsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBa0J0QyxZQUFZLFVBQVUsQ0FBQyxHQUFHO0dBQ3hCLFFBQVEsWUFBWSxXQUFXLGdCQUFnQixRQUFRLFNBQVM7R0FDaEUsTUFBTSxPQUFPO0dBQ2IsS0FBSyxxQkFBcUIsUUFBUSxzQkFBc0IsUUFBUSxRQUFROzs7OztHQUt4RSxLQUFLLFFBQVEsS0FBSyxpQkFBaUIsc0NBQXNDO0VBQzNFOzs7Ozs7OztFQVFBLE1BQU0sUUFBUSxTQUFTLFNBQVM7R0FDOUIsTUFBTSxXQUFXLE1BQU0sUUFBUSxXQUFXLE9BQU87R0FDakQsSUFBSSxVQUFVO0lBQ1osT0FBTztHQUNUOzs7R0FHQSxJQUFJLFFBQVEsU0FBUyxRQUFRLE1BQU0sU0FBUyxXQUFXO0lBQ3JELE9BQU8sTUFBTSxLQUFLLGVBQWUsU0FBUyxPQUFPO0dBQ25EOzs7R0FHQSxPQUFPLE1BQU0sS0FBSyxhQUFhLFNBQVMsT0FBTztFQUNqRDtFQUNBLE1BQU0sYUFBYSxTQUFTLFNBQVM7R0FDbkMsSUFBSTtHQUNKLE1BQU0sU0FBUyxRQUFRLFVBQVUsQ0FBQzs7R0FFbEMsSUFBSSxLQUFLLG9CQUFvQjtJQUMzQjtLQUNFLE9BQU8sS0FBSyxnQ0FBZ0MsR0FBRyxlQUFlLFFBQVEsR0FBRyxFQUFFLE1BQU0sS0FBSyxVQUFVLGFBQWEscUNBQXFDO0lBQ3BKO0lBQ0EsTUFBTSxzQkFBc0IsT0FBTztJQUNuQyxNQUFNLHFCQUFxQixRQUFRO0lBQ25DLE1BQU0sc0JBQXNCLENBQUMsc0JBQXNCLHVCQUF1Qjs7O0lBRzFFLFdBQVcsTUFBTSxRQUFRLE1BQU0sSUFBSSxRQUFRLFNBQVMsRUFDbEQsV0FBVyxRQUFRLFNBQVMsWUFBWSxzQkFBc0Isc0JBQXNCLFVBQ3RGLENBQUMsQ0FBQzs7Ozs7Ozs7SUFRRixJQUFJLHVCQUF1Qix1QkFBdUIsUUFBUSxTQUFTLFdBQVc7S0FDNUUsS0FBSyxzQ0FBc0M7S0FDM0MsTUFBTSxZQUFZLE1BQU0sUUFBUSxTQUFTLFNBQVMsU0FBUyxNQUFNLENBQUM7S0FDbEU7TUFDRSxJQUFJLFdBQVc7T0FDYixPQUFPLElBQUksa0JBQWtCLGVBQWUsUUFBUSxHQUFHLEVBQUUsS0FBSyxvQ0FBb0M7TUFDcEc7S0FDRjtJQUNGO0dBQ0YsT0FBTzs7O0lBR0wsTUFBTSxJQUFJLGFBQWEsMEJBQTBCO0tBQy9DLFdBQVcsS0FBSztLQUNoQixLQUFLLFFBQVE7SUFDZixDQUFDO0dBQ0g7R0FDQTtJQUNFLE1BQU0sV0FBVyxPQUFPLFlBQWEsTUFBTSxRQUFRLFlBQVksU0FBUyxNQUFNOzs7SUFHOUUsT0FBTyxlQUFlLGtDQUFrQyxlQUFlLFFBQVEsR0FBRyxDQUFDO0lBQ25GLE9BQU8sSUFBSSw4QkFBOEIsZUFBZSxvQkFBb0IsVUFBVSxTQUFTLE1BQU0sUUFBUSxHQUFHO0lBQ2hILE9BQU8sZUFBZSw0QkFBNEI7SUFDbEQsT0FBTyxJQUFJLE9BQU87SUFDbEIsT0FBTyxTQUFTO0lBQ2hCLE9BQU8sZUFBZSw2QkFBNkI7SUFDbkQsT0FBTyxJQUFJLFFBQVE7SUFDbkIsT0FBTyxTQUFTO0lBQ2hCLE9BQU8sU0FBUztHQUNsQjtHQUNBLE9BQU87RUFDVDtFQUNBLE1BQU0sZUFBZSxTQUFTLFNBQVM7R0FDckMsS0FBSyxzQ0FBc0M7R0FDM0MsTUFBTSxXQUFXLE1BQU0sUUFBUSxNQUFNLE9BQU87OztHQUc1QyxNQUFNLFlBQVksTUFBTSxRQUFRLFNBQVMsU0FBUyxTQUFTLE1BQU0sQ0FBQztHQUNsRSxJQUFJLENBQUMsV0FBVzs7O0lBR2QsTUFBTSxJQUFJLGFBQWEsMkJBQTJCO0tBQ2hELEtBQUssUUFBUTtLQUNiLFFBQVEsU0FBUztJQUNuQixDQUFDO0dBQ0g7R0FDQSxPQUFPO0VBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUE0QkEsd0NBQXdDO0dBQ3RDLElBQUkscUJBQXFCO0dBQ3pCLElBQUksNkJBQTZCO0dBQ2pDLEtBQUssTUFBTSxDQUFDLE9BQU8sV0FBVyxLQUFLLFFBQVEsUUFBUSxHQUFHOztJQUVwRCxJQUFJLFdBQVcsaUJBQWlCLHdDQUF3QztLQUN0RTtJQUNGOztJQUVBLElBQUksV0FBVyxpQkFBaUIsbUNBQW1DO0tBQ2pFLHFCQUFxQjtJQUN2QjtJQUNBLElBQUksT0FBTyxpQkFBaUI7S0FDMUI7SUFDRjtHQUNGO0dBQ0EsSUFBSSwrQkFBK0IsR0FBRztJQUNwQyxLQUFLLFFBQVEsS0FBSyxpQkFBaUIsaUNBQWlDO0dBQ3RFLE9BQU8sSUFBSSw2QkFBNkIsS0FBSyx1QkFBdUIsTUFBTTs7SUFFeEUsS0FBSyxRQUFRLE9BQU8sb0JBQW9CLENBQUM7R0FDM0M7O0VBRUY7Q0FDRjtDQUNBLGlCQUFpQixvQ0FBb0MsRUFDbkQsTUFBTSxnQkFBZ0IsRUFDcEIsWUFDQztFQUNELElBQUksQ0FBQyxZQUFZLFNBQVMsVUFBVSxLQUFLO0dBQ3ZDLE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVCxFQUNGO0NBQ0EsaUJBQWlCLHlDQUF5QyxFQUN4RCxNQUFNLGdCQUFnQixFQUNwQixZQUNDO0VBQ0QsT0FBTyxTQUFTLGFBQWEsTUFBTSxhQUFhLFFBQVEsSUFBSTtDQUM5RCxFQUNGOzs7Ozs7Ozs7Ozs7O0NBY0EsTUFBTSxtQkFBbUI7Ozs7Ozs7Ozs7O0VBV3ZCLFlBQVksRUFDVixXQUNBLFVBQVUsQ0FBQyxHQUNYLG9CQUFvQixTQUNsQixDQUFDLEdBQUc7R0FDTixLQUFLLG1CQUFtQixJQUFJLElBQUk7R0FDaEMsS0FBSyxvQkFBb0IsSUFBSSxJQUFJO0dBQ2pDLEtBQUssMEJBQTBCLElBQUksSUFBSTtHQUN2QyxLQUFLLFlBQVksSUFBSSxpQkFBaUI7SUFDcEMsV0FBVyxXQUFXLGdCQUFnQixTQUFTO0lBQy9DLFNBQVMsQ0FBQyxHQUFHLFNBQVMsSUFBSSx1QkFBdUIsRUFDL0Msb0JBQW9CLEtBQ3RCLENBQUMsQ0FBQztJQUNGO0dBQ0YsQ0FBQzs7R0FFRCxLQUFLLFVBQVUsS0FBSyxRQUFRLEtBQUssSUFBSTtHQUNyQyxLQUFLLFdBQVcsS0FBSyxTQUFTLEtBQUssSUFBSTtFQUN6Qzs7Ozs7RUFLQSxJQUFJLFdBQVc7R0FDYixPQUFPLEtBQUs7RUFDZDs7Ozs7Ozs7Ozs7RUFXQSxTQUFTLFNBQVM7R0FDaEIsS0FBSyxlQUFlLE9BQU87R0FDM0IsSUFBSSxDQUFDLEtBQUssaUNBQWlDO0lBQ3pDLEtBQUssaUJBQWlCLFdBQVcsS0FBSyxPQUFPO0lBQzdDLEtBQUssaUJBQWlCLFlBQVksS0FBSyxRQUFRO0lBQy9DLEtBQUssa0NBQWtDO0dBQ3pDO0VBQ0Y7Ozs7Ozs7O0VBUUEsZUFBZSxTQUFTO0dBQ3RCO0lBQ0UsbUJBQW1CLFFBQVEsU0FBUztLQUNsQyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsTUFBTSxrQkFBa0IsQ0FBQztHQUN6QixLQUFLLE1BQU0sU0FBUyxTQUFTOztJQUUzQixJQUFJLE9BQU8sVUFBVSxVQUFVO0tBQzdCLGdCQUFnQixLQUFLLEtBQUs7SUFDNUIsT0FBTyxJQUFJLFNBQVMsTUFBTSxhQUFhLFdBQVc7S0FDaEQsZ0JBQWdCLEtBQUssTUFBTSxHQUFHO0lBQ2hDO0lBQ0EsTUFBTSxFQUNKLFVBQ0EsUUFDRSxlQUFlLEtBQUs7SUFDeEIsTUFBTSxZQUFZLE9BQU8sVUFBVSxZQUFZLE1BQU0sV0FBVyxXQUFXO0lBQzNFLElBQUksS0FBSyxpQkFBaUIsSUFBSSxHQUFHLEtBQUssS0FBSyxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sVUFBVTtLQUNqRixNQUFNLElBQUksYUFBYSx5Q0FBeUM7TUFDOUQsWUFBWSxLQUFLLGlCQUFpQixJQUFJLEdBQUc7TUFDekMsYUFBYTtLQUNmLENBQUM7SUFDSDtJQUNBLElBQUksT0FBTyxVQUFVLFlBQVksTUFBTSxXQUFXO0tBQ2hELElBQUksS0FBSyx3QkFBd0IsSUFBSSxRQUFRLEtBQUssS0FBSyx3QkFBd0IsSUFBSSxRQUFRLE1BQU0sTUFBTSxXQUFXO01BQ2hILE1BQU0sSUFBSSxhQUFhLDZDQUE2QyxFQUNsRSxJQUNGLENBQUM7S0FDSDtLQUNBLEtBQUssd0JBQXdCLElBQUksVUFBVSxNQUFNLFNBQVM7SUFDNUQ7SUFDQSxLQUFLLGlCQUFpQixJQUFJLEtBQUssUUFBUTtJQUN2QyxLQUFLLGtCQUFrQixJQUFJLEtBQUssU0FBUztJQUN6QyxJQUFJLGdCQUFnQixTQUFTLEdBQUc7S0FDOUIsTUFBTSxpQkFBaUIsaURBQWlELFNBQVMsZ0JBQWdCLEtBQUssSUFBSSxFQUFFLGtDQUFrQztLQUM5STtNQUNFLE9BQU8sS0FBSyxjQUFjO0tBQzVCO0lBQ0Y7R0FDRjtFQUNGOzs7Ozs7Ozs7OztFQVdBLFFBQVEsT0FBTzs7O0dBR2IsT0FBTyxVQUFVLE9BQU8sWUFBWTtJQUNsQyxNQUFNLHNCQUFzQixJQUFJLDRCQUE0QjtJQUM1RCxLQUFLLFNBQVMsUUFBUSxLQUFLLG1CQUFtQjs7O0lBRzlDLEtBQUssTUFBTSxDQUFDLEtBQUssYUFBYSxLQUFLLGtCQUFrQjtLQUNuRCxNQUFNLFlBQVksS0FBSyx3QkFBd0IsSUFBSSxRQUFRO0tBQzNELE1BQU0sWUFBWSxLQUFLLGtCQUFrQixJQUFJLEdBQUc7S0FDaEQsTUFBTSxVQUFVLElBQUksUUFBUSxLQUFLO01BQy9CO01BQ0EsT0FBTztNQUNQLGFBQWE7S0FDZixDQUFDO0tBQ0QsTUFBTSxRQUFRLElBQUksS0FBSyxTQUFTLFVBQVU7TUFDeEMsUUFBUSxFQUNOLFNBQ0Y7TUFDQTtNQUNBO0tBQ0YsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNLEVBQ0osYUFDQSxtQkFDRTtJQUNKO0tBQ0Usb0JBQW9CLGFBQWEsY0FBYztJQUNqRDtJQUNBLE9BQU87S0FDTDtLQUNBO0lBQ0Y7R0FDRixDQUFDO0VBQ0g7Ozs7Ozs7Ozs7O0VBV0EsU0FBUyxPQUFPOzs7R0FHZCxPQUFPLFVBQVUsT0FBTyxZQUFZO0lBQ2xDLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssU0FBUyxTQUFTO0lBQzVELE1BQU0sMEJBQTBCLE1BQU0sTUFBTSxLQUFLO0lBQ2pELE1BQU0sb0JBQW9CLElBQUksSUFBSSxLQUFLLGlCQUFpQixPQUFPLENBQUM7SUFDaEUsTUFBTSxjQUFjLENBQUM7SUFDckIsS0FBSyxNQUFNLFdBQVcseUJBQXlCO0tBQzdDLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxRQUFRLEdBQUcsR0FBRztNQUN2QyxNQUFNLE1BQU0sT0FBTyxPQUFPO01BQzFCLFlBQVksS0FBSyxRQUFRLEdBQUc7S0FDOUI7SUFDRjtJQUNBO0tBQ0Usb0JBQW9CLFdBQVc7SUFDakM7SUFDQSxPQUFPLEVBQ0wsWUFDRjtHQUNGLENBQUM7RUFDSDs7Ozs7OztFQU9BLHFCQUFxQjtHQUNuQixPQUFPLEtBQUs7RUFDZDs7Ozs7OztFQU9BLGdCQUFnQjtHQUNkLE9BQU8sQ0FBQyxHQUFHLEtBQUssaUJBQWlCLEtBQUssQ0FBQztFQUN6Qzs7Ozs7Ozs7OztFQVVBLGtCQUFrQixLQUFLO0dBQ3JCLE1BQU0sWUFBWSxJQUFJLElBQUksS0FBSyxTQUFTLElBQUk7R0FDNUMsT0FBTyxLQUFLLGlCQUFpQixJQUFJLFVBQVUsSUFBSTtFQUNqRDs7Ozs7O0VBTUEsd0JBQXdCLFVBQVU7R0FDaEMsT0FBTyxLQUFLLHdCQUF3QixJQUFJLFFBQVE7RUFDbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFtQkEsTUFBTSxjQUFjLFNBQVM7R0FDM0IsTUFBTSxNQUFNLG1CQUFtQixVQUFVLFFBQVEsTUFBTTtHQUN2RCxNQUFNLFdBQVcsS0FBSyxrQkFBa0IsR0FBRztHQUMzQyxJQUFJLFVBQVU7SUFDWixNQUFNLFFBQVEsTUFBTSxLQUFLLE9BQU8sS0FBSyxLQUFLLFNBQVMsU0FBUztJQUM1RCxPQUFPLE1BQU0sTUFBTSxRQUFRO0dBQzdCO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7RUFTQSx3QkFBd0IsS0FBSztHQUMzQixNQUFNLFdBQVcsS0FBSyxrQkFBa0IsR0FBRztHQUMzQyxJQUFJLENBQUMsVUFBVTtJQUNiLE1BQU0sSUFBSSxhQUFhLHFCQUFxQixFQUMxQyxJQUNGLENBQUM7R0FDSDtHQUNBLFFBQU8sWUFBVztJQUNoQixRQUFRLFVBQVUsSUFBSSxRQUFRLEdBQUc7SUFDakMsUUFBUSxTQUFTLE9BQU8sT0FBTyxFQUM3QixTQUNGLEdBQUcsUUFBUSxNQUFNO0lBQ2pCLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTztHQUNyQztFQUNGO0NBQ0Y7Ozs7Ozs7O0NBU0EsSUFBSTs7Ozs7Q0FLSixNQUFNLHNDQUFzQztFQUMxQyxJQUFJLENBQUMsb0JBQW9CO0dBQ3ZCLHFCQUFxQixJQUFJLG1CQUFtQjtFQUM5QztFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsU0FBUywwQkFBMEIsV0FBVyw4QkFBOEIsQ0FBQyxHQUFHOzs7RUFHOUUsS0FBSyxNQUFNLGFBQWEsQ0FBQyxHQUFHLFVBQVUsYUFBYSxLQUFLLENBQUMsR0FBRztHQUMxRCxJQUFJLDRCQUE0QixNQUFLLFdBQVUsT0FBTyxLQUFLLFNBQVMsQ0FBQyxHQUFHO0lBQ3RFLFVBQVUsYUFBYSxPQUFPLFNBQVM7R0FDekM7RUFDRjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLFVBQVUsc0JBQXNCLEtBQUssRUFDbkMsOEJBQThCLENBQUMsU0FBUyxVQUFVLEdBQ2xELGlCQUFpQixjQUNqQixZQUFZLE1BQ1osb0JBQ0UsQ0FBQyxHQUFHO0VBQ04sTUFBTSxZQUFZLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSTtFQUM1QyxVQUFVLE9BQU87RUFDakIsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sMEJBQTBCLDBCQUEwQixXQUFXLDJCQUEyQjtFQUNoRyxNQUFNLHdCQUF3QjtFQUM5QixJQUFJLGtCQUFrQix3QkFBd0IsU0FBUyxTQUFTLEdBQUcsR0FBRztHQUNwRSxNQUFNLGVBQWUsSUFBSSxJQUFJLHdCQUF3QixJQUFJO0dBQ3pELGFBQWEsWUFBWTtHQUN6QixNQUFNLGFBQWE7RUFDckI7RUFDQSxJQUFJLFdBQVc7R0FDYixNQUFNLFdBQVcsSUFBSSxJQUFJLHdCQUF3QixJQUFJO0dBQ3JELFNBQVMsWUFBWTtHQUNyQixNQUFNLFNBQVM7RUFDakI7RUFDQSxJQUFJLGlCQUFpQjtHQUNuQixNQUFNLGlCQUFpQixnQkFBZ0IsRUFDckMsS0FBSyxVQUNQLENBQUM7R0FDRCxLQUFLLE1BQU0sZ0JBQWdCLGdCQUFnQjtJQUN6QyxNQUFNLGFBQWE7R0FDckI7RUFDRjtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxNQUFNLHNCQUFzQixNQUFNOzs7Ozs7Ozs7Ozs7Ozs7OztFQWlCaEMsWUFBWSxvQkFBb0IsU0FBUztHQUN2QyxNQUFNLFNBQVMsRUFDYixjQUNJO0lBQ0osTUFBTSxrQkFBa0IsbUJBQW1CLG1CQUFtQjtJQUM5RCxLQUFLLE1BQU0sZUFBZSxzQkFBc0IsUUFBUSxLQUFLLE9BQU8sR0FBRztLQUNyRSxNQUFNLFdBQVcsZ0JBQWdCLElBQUksV0FBVztLQUNoRCxJQUFJLFVBQVU7TUFDWixNQUFNLFlBQVksbUJBQW1CLHdCQUF3QixRQUFRO01BQ3JFLE9BQU87T0FDTDtPQUNBO01BQ0Y7S0FDRjtJQUNGO0lBQ0E7S0FDRSxPQUFPLE1BQU0seUNBQXlDLGVBQWUsUUFBUSxHQUFHLENBQUM7SUFDbkY7SUFDQTtHQUNGO0dBQ0EsTUFBTSxPQUFPLG1CQUFtQixRQUFRO0VBQzFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1QkEsU0FBUyxTQUFTLFNBQVM7RUFDekIsTUFBTSxxQkFBcUIsOEJBQThCO0VBQ3pELE1BQU0sZ0JBQWdCLElBQUksY0FBYyxvQkFBb0IsT0FBTztFQUNuRSxjQUFjLGFBQWE7Q0FDN0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTRCQSxTQUFTLFNBQVMsU0FBUztFQUN6QixNQUFNLHFCQUFxQiw4QkFBOEI7RUFDekQsbUJBQW1CLFNBQVMsT0FBTztDQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxTQUFTLGlCQUFpQixTQUFTLFNBQVM7RUFDMUMsU0FBUyxPQUFPO0VBQ2hCLFNBQVMsT0FBTztDQUNsQjs7Ozs7Ozs7Q0FTQSxNQUFNLG9CQUFvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CMUIsTUFBTSx1QkFBdUIsT0FBTyxxQkFBcUIsa0JBQWtCLHNCQUFzQjtFQUMvRixNQUFNLGFBQWEsTUFBTSxLQUFLLE9BQU8sS0FBSztFQUMxQyxNQUFNLHFCQUFxQixXQUFXLFFBQU8sY0FBYTtHQUN4RCxPQUFPLFVBQVUsU0FBUyxlQUFlLEtBQUssVUFBVSxTQUFTLEtBQUssYUFBYSxLQUFLLEtBQUssY0FBYztFQUM3RyxDQUFDO0VBQ0QsTUFBTSxRQUFRLElBQUksbUJBQW1CLEtBQUksY0FBYSxLQUFLLE9BQU8sT0FBTyxTQUFTLENBQUMsQ0FBQztFQUNwRixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7O0NBZUEsU0FBUyx3QkFBd0I7O0VBRS9CLEtBQUssaUJBQWlCLGFBQVksVUFBUztHQUN6QyxNQUFNLFlBQVksV0FBVyxnQkFBZ0I7R0FDN0MsTUFBTSxVQUFVLHFCQUFxQixTQUFTLENBQUMsQ0FBQyxNQUFLLGtCQUFpQjtJQUNwRTtLQUNFLElBQUksY0FBYyxTQUFTLEdBQUc7TUFDNUIsT0FBTyxJQUFJLHlEQUF5RCxrQkFBa0IsYUFBYTtLQUNyRztJQUNGO0dBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQztDQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXdCQSxNQUFNLHdCQUF3QixNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBeUJsQyxZQUFZLFNBQVMsRUFDbkIsWUFBWSxDQUFDLEdBQUcsR0FDaEIsV0FBVyxDQUFDLE1BQ1YsQ0FBQyxHQUFHO0dBQ047SUFDRSxtQkFBbUIsZUFBZSxXQUFXLFFBQVE7S0FDbkQsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxtQkFBbUIsZUFBZSxVQUFVLFFBQVE7S0FDbEQsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLE9BQU0sWUFBVyxLQUFLLE9BQU8sT0FBTyxHQUFHLE9BQU87R0FDOUMsS0FBSyxhQUFhO0dBQ2xCLEtBQUssWUFBWTtFQUNuQjs7Ozs7Ozs7Ozs7RUFXQSxPQUFPLEVBQ0wsS0FDQSxXQUNDO0dBQ0QsSUFBSSxXQUFXLFFBQVEsU0FBUyxZQUFZO0lBQzFDLE9BQU87R0FDVDtHQUNBLE1BQU0sb0JBQW9CLElBQUksV0FBVyxJQUFJO0dBQzdDLEtBQUssTUFBTSxVQUFVLEtBQUssV0FBVztJQUNuQyxJQUFJLE9BQU8sS0FBSyxpQkFBaUIsR0FBRztLQUNsQztNQUNFLE9BQU8sSUFBSSx3QkFBd0Isa0JBQWtCLFlBQVksOERBQThELEdBQUcsT0FBTyxTQUFTLEdBQUc7S0FDdko7S0FDQSxPQUFPO0lBQ1Q7R0FDRjtHQUNBLElBQUksS0FBSyxXQUFXLE1BQUssV0FBVSxPQUFPLEtBQUssaUJBQWlCLENBQUMsR0FBRztJQUNsRTtLQUNFLE9BQU8sTUFBTSx3QkFBd0Isa0JBQWtCLEtBQUssZ0JBQWdCO0lBQzlFO0lBQ0EsT0FBTztHQUNUO0dBQ0E7SUFDRSxPQUFPLElBQUksd0JBQXdCLGtCQUFrQixZQUFZLDBEQUEwRCxzQkFBc0I7R0FDbko7R0FDQSxPQUFPO0VBQ1Q7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBCQSxTQUFTLHdCQUF3QixLQUFLO0VBQ3BDLE1BQU0scUJBQXFCLDhCQUE4QjtFQUN6RCxPQUFPLG1CQUFtQix3QkFBd0IsR0FBRztDQUN2RDtDQUVBLFFBQVEsa0JBQWtCO0NBQzFCLFFBQVEsd0JBQXdCO0NBQ2hDLFFBQVEsZUFBZTtDQUN2QixRQUFRLDBCQUEwQjtDQUNsQyxRQUFRLG1CQUFtQjtDQUMzQixRQUFRLGdCQUFnQjtBQUU1QixFQUFFIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIndvcmtib3gtN2U1ZWI0MmIuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZGVmaW5lKFsnZXhwb3J0cyddLCAoZnVuY3Rpb24gKGV4cG9ydHMpIHsgJ3VzZSBzdHJpY3QnO1xuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRyeSB7XG4gICAgICBzZWxmWyd3b3JrYm94OmNvcmU6Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIENsYWltIGFueSBjdXJyZW50bHkgYXZhaWxhYmxlIGNsaWVudHMgb25jZSB0aGUgc2VydmljZSB3b3JrZXJcbiAgICAgKiBiZWNvbWVzIGFjdGl2ZS4gVGhpcyBpcyBub3JtYWxseSB1c2VkIGluIGNvbmp1bmN0aW9uIHdpdGggYHNraXBXYWl0aW5nKClgLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtY29yZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNsaWVudHNDbGFpbSgpIHtcbiAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignYWN0aXZhdGUnLCAoKSA9PiBzZWxmLmNsaWVudHMuY2xhaW0oKSk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IGxvZ2dlciA9ICgoKSA9PiB7XG4gICAgICAvLyBEb24ndCBvdmVyd3JpdGUgdGhpcyB2YWx1ZSBpZiBpdCdzIGFscmVhZHkgc2V0LlxuICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9wdWxsLzIyODQjaXNzdWVjb21tZW50LTU2MDQ3MDkyM1xuICAgICAgaWYgKCEoJ19fV0JfRElTQUJMRV9ERVZfTE9HUycgaW4gZ2xvYmFsVGhpcykpIHtcbiAgICAgICAgc2VsZi5fX1dCX0RJU0FCTEVfREVWX0xPR1MgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGxldCBpbkdyb3VwID0gZmFsc2U7XG4gICAgICBjb25zdCBtZXRob2RUb0NvbG9yTWFwID0ge1xuICAgICAgICBkZWJ1ZzogYCM3ZjhjOGRgLFxuICAgICAgICBsb2c6IGAjMmVjYzcxYCxcbiAgICAgICAgd2FybjogYCNmMzljMTJgLFxuICAgICAgICBlcnJvcjogYCNjMDM5MmJgLFxuICAgICAgICBncm91cENvbGxhcHNlZDogYCMzNDk4ZGJgLFxuICAgICAgICBncm91cEVuZDogbnVsbCAvLyBObyBjb2xvcmVkIHByZWZpeCBvbiBncm91cEVuZFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHByaW50ID0gZnVuY3Rpb24gKG1ldGhvZCwgYXJncykge1xuICAgICAgICBpZiAoc2VsZi5fX1dCX0RJU0FCTEVfREVWX0xPR1MpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1ldGhvZCA9PT0gJ2dyb3VwQ29sbGFwc2VkJykge1xuICAgICAgICAgIC8vIFNhZmFyaSBkb2Vzbid0IHByaW50IGFsbCBjb25zb2xlLmdyb3VwQ29sbGFwc2VkKCkgYXJndW1lbnRzOlxuICAgICAgICAgIC8vIGh0dHBzOi8vYnVncy53ZWJraXQub3JnL3Nob3dfYnVnLmNnaT9pZD0xODI3NTRcbiAgICAgICAgICBpZiAoL14oKD8hY2hyb21lfGFuZHJvaWQpLikqc2FmYXJpL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSkge1xuICAgICAgICAgICAgY29uc29sZVttZXRob2RdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdHlsZXMgPSBbYGJhY2tncm91bmQ6ICR7bWV0aG9kVG9Db2xvck1hcFttZXRob2RdfWAsIGBib3JkZXItcmFkaXVzOiAwLjVlbWAsIGBjb2xvcjogd2hpdGVgLCBgZm9udC13ZWlnaHQ6IGJvbGRgLCBgcGFkZGluZzogMnB4IDAuNWVtYF07XG4gICAgICAgIC8vIFdoZW4gaW4gYSBncm91cCwgdGhlIHdvcmtib3ggcHJlZml4IGlzIG5vdCBkaXNwbGF5ZWQuXG4gICAgICAgIGNvbnN0IGxvZ1ByZWZpeCA9IGluR3JvdXAgPyBbXSA6IFsnJWN3b3JrYm94Jywgc3R5bGVzLmpvaW4oJzsnKV07XG4gICAgICAgIGNvbnNvbGVbbWV0aG9kXSguLi5sb2dQcmVmaXgsIC4uLmFyZ3MpO1xuICAgICAgICBpZiAobWV0aG9kID09PSAnZ3JvdXBDb2xsYXBzZWQnKSB7XG4gICAgICAgICAgaW5Hcm91cCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1ldGhvZCA9PT0gJ2dyb3VwRW5kJykge1xuICAgICAgICAgIGluR3JvdXAgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXR5cGVzXG4gICAgICBjb25zdCBhcGkgPSB7fTtcbiAgICAgIGNvbnN0IGxvZ2dlck1ldGhvZHMgPSBPYmplY3Qua2V5cyhtZXRob2RUb0NvbG9yTWFwKTtcbiAgICAgIGZvciAoY29uc3Qga2V5IG9mIGxvZ2dlck1ldGhvZHMpIHtcbiAgICAgICAgY29uc3QgbWV0aG9kID0ga2V5O1xuICAgICAgICBhcGlbbWV0aG9kXSA9ICguLi5hcmdzKSA9PiB7XG4gICAgICAgICAgcHJpbnQobWV0aG9kLCBhcmdzKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBhcGk7XG4gICAgfSkoKTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IG1lc3NhZ2VzID0ge1xuICAgICAgJ2ludmFsaWQtdmFsdWUnOiAoe1xuICAgICAgICBwYXJhbU5hbWUsXG4gICAgICAgIHZhbGlkVmFsdWVEZXNjcmlwdGlvbixcbiAgICAgICAgdmFsdWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFwYXJhbU5hbWUgfHwgIXZhbGlkVmFsdWVEZXNjcmlwdGlvbikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnaW52YWxpZC12YWx1ZScgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgJyR7cGFyYW1OYW1lfScgcGFyYW1ldGVyIHdhcyBnaXZlbiBhIHZhbHVlIHdpdGggYW4gYCArIGB1bmV4cGVjdGVkIHZhbHVlLiAke3ZhbGlkVmFsdWVEZXNjcmlwdGlvbn0gUmVjZWl2ZWQgYSB2YWx1ZSBvZiBgICsgYCR7SlNPTi5zdHJpbmdpZnkodmFsdWUpfS5gO1xuICAgICAgfSxcbiAgICAgICdub3QtYW4tYXJyYXknOiAoe1xuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgIGZ1bmNOYW1lLFxuICAgICAgICBwYXJhbU5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFtb2R1bGVOYW1lIHx8ICFjbGFzc05hbWUgfHwgIWZ1bmNOYW1lIHx8ICFwYXJhbU5hbWUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ25vdC1hbi1hcnJheScgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgcGFyYW1ldGVyICcke3BhcmFtTmFtZX0nIHBhc3NlZCBpbnRvIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWV9LiR7ZnVuY05hbWV9KCknIG11c3QgYmUgYW4gYXJyYXkuYDtcbiAgICAgIH0sXG4gICAgICAnaW5jb3JyZWN0LXR5cGUnOiAoe1xuICAgICAgICBleHBlY3RlZFR5cGUsXG4gICAgICAgIHBhcmFtTmFtZSxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIWV4cGVjdGVkVHlwZSB8fCAhcGFyYW1OYW1lIHx8ICFtb2R1bGVOYW1lIHx8ICFmdW5jTmFtZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnaW5jb3JyZWN0LXR5cGUnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNsYXNzTmFtZVN0ciA9IGNsYXNzTmFtZSA/IGAke2NsYXNzTmFtZX0uYCA6ICcnO1xuICAgICAgICByZXR1cm4gYFRoZSBwYXJhbWV0ZXIgJyR7cGFyYW1OYW1lfScgcGFzc2VkIGludG8gYCArIGAnJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZVN0cn1gICsgYCR7ZnVuY05hbWV9KCknIG11c3QgYmUgb2YgdHlwZSAke2V4cGVjdGVkVHlwZX0uYDtcbiAgICAgIH0sXG4gICAgICAnaW5jb3JyZWN0LWNsYXNzJzogKHtcbiAgICAgICAgZXhwZWN0ZWRDbGFzc05hbWUsXG4gICAgICAgIHBhcmFtTmFtZSxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZSxcbiAgICAgICAgaXNSZXR1cm5WYWx1ZVByb2JsZW1cbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFleHBlY3RlZENsYXNzTmFtZSB8fCAhbW9kdWxlTmFtZSB8fCAhZnVuY05hbWUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ2luY29ycmVjdC1jbGFzcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2xhc3NOYW1lU3RyID0gY2xhc3NOYW1lID8gYCR7Y2xhc3NOYW1lfS5gIDogJyc7XG4gICAgICAgIGlmIChpc1JldHVyblZhbHVlUHJvYmxlbSkge1xuICAgICAgICAgIHJldHVybiBgVGhlIHJldHVybiB2YWx1ZSBmcm9tIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWVTdHJ9JHtmdW5jTmFtZX0oKScgYCArIGBtdXN0IGJlIGFuIGluc3RhbmNlIG9mIGNsYXNzICR7ZXhwZWN0ZWRDbGFzc05hbWV9LmA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgcGFyYW1ldGVyICcke3BhcmFtTmFtZX0nIHBhc3NlZCBpbnRvIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWVTdHJ9JHtmdW5jTmFtZX0oKScgYCArIGBtdXN0IGJlIGFuIGluc3RhbmNlIG9mIGNsYXNzICR7ZXhwZWN0ZWRDbGFzc05hbWV9LmA7XG4gICAgICB9LFxuICAgICAgJ21pc3NpbmctYS1tZXRob2QnOiAoe1xuICAgICAgICBleHBlY3RlZE1ldGhvZCxcbiAgICAgICAgcGFyYW1OYW1lLFxuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgIGZ1bmNOYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghZXhwZWN0ZWRNZXRob2QgfHwgIXBhcmFtTmFtZSB8fCAhbW9kdWxlTmFtZSB8fCAhY2xhc3NOYW1lIHx8ICFmdW5jTmFtZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnbWlzc2luZy1hLW1ldGhvZCcgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGAke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lfS4ke2Z1bmNOYW1lfSgpIGV4cGVjdGVkIHRoZSBgICsgYCcke3BhcmFtTmFtZX0nIHBhcmFtZXRlciB0byBleHBvc2UgYSAnJHtleHBlY3RlZE1ldGhvZH0nIG1ldGhvZC5gO1xuICAgICAgfSxcbiAgICAgICdhZGQtdG8tY2FjaGUtbGlzdC11bmV4cGVjdGVkLXR5cGUnOiAoe1xuICAgICAgICBlbnRyeVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYEFuIHVuZXhwZWN0ZWQgZW50cnkgd2FzIHBhc3NlZCB0byBgICsgYCd3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyLmFkZFRvQ2FjaGVMaXN0KCknIFRoZSBlbnRyeSBgICsgYCcke0pTT04uc3RyaW5naWZ5KGVudHJ5KX0nIGlzbid0IHN1cHBvcnRlZC4gWW91IG11c3Qgc3VwcGx5IGFuIGFycmF5IG9mIGAgKyBgc3RyaW5ncyB3aXRoIG9uZSBvciBtb3JlIGNoYXJhY3RlcnMsIG9iamVjdHMgd2l0aCBhIHVybCBwcm9wZXJ0eSBvciBgICsgYFJlcXVlc3Qgb2JqZWN0cy5gO1xuICAgICAgfSxcbiAgICAgICdhZGQtdG8tY2FjaGUtbGlzdC1jb25mbGljdGluZy1lbnRyaWVzJzogKHtcbiAgICAgICAgZmlyc3RFbnRyeSxcbiAgICAgICAgc2Vjb25kRW50cnlcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFmaXJzdEVudHJ5IHx8ICFzZWNvbmRFbnRyeSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byBgICsgYCdhZGQtdG8tY2FjaGUtbGlzdC1kdXBsaWNhdGUtZW50cmllcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUd28gb2YgdGhlIGVudHJpZXMgcGFzc2VkIHRvIGAgKyBgJ3dvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXIuYWRkVG9DYWNoZUxpc3QoKScgaGFkIHRoZSBVUkwgYCArIGAke2ZpcnN0RW50cnl9IGJ1dCBkaWZmZXJlbnQgcmV2aXNpb24gZGV0YWlscy4gV29ya2JveCBpcyBgICsgYHVuYWJsZSB0byBjYWNoZSBhbmQgdmVyc2lvbiB0aGUgYXNzZXQgY29ycmVjdGx5LiBQbGVhc2UgcmVtb3ZlIG9uZSBgICsgYG9mIHRoZSBlbnRyaWVzLmA7XG4gICAgICB9LFxuICAgICAgJ3BsdWdpbi1lcnJvci1yZXF1ZXN0LXdpbGwtZmV0Y2gnOiAoe1xuICAgICAgICB0aHJvd25FcnJvck1lc3NhZ2VcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCF0aHJvd25FcnJvck1lc3NhZ2UpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gYCArIGAncGx1Z2luLWVycm9yLXJlcXVlc3Qtd2lsbC1mZXRjaCcsIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgQW4gZXJyb3Igd2FzIHRocm93biBieSBhIHBsdWdpbnMgJ3JlcXVlc3RXaWxsRmV0Y2goKScgbWV0aG9kLiBgICsgYFRoZSB0aHJvd24gZXJyb3IgbWVzc2FnZSB3YXM6ICcke3Rocm93bkVycm9yTWVzc2FnZX0nLmA7XG4gICAgICB9LFxuICAgICAgJ2ludmFsaWQtY2FjaGUtbmFtZSc6ICh7XG4gICAgICAgIGNhY2hlTmFtZUlkLFxuICAgICAgICB2YWx1ZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIWNhY2hlTmFtZUlkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhICdjYWNoZU5hbWVJZCcgZm9yIGVycm9yICdpbnZhbGlkLWNhY2hlLW5hbWUnYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBwcm92aWRlIGEgbmFtZSBjb250YWluaW5nIGF0IGxlYXN0IG9uZSBjaGFyYWN0ZXIgZm9yIGAgKyBgc2V0Q2FjaGVEZXRhaWxzKHske2NhY2hlTmFtZUlkfTogJy4uLid9KS4gUmVjZWl2ZWQgYSB2YWx1ZSBvZiBgICsgYCcke0pTT04uc3RyaW5naWZ5KHZhbHVlKX0nYDtcbiAgICAgIH0sXG4gICAgICAndW5yZWdpc3Rlci1yb3V0ZS1idXQtbm90LWZvdW5kLXdpdGgtbWV0aG9kJzogKHtcbiAgICAgICAgbWV0aG9kXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbWV0aG9kKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvIGAgKyBgJ3VucmVnaXN0ZXItcm91dGUtYnV0LW5vdC1mb3VuZC13aXRoLW1ldGhvZCcgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgcm91dGUgeW91J3JlIHRyeWluZyB0byB1bnJlZ2lzdGVyIHdhcyBub3QgIHByZXZpb3VzbHkgYCArIGByZWdpc3RlcmVkIGZvciB0aGUgbWV0aG9kIHR5cGUgJyR7bWV0aG9kfScuYDtcbiAgICAgIH0sXG4gICAgICAndW5yZWdpc3Rlci1yb3V0ZS1yb3V0ZS1ub3QtcmVnaXN0ZXJlZCc6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgcm91dGUgeW91J3JlIHRyeWluZyB0byB1bnJlZ2lzdGVyIHdhcyBub3QgcHJldmlvdXNseSBgICsgYHJlZ2lzdGVyZWQuYDtcbiAgICAgIH0sXG4gICAgICAncXVldWUtcmVwbGF5LWZhaWxlZCc6ICh7XG4gICAgICAgIG5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBSZXBsYXlpbmcgdGhlIGJhY2tncm91bmQgc3luYyBxdWV1ZSAnJHtuYW1lfScgZmFpbGVkLmA7XG4gICAgICB9LFxuICAgICAgJ2R1cGxpY2F0ZS1xdWV1ZS1uYW1lJzogKHtcbiAgICAgICAgbmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBRdWV1ZSBuYW1lICcke25hbWV9JyBpcyBhbHJlYWR5IGJlaW5nIHVzZWQuIGAgKyBgQWxsIGluc3RhbmNlcyBvZiBiYWNrZ3JvdW5kU3luYy5RdWV1ZSBtdXN0IGJlIGdpdmVuIHVuaXF1ZSBuYW1lcy5gO1xuICAgICAgfSxcbiAgICAgICdleHBpcmVkLXRlc3Qtd2l0aG91dC1tYXgtYWdlJzogKHtcbiAgICAgICAgbWV0aG9kTmFtZSxcbiAgICAgICAgcGFyYW1OYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlICcke21ldGhvZE5hbWV9KCknIG1ldGhvZCBjYW4gb25seSBiZSB1c2VkIHdoZW4gdGhlIGAgKyBgJyR7cGFyYW1OYW1lfScgaXMgdXNlZCBpbiB0aGUgY29uc3RydWN0b3IuYDtcbiAgICAgIH0sXG4gICAgICAndW5zdXBwb3J0ZWQtcm91dGUtdHlwZSc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWUsXG4gICAgICAgIHBhcmFtTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBzdXBwbGllZCAnJHtwYXJhbU5hbWV9JyBwYXJhbWV0ZXIgd2FzIGFuIHVuc3VwcG9ydGVkIHR5cGUuIGAgKyBgUGxlYXNlIGNoZWNrIHRoZSBkb2NzIGZvciAke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lfS4ke2Z1bmNOYW1lfSBmb3IgYCArIGB2YWxpZCBpbnB1dCB0eXBlcy5gO1xuICAgICAgfSxcbiAgICAgICdub3QtYXJyYXktb2YtY2xhc3MnOiAoe1xuICAgICAgICB2YWx1ZSxcbiAgICAgICAgZXhwZWN0ZWRDbGFzcyxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZSxcbiAgICAgICAgcGFyYW1OYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlIHN1cHBsaWVkICcke3BhcmFtTmFtZX0nIHBhcmFtZXRlciBtdXN0IGJlIGFuIGFycmF5IG9mIGAgKyBgJyR7ZXhwZWN0ZWRDbGFzc30nIG9iamVjdHMuIFJlY2VpdmVkICcke0pTT04uc3RyaW5naWZ5KHZhbHVlKX0sJy4gYCArIGBQbGVhc2UgY2hlY2sgdGhlIGNhbGwgdG8gJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZX0uJHtmdW5jTmFtZX0oKSBgICsgYHRvIGZpeCB0aGUgaXNzdWUuYDtcbiAgICAgIH0sXG4gICAgICAnbWF4LWVudHJpZXMtb3ItYWdlLXJlcXVpcmVkJzogKHtcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFlvdSBtdXN0IGRlZmluZSBlaXRoZXIgY29uZmlnLm1heEVudHJpZXMgb3IgY29uZmlnLm1heEFnZVNlY29uZHNgICsgYGluICR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWV9LiR7ZnVuY05hbWV9YDtcbiAgICAgIH0sXG4gICAgICAnc3RhdHVzZXMtb3ItaGVhZGVycy1yZXF1aXJlZCc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBkZWZpbmUgZWl0aGVyIGNvbmZpZy5zdGF0dXNlcyBvciBjb25maWcuaGVhZGVyc2AgKyBgaW4gJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZX0uJHtmdW5jTmFtZX1gO1xuICAgICAgfSxcbiAgICAgICdpbnZhbGlkLXN0cmluZyc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGZ1bmNOYW1lLFxuICAgICAgICBwYXJhbU5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFwYXJhbU5hbWUgfHwgIW1vZHVsZU5hbWUgfHwgIWZ1bmNOYW1lKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdpbnZhbGlkLXN0cmluZycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBXaGVuIHVzaW5nIHN0cmluZ3MsIHRoZSAnJHtwYXJhbU5hbWV9JyBwYXJhbWV0ZXIgbXVzdCBzdGFydCB3aXRoIGAgKyBgJ2h0dHAnIChmb3IgY3Jvc3Mtb3JpZ2luIG1hdGNoZXMpIG9yICcvJyAoZm9yIHNhbWUtb3JpZ2luIG1hdGNoZXMpLiBgICsgYFBsZWFzZSBzZWUgdGhlIGRvY3MgZm9yICR7bW9kdWxlTmFtZX0uJHtmdW5jTmFtZX0oKSBmb3IgYCArIGBtb3JlIGluZm8uYDtcbiAgICAgIH0sXG4gICAgICAnY2hhbm5lbC1uYW1lLXJlcXVpcmVkJzogKCkgPT4ge1xuICAgICAgICByZXR1cm4gYFlvdSBtdXN0IHByb3ZpZGUgYSBjaGFubmVsTmFtZSB0byBjb25zdHJ1Y3QgYSBgICsgYEJyb2FkY2FzdENhY2hlVXBkYXRlIGluc3RhbmNlLmA7XG4gICAgICB9LFxuICAgICAgJ2ludmFsaWQtcmVzcG9uc2VzLWFyZS1zYW1lLWFyZ3MnOiAoKSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlIGFyZ3VtZW50cyBwYXNzZWQgaW50byByZXNwb25zZXNBcmVTYW1lKCkgYXBwZWFyIHRvIGJlIGAgKyBgaW52YWxpZC4gUGxlYXNlIGVuc3VyZSB2YWxpZCBSZXNwb25zZXMgYXJlIHVzZWQuYDtcbiAgICAgIH0sXG4gICAgICAnZXhwaXJlLWN1c3RvbS1jYWNoZXMtb25seSc6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBwcm92aWRlIGEgJ2NhY2hlTmFtZScgcHJvcGVydHkgd2hlbiB1c2luZyB0aGUgYCArIGBleHBpcmF0aW9uIHBsdWdpbiB3aXRoIGEgcnVudGltZSBjYWNoaW5nIHN0cmF0ZWd5LmA7XG4gICAgICB9LFxuICAgICAgJ3VuaXQtbXVzdC1iZS1ieXRlcyc6ICh7XG4gICAgICAgIG5vcm1hbGl6ZWRSYW5nZUhlYWRlclxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRSYW5nZUhlYWRlcikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAndW5pdC1tdXN0LWJlLWJ5dGVzJyBlcnJvci5gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYFRoZSAndW5pdCcgcG9ydGlvbiBvZiB0aGUgUmFuZ2UgaGVhZGVyIG11c3QgYmUgc2V0IHRvICdieXRlcycuIGAgKyBgVGhlIFJhbmdlIGhlYWRlciBwcm92aWRlZCB3YXMgXCIke25vcm1hbGl6ZWRSYW5nZUhlYWRlcn1cImA7XG4gICAgICB9LFxuICAgICAgJ3NpbmdsZS1yYW5nZS1vbmx5JzogKHtcbiAgICAgICAgbm9ybWFsaXplZFJhbmdlSGVhZGVyXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbm9ybWFsaXplZFJhbmdlSGVhZGVyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdzaW5nbGUtcmFuZ2Utb25seScgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBNdWx0aXBsZSByYW5nZXMgYXJlIG5vdCBzdXBwb3J0ZWQuIFBsZWFzZSB1c2UgYSAgc2luZ2xlIHN0YXJ0IGAgKyBgdmFsdWUsIGFuZCBvcHRpb25hbCBlbmQgdmFsdWUuIFRoZSBSYW5nZSBoZWFkZXIgcHJvdmlkZWQgd2FzIGAgKyBgXCIke25vcm1hbGl6ZWRSYW5nZUhlYWRlcn1cImA7XG4gICAgICB9LFxuICAgICAgJ2ludmFsaWQtcmFuZ2UtdmFsdWVzJzogKHtcbiAgICAgICAgbm9ybWFsaXplZFJhbmdlSGVhZGVyXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbm9ybWFsaXplZFJhbmdlSGVhZGVyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdpbnZhbGlkLXJhbmdlLXZhbHVlcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgUmFuZ2UgaGVhZGVyIGlzIG1pc3NpbmcgYm90aCBzdGFydCBhbmQgZW5kIHZhbHVlcy4gQXQgbGVhc3QgYCArIGBvbmUgb2YgdGhvc2UgdmFsdWVzIGlzIG5lZWRlZC4gVGhlIFJhbmdlIGhlYWRlciBwcm92aWRlZCB3YXMgYCArIGBcIiR7bm9ybWFsaXplZFJhbmdlSGVhZGVyfVwiYDtcbiAgICAgIH0sXG4gICAgICAnbm8tcmFuZ2UtaGVhZGVyJzogKCkgPT4ge1xuICAgICAgICByZXR1cm4gYE5vIFJhbmdlIGhlYWRlciB3YXMgZm91bmQgaW4gdGhlIFJlcXVlc3QgcHJvdmlkZWQuYDtcbiAgICAgIH0sXG4gICAgICAncmFuZ2Utbm90LXNhdGlzZmlhYmxlJzogKHtcbiAgICAgICAgc2l6ZSxcbiAgICAgICAgc3RhcnQsXG4gICAgICAgIGVuZFxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBzdGFydCAoJHtzdGFydH0pIGFuZCBlbmQgKCR7ZW5kfSkgdmFsdWVzIGluIHRoZSBSYW5nZSBhcmUgYCArIGBub3Qgc2F0aXNmaWFibGUgYnkgdGhlIGNhY2hlZCByZXNwb25zZSwgd2hpY2ggaXMgJHtzaXplfSBieXRlcy5gO1xuICAgICAgfSxcbiAgICAgICdhdHRlbXB0LXRvLWNhY2hlLW5vbi1nZXQtcmVxdWVzdCc6ICh7XG4gICAgICAgIHVybCxcbiAgICAgICAgbWV0aG9kXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVW5hYmxlIHRvIGNhY2hlICcke3VybH0nIGJlY2F1c2UgaXQgaXMgYSAnJHttZXRob2R9JyByZXF1ZXN0IGFuZCBgICsgYG9ubHkgJ0dFVCcgcmVxdWVzdHMgY2FuIGJlIGNhY2hlZC5gO1xuICAgICAgfSxcbiAgICAgICdjYWNoZS1wdXQtd2l0aC1uby1yZXNwb25zZSc6ICh7XG4gICAgICAgIHVybFxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZXJlIHdhcyBhbiBhdHRlbXB0IHRvIGNhY2hlICcke3VybH0nIGJ1dCB0aGUgcmVzcG9uc2Ugd2FzIG5vdCBgICsgYGRlZmluZWQuYDtcbiAgICAgIH0sXG4gICAgICAnbm8tcmVzcG9uc2UnOiAoe1xuICAgICAgICB1cmwsXG4gICAgICAgIGVycm9yXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGxldCBtZXNzYWdlID0gYFRoZSBzdHJhdGVneSBjb3VsZCBub3QgZ2VuZXJhdGUgYSByZXNwb25zZSBmb3IgJyR7dXJsfScuYDtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgbWVzc2FnZSArPSBgIFRoZSB1bmRlcmx5aW5nIGVycm9yIGlzICR7ZXJyb3J9LmA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICB9LFxuICAgICAgJ2JhZC1wcmVjYWNoaW5nLXJlc3BvbnNlJzogKHtcbiAgICAgICAgdXJsLFxuICAgICAgICBzdGF0dXNcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgcHJlY2FjaGluZyByZXF1ZXN0IGZvciAnJHt1cmx9JyBmYWlsZWRgICsgKHN0YXR1cyA/IGAgd2l0aCBhbiBIVFRQIHN0YXR1cyBvZiAke3N0YXR1c30uYCA6IGAuYCk7XG4gICAgICB9LFxuICAgICAgJ25vbi1wcmVjYWNoZWQtdXJsJzogKHtcbiAgICAgICAgdXJsXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwoJyR7dXJsfScpIHdhcyBjYWxsZWQsIGJ1dCB0aGF0IFVSTCBpcyBgICsgYG5vdCBwcmVjYWNoZWQuIFBsZWFzZSBwYXNzIGluIGEgVVJMIHRoYXQgaXMgcHJlY2FjaGVkIGluc3RlYWQuYDtcbiAgICAgIH0sXG4gICAgICAnYWRkLXRvLWNhY2hlLWxpc3QtY29uZmxpY3RpbmctaW50ZWdyaXRpZXMnOiAoe1xuICAgICAgICB1cmxcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUd28gb2YgdGhlIGVudHJpZXMgcGFzc2VkIHRvIGAgKyBgJ3dvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXIuYWRkVG9DYWNoZUxpc3QoKScgaGFkIHRoZSBVUkwgYCArIGAke3VybH0gd2l0aCBkaWZmZXJlbnQgaW50ZWdyaXR5IHZhbHVlcy4gUGxlYXNlIHJlbW92ZSBvbmUgb2YgdGhlbS5gO1xuICAgICAgfSxcbiAgICAgICdtaXNzaW5nLXByZWNhY2hlLWVudHJ5JzogKHtcbiAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICB1cmxcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBVbmFibGUgdG8gZmluZCBhIHByZWNhY2hlZCByZXNwb25zZSBpbiAke2NhY2hlTmFtZX0gZm9yICR7dXJsfS5gO1xuICAgICAgfSxcbiAgICAgICdjcm9zcy1vcmlnaW4tY29weS1yZXNwb25zZSc6ICh7XG4gICAgICAgIG9yaWdpblxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYHdvcmtib3gtY29yZS5jb3B5UmVzcG9uc2UoKSBjYW4gb25seSBiZSB1c2VkIHdpdGggc2FtZS1vcmlnaW4gYCArIGByZXNwb25zZXMuIEl0IHdhcyBwYXNzZWQgYSByZXNwb25zZSB3aXRoIG9yaWdpbiAke29yaWdpbn0uYDtcbiAgICAgIH0sXG4gICAgICAnb3BhcXVlLXN0cmVhbXMtc291cmNlJzogKHtcbiAgICAgICAgdHlwZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gYE9uZSBvZiB0aGUgd29ya2JveC1zdHJlYW1zIHNvdXJjZXMgcmVzdWx0ZWQgaW4gYW4gYCArIGAnJHt0eXBlfScgcmVzcG9uc2UuYDtcbiAgICAgICAgaWYgKHR5cGUgPT09ICdvcGFxdWVyZWRpcmVjdCcpIHtcbiAgICAgICAgICByZXR1cm4gYCR7bWVzc2FnZX0gUGxlYXNlIGRvIG5vdCB1c2UgYSBuYXZpZ2F0aW9uIHJlcXVlc3QgdGhhdCByZXN1bHRzIGAgKyBgaW4gYSByZWRpcmVjdCBhcyBhIHNvdXJjZS5gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHttZXNzYWdlfSBQbGVhc2UgZW5zdXJlIHlvdXIgc291cmNlcyBhcmUgQ09SUy1lbmFibGVkLmA7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IGdlbmVyYXRvckZ1bmN0aW9uID0gKGNvZGUsIGRldGFpbHMgPSB7fSkgPT4ge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IG1lc3NhZ2VzW2NvZGVdO1xuICAgICAgaWYgKCFtZXNzYWdlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5hYmxlIHRvIGZpbmQgbWVzc2FnZSBmb3IgY29kZSAnJHtjb2RlfScuYCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbWVzc2FnZShkZXRhaWxzKTtcbiAgICB9O1xuICAgIGNvbnN0IG1lc3NhZ2VHZW5lcmF0b3IgPSBnZW5lcmF0b3JGdW5jdGlvbjtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFdvcmtib3ggZXJyb3JzIHNob3VsZCBiZSB0aHJvd24gd2l0aCB0aGlzIGNsYXNzLlxuICAgICAqIFRoaXMgYWxsb3dzIHVzZSB0byBlbnN1cmUgdGhlIHR5cGUgZWFzaWx5IGluIHRlc3RzLFxuICAgICAqIGhlbHBzIGRldmVsb3BlcnMgaWRlbnRpZnkgZXJyb3JzIGZyb20gd29ya2JveFxuICAgICAqIGVhc2lseSBhbmQgYWxsb3dzIHVzZSB0byBvcHRpbWlzZSBlcnJvclxuICAgICAqIG1lc3NhZ2VzIGNvcnJlY3RseS5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY2xhc3MgV29ya2JveEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICAgICAgLyoqXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IGVycm9yQ29kZSBUaGUgZXJyb3IgY29kZSB0aGF0XG4gICAgICAgKiBpZGVudGlmaWVzIHRoaXMgcGFydGljdWxhciBlcnJvci5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0PX0gZGV0YWlscyBBbnkgcmVsZXZhbnQgYXJndW1lbnRzXG4gICAgICAgKiB0aGF0IHdpbGwgaGVscCBkZXZlbG9wZXJzIGlkZW50aWZ5IGlzc3VlcyBzaG91bGRcbiAgICAgICAqIGJlIGFkZGVkIGFzIGEga2V5IG9uIHRoZSBjb250ZXh0IG9iamVjdC5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IoZXJyb3JDb2RlLCBkZXRhaWxzKSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBtZXNzYWdlR2VuZXJhdG9yKGVycm9yQ29kZSwgZGV0YWlscyk7XG4gICAgICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgICAgICB0aGlzLm5hbWUgPSBlcnJvckNvZGU7XG4gICAgICAgIHRoaXMuZGV0YWlscyA9IGRldGFpbHM7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLypcbiAgICAgKiBUaGlzIG1ldGhvZCB0aHJvd3MgaWYgdGhlIHN1cHBsaWVkIHZhbHVlIGlzIG5vdCBhbiBhcnJheS5cbiAgICAgKiBUaGUgZGVzdHJ1Y3RlZCB2YWx1ZXMgYXJlIHJlcXVpcmVkIHRvIHByb2R1Y2UgYSBtZWFuaW5nZnVsIGVycm9yIGZvciB1c2Vycy5cbiAgICAgKiBUaGUgZGVzdHJ1Y3RlZCBhbmQgcmVzdHJ1Y3R1cmVkIG9iamVjdCBpcyBzbyBpdCdzIGNsZWFyIHdoYXQgaXNcbiAgICAgKiBuZWVkZWQuXG4gICAgICovXG4gICAgY29uc3QgaXNBcnJheSA9ICh2YWx1ZSwgZGV0YWlscykgPT4ge1xuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdub3QtYW4tYXJyYXknLCBkZXRhaWxzKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGhhc01ldGhvZCA9IChvYmplY3QsIGV4cGVjdGVkTWV0aG9kLCBkZXRhaWxzKSA9PiB7XG4gICAgICBjb25zdCB0eXBlID0gdHlwZW9mIG9iamVjdFtleHBlY3RlZE1ldGhvZF07XG4gICAgICBpZiAodHlwZSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBkZXRhaWxzWydleHBlY3RlZE1ldGhvZCddID0gZXhwZWN0ZWRNZXRob2Q7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ21pc3NpbmctYS1tZXRob2QnLCBkZXRhaWxzKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGlzVHlwZSA9IChvYmplY3QsIGV4cGVjdGVkVHlwZSwgZGV0YWlscykgPT4ge1xuICAgICAgaWYgKHR5cGVvZiBvYmplY3QgIT09IGV4cGVjdGVkVHlwZSkge1xuICAgICAgICBkZXRhaWxzWydleHBlY3RlZFR5cGUnXSA9IGV4cGVjdGVkVHlwZTtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignaW5jb3JyZWN0LXR5cGUnLCBkZXRhaWxzKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGlzSW5zdGFuY2UgPSAob2JqZWN0LFxuICAgIC8vIE5lZWQgdGhlIGdlbmVyYWwgdHlwZSB0byBkbyB0aGUgY2hlY2sgbGF0ZXIuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbiAgICBleHBlY3RlZENsYXNzLCBkZXRhaWxzKSA9PiB7XG4gICAgICBpZiAoIShvYmplY3QgaW5zdGFuY2VvZiBleHBlY3RlZENsYXNzKSkge1xuICAgICAgICBkZXRhaWxzWydleHBlY3RlZENsYXNzTmFtZSddID0gZXhwZWN0ZWRDbGFzcy5uYW1lO1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdpbmNvcnJlY3QtY2xhc3MnLCBkZXRhaWxzKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGlzT25lT2YgPSAodmFsdWUsIHZhbGlkVmFsdWVzLCBkZXRhaWxzKSA9PiB7XG4gICAgICBpZiAoIXZhbGlkVmFsdWVzLmluY2x1ZGVzKHZhbHVlKSkge1xuICAgICAgICBkZXRhaWxzWyd2YWxpZFZhbHVlRGVzY3JpcHRpb24nXSA9IGBWYWxpZCB2YWx1ZXMgYXJlICR7SlNPTi5zdHJpbmdpZnkodmFsaWRWYWx1ZXMpfS5gO1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdpbnZhbGlkLXZhbHVlJywgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBpc0FycmF5T2ZDbGFzcyA9ICh2YWx1ZSxcbiAgICAvLyBOZWVkIGdlbmVyYWwgdHlwZSB0byBkbyBjaGVjayBsYXRlci5cbiAgICBleHBlY3RlZENsYXNzLFxuICAgIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICBkZXRhaWxzKSA9PiB7XG4gICAgICBjb25zdCBlcnJvciA9IG5ldyBXb3JrYm94RXJyb3IoJ25vdC1hcnJheS1vZi1jbGFzcycsIGRldGFpbHMpO1xuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiB2YWx1ZSkge1xuICAgICAgICBpZiAoIShpdGVtIGluc3RhbmNlb2YgZXhwZWN0ZWRDbGFzcykpIHtcbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgZmluYWxBc3NlcnRFeHBvcnRzID0ge1xuICAgICAgaGFzTWV0aG9kLFxuICAgICAgaXNBcnJheSxcbiAgICAgIGlzSW5zdGFuY2UsXG4gICAgICBpc09uZU9mLFxuICAgICAgaXNUeXBlLFxuICAgICAgaXNBcnJheU9mQ2xhc3NcbiAgICB9O1xuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRyeSB7XG4gICAgICBzZWxmWyd3b3JrYm94OnJvdXRpbmc6Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFRoZSBkZWZhdWx0IEhUVFAgbWV0aG9kLCAnR0VUJywgdXNlZCB3aGVuIHRoZXJlJ3Mgbm8gc3BlY2lmaWMgbWV0aG9kXG4gICAgICogY29uZmlndXJlZCBmb3IgYSByb3V0ZS5cbiAgICAgKlxuICAgICAqIEB0eXBlIHtzdHJpbmd9XG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNvbnN0IGRlZmF1bHRNZXRob2QgPSAnR0VUJztcbiAgICAvKipcbiAgICAgKiBUaGUgbGlzdCBvZiB2YWxpZCBIVFRQIG1ldGhvZHMgYXNzb2NpYXRlZCB3aXRoIHJlcXVlc3RzIHRoYXQgY291bGQgYmUgcm91dGVkLlxuICAgICAqXG4gICAgICogQHR5cGUge0FycmF5PHN0cmluZz59XG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNvbnN0IHZhbGlkTWV0aG9kcyA9IFsnREVMRVRFJywgJ0dFVCcsICdIRUFEJywgJ1BBVENIJywgJ1BPU1QnLCAnUFVUJ107XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9uKCl8T2JqZWN0fSBoYW5kbGVyIEVpdGhlciBhIGZ1bmN0aW9uLCBvciBhbiBvYmplY3Qgd2l0aCBhXG4gICAgICogJ2hhbmRsZScgbWV0aG9kLlxuICAgICAqIEByZXR1cm4ge09iamVjdH0gQW4gb2JqZWN0IHdpdGggYSBoYW5kbGUgbWV0aG9kLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjb25zdCBub3JtYWxpemVIYW5kbGVyID0gaGFuZGxlciA9PiB7XG4gICAgICBpZiAoaGFuZGxlciAmJiB0eXBlb2YgaGFuZGxlciA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5oYXNNZXRob2QoaGFuZGxlciwgJ2hhbmRsZScsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGUnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdoYW5kbGVyJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBoYW5kbGVyO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUoaGFuZGxlciwgJ2Z1bmN0aW9uJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZScsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ2hhbmRsZXInXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBoYW5kbGU6IGhhbmRsZXJcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQSBgUm91dGVgIGNvbnNpc3RzIG9mIGEgcGFpciBvZiBjYWxsYmFjayBmdW5jdGlvbnMsIFwibWF0Y2hcIiBhbmQgXCJoYW5kbGVyXCIuXG4gICAgICogVGhlIFwibWF0Y2hcIiBjYWxsYmFjayBkZXRlcm1pbmUgaWYgYSByb3V0ZSBzaG91bGQgYmUgdXNlZCB0byBcImhhbmRsZVwiIGFcbiAgICAgKiByZXF1ZXN0IGJ5IHJldHVybmluZyBhIG5vbi1mYWxzeSB2YWx1ZSBpZiBpdCBjYW4uIFRoZSBcImhhbmRsZXJcIiBjYWxsYmFja1xuICAgICAqIGlzIGNhbGxlZCB3aGVuIHRoZXJlIGlzIGEgbWF0Y2ggYW5kIHNob3VsZCByZXR1cm4gYSBQcm9taXNlIHRoYXQgcmVzb2x2ZXNcbiAgICAgKiB0byBhIGBSZXNwb25zZWAuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1yb3V0aW5nXG4gICAgICovXG4gICAgY2xhc3MgUm91dGUge1xuICAgICAgLyoqXG4gICAgICAgKiBDb25zdHJ1Y3RvciBmb3IgUm91dGUgY2xhc3MuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+bWF0Y2hDYWxsYmFja30gbWF0Y2hcbiAgICAgICAqIEEgY2FsbGJhY2sgZnVuY3Rpb24gdGhhdCBkZXRlcm1pbmVzIHdoZXRoZXIgdGhlIHJvdXRlIG1hdGNoZXMgYSBnaXZlblxuICAgICAgICogYGZldGNoYCBldmVudCBieSByZXR1cm5pbmcgYSBub24tZmFsc3kgdmFsdWUuXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IGhhbmRsZXIgQSBjYWxsYmFja1xuICAgICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXNvbHZpbmcgdG8gYSBSZXNwb25zZS5cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbbWV0aG9kPSdHRVQnXSBUaGUgSFRUUCBtZXRob2QgdG8gbWF0Y2ggdGhlIFJvdXRlXG4gICAgICAgKiBhZ2FpbnN0LlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihtYXRjaCwgaGFuZGxlciwgbWV0aG9kID0gZGVmYXVsdE1ldGhvZCkge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShtYXRjaCwgJ2Z1bmN0aW9uJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZScsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ21hdGNoJ1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChtZXRob2QpIHtcbiAgICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc09uZU9mKG1ldGhvZCwgdmFsaWRNZXRob2RzLCB7XG4gICAgICAgICAgICAgIHBhcmFtTmFtZTogJ21ldGhvZCdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBUaGVzZSB2YWx1ZXMgYXJlIHJlZmVyZW5jZWQgZGlyZWN0bHkgYnkgUm91dGVyIHNvIGNhbm5vdCBiZVxuICAgICAgICAvLyBhbHRlcmVkIGJ5IG1pbmlmaWNhdG9uLlxuICAgICAgICB0aGlzLmhhbmRsZXIgPSBub3JtYWxpemVIYW5kbGVyKGhhbmRsZXIpO1xuICAgICAgICB0aGlzLm1hdGNoID0gbWF0Y2g7XG4gICAgICAgIHRoaXMubWV0aG9kID0gbWV0aG9kO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmctaGFuZGxlckNhbGxiYWNrfSBoYW5kbGVyIEEgY2FsbGJhY2tcbiAgICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzb2x2aW5nIHRvIGEgUmVzcG9uc2VcbiAgICAgICAqL1xuICAgICAgc2V0Q2F0Y2hIYW5kbGVyKGhhbmRsZXIpIHtcbiAgICAgICAgdGhpcy5jYXRjaEhhbmRsZXIgPSBub3JtYWxpemVIYW5kbGVyKGhhbmRsZXIpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFJlZ0V4cFJvdXRlIG1ha2VzIGl0IGVhc3kgdG8gY3JlYXRlIGEgcmVndWxhciBleHByZXNzaW9uIGJhc2VkXG4gICAgICoge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZX0uXG4gICAgICpcbiAgICAgKiBGb3Igc2FtZS1vcmlnaW4gcmVxdWVzdHMgdGhlIFJlZ0V4cCBvbmx5IG5lZWRzIHRvIG1hdGNoIHBhcnQgb2YgdGhlIFVSTC4gRm9yXG4gICAgICogcmVxdWVzdHMgYWdhaW5zdCB0aGlyZC1wYXJ0eSBzZXJ2ZXJzLCB5b3UgbXVzdCBkZWZpbmUgYSBSZWdFeHAgdGhhdCBtYXRjaGVzXG4gICAgICogdGhlIHN0YXJ0IG9mIHRoZSBVUkwuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1yb3V0aW5nXG4gICAgICogQGV4dGVuZHMgd29ya2JveC1yb3V0aW5nLlJvdXRlXG4gICAgICovXG4gICAgY2xhc3MgUmVnRXhwUm91dGUgZXh0ZW5kcyBSb3V0ZSB7XG4gICAgICAvKipcbiAgICAgICAqIElmIHRoZSByZWd1bGFyIGV4cHJlc3Npb24gY29udGFpbnNcbiAgICAgICAqIFtjYXB0dXJlIGdyb3Vwc117QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvUmVnRXhwI2dyb3VwaW5nLWJhY2stcmVmZXJlbmNlc30sXG4gICAgICAgKiB0aGUgY2FwdHVyZWQgdmFsdWVzIHdpbGwgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAgICoge0BsaW5rIHdvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IGBwYXJhbXNgXG4gICAgICAgKiBhcmd1bWVudC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1JlZ0V4cH0gcmVnRXhwIFRoZSByZWd1bGFyIGV4cHJlc3Npb24gdG8gbWF0Y2ggYWdhaW5zdCBVUkxzLlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBoYW5kbGVyIEEgY2FsbGJhY2tcbiAgICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzdWx0aW5nIGluIGEgUmVzcG9uc2UuXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW21ldGhvZD0nR0VUJ10gVGhlIEhUVFAgbWV0aG9kIHRvIG1hdGNoIHRoZSBSb3V0ZVxuICAgICAgICogYWdhaW5zdC5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IocmVnRXhwLCBoYW5kbGVyLCBtZXRob2QpIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0luc3RhbmNlKHJlZ0V4cCwgUmVnRXhwLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JlZ0V4cFJvdXRlJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAncGF0dGVybidcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtYXRjaCA9ICh7XG4gICAgICAgICAgdXJsXG4gICAgICAgIH0pID0+IHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSByZWdFeHAuZXhlYyh1cmwuaHJlZik7XG4gICAgICAgICAgLy8gUmV0dXJuIGltbWVkaWF0ZWx5IGlmIHRoZXJlJ3Mgbm8gbWF0Y2guXG4gICAgICAgICAgaWYgKCFyZXN1bHQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gUmVxdWlyZSB0aGF0IHRoZSBtYXRjaCBzdGFydCBhdCB0aGUgZmlyc3QgY2hhcmFjdGVyIGluIHRoZSBVUkwgc3RyaW5nXG4gICAgICAgICAgLy8gaWYgaXQncyBhIGNyb3NzLW9yaWdpbiByZXF1ZXN0LlxuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzI4MSBmb3IgdGhlIGNvbnRleHRcbiAgICAgICAgICAvLyBiZWhpbmQgdGhpcyBiZWhhdmlvci5cbiAgICAgICAgICBpZiAodXJsLm9yaWdpbiAhPT0gbG9jYXRpb24ub3JpZ2luICYmIHJlc3VsdC5pbmRleCAhPT0gMCkge1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYFRoZSByZWd1bGFyIGV4cHJlc3Npb24gJyR7cmVnRXhwLnRvU3RyaW5nKCl9JyBvbmx5IHBhcnRpYWxseSBtYXRjaGVkIGAgKyBgYWdhaW5zdCB0aGUgY3Jvc3Mtb3JpZ2luIFVSTCAnJHt1cmwudG9TdHJpbmcoKX0nLiBSZWdFeHBSb3V0ZSdzIHdpbGwgb25seSBgICsgYGhhbmRsZSBjcm9zcy1vcmlnaW4gcmVxdWVzdHMgaWYgdGhleSBtYXRjaCB0aGUgZW50aXJlIFVSTC5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gSWYgdGhlIHJvdXRlIG1hdGNoZXMsIGJ1dCB0aGVyZSBhcmVuJ3QgYW55IGNhcHR1cmUgZ3JvdXBzIGRlZmluZWQsIHRoZW5cbiAgICAgICAgICAvLyB0aGlzIHdpbGwgcmV0dXJuIFtdLCB3aGljaCBpcyB0cnV0aHkgYW5kIHRoZXJlZm9yZSBzdWZmaWNpZW50IHRvXG4gICAgICAgICAgLy8gaW5kaWNhdGUgYSBtYXRjaC5cbiAgICAgICAgICAvLyBJZiB0aGVyZSBhcmUgY2FwdHVyZSBncm91cHMsIHRoZW4gaXQgd2lsbCByZXR1cm4gdGhlaXIgdmFsdWVzLlxuICAgICAgICAgIHJldHVybiByZXN1bHQuc2xpY2UoMSk7XG4gICAgICAgIH07XG4gICAgICAgIHN1cGVyKG1hdGNoLCBoYW5kbGVyLCBtZXRob2QpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IGdldEZyaWVuZGx5VVJMID0gdXJsID0+IHtcbiAgICAgIGNvbnN0IHVybE9iaiA9IG5ldyBVUkwoU3RyaW5nKHVybCksIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjMyM1xuICAgICAgLy8gV2Ugd2FudCB0byBpbmNsdWRlIGV2ZXJ5dGhpbmcsIGV4Y2VwdCBmb3IgdGhlIG9yaWdpbiBpZiBpdCdzIHNhbWUtb3JpZ2luLlxuICAgICAgcmV0dXJuIHVybE9iai5ocmVmLnJlcGxhY2UobmV3IFJlZ0V4cChgXiR7bG9jYXRpb24ub3JpZ2lufWApLCAnJyk7XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFRoZSBSb3V0ZXIgY2FuIGJlIHVzZWQgdG8gcHJvY2VzcyBhIGBGZXRjaEV2ZW50YCB1c2luZyBvbmUgb3IgbW9yZVxuICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmcuUm91dGV9LCByZXNwb25kaW5nIHdpdGggYSBgUmVzcG9uc2VgIGlmXG4gICAgICogYSBtYXRjaGluZyByb3V0ZSBleGlzdHMuXG4gICAgICpcbiAgICAgKiBJZiBubyByb3V0ZSBtYXRjaGVzIGEgZ2l2ZW4gYSByZXF1ZXN0LCB0aGUgUm91dGVyIHdpbGwgdXNlIGEgXCJkZWZhdWx0XCJcbiAgICAgKiBoYW5kbGVyIGlmIG9uZSBpcyBkZWZpbmVkLlxuICAgICAqXG4gICAgICogU2hvdWxkIHRoZSBtYXRjaGluZyBSb3V0ZSB0aHJvdyBhbiBlcnJvciwgdGhlIFJvdXRlciB3aWxsIHVzZSBhIFwiY2F0Y2hcIlxuICAgICAqIGhhbmRsZXIgaWYgb25lIGlzIGRlZmluZWQgdG8gZ3JhY2VmdWxseSBkZWFsIHdpdGggaXNzdWVzIGFuZCByZXNwb25kIHdpdGggYVxuICAgICAqIFJlcXVlc3QuXG4gICAgICpcbiAgICAgKiBJZiBhIHJlcXVlc3QgbWF0Y2hlcyBtdWx0aXBsZSByb3V0ZXMsIHRoZSAqKmVhcmxpZXN0KiogcmVnaXN0ZXJlZCByb3V0ZSB3aWxsXG4gICAgICogYmUgdXNlZCB0byByZXNwb25kIHRvIHRoZSByZXF1ZXN0LlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcm91dGluZ1xuICAgICAqL1xuICAgIGNsYXNzIFJvdXRlciB7XG4gICAgICAvKipcbiAgICAgICAqIEluaXRpYWxpemVzIGEgbmV3IFJvdXRlci5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuX3JvdXRlcyA9IG5ldyBNYXAoKTtcbiAgICAgICAgdGhpcy5fZGVmYXVsdEhhbmRsZXJNYXAgPSBuZXcgTWFwKCk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEByZXR1cm4ge01hcDxzdHJpbmcsIEFycmF5PHdvcmtib3gtcm91dGluZy5Sb3V0ZT4+fSByb3V0ZXMgQSBgTWFwYCBvZiBIVFRQXG4gICAgICAgKiBtZXRob2QgbmFtZSAoJ0dFVCcsIGV0Yy4pIHRvIGFuIGFycmF5IG9mIGFsbCB0aGUgY29ycmVzcG9uZGluZyBgUm91dGVgXG4gICAgICAgKiBpbnN0YW5jZXMgdGhhdCBhcmUgcmVnaXN0ZXJlZC5cbiAgICAgICAqL1xuICAgICAgZ2V0IHJvdXRlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JvdXRlcztcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQWRkcyBhIGZldGNoIGV2ZW50IGxpc3RlbmVyIHRvIHJlc3BvbmQgdG8gZXZlbnRzIHdoZW4gYSByb3V0ZSBtYXRjaGVzXG4gICAgICAgKiB0aGUgZXZlbnQncyByZXF1ZXN0LlxuICAgICAgICovXG4gICAgICBhZGRGZXRjaExpc3RlbmVyKCkge1xuICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL01pY3Jvc29mdC9UeXBlU2NyaXB0L2lzc3Vlcy8yODM1NyNpc3N1ZWNvbW1lbnQtNDM2NDg0NzA1XG4gICAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignZmV0Y2gnLCBldmVudCA9PiB7XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgcmVxdWVzdFxuICAgICAgICAgIH0gPSBldmVudDtcbiAgICAgICAgICBjb25zdCByZXNwb25zZVByb21pc2UgPSB0aGlzLmhhbmRsZVJlcXVlc3Qoe1xuICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgIGV2ZW50XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKHJlc3BvbnNlUHJvbWlzZSkge1xuICAgICAgICAgICAgZXZlbnQucmVzcG9uZFdpdGgocmVzcG9uc2VQcm9taXNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBZGRzIGEgbWVzc2FnZSBldmVudCBsaXN0ZW5lciBmb3IgVVJMcyB0byBjYWNoZSBmcm9tIHRoZSB3aW5kb3cuXG4gICAgICAgKiBUaGlzIGlzIHVzZWZ1bCB0byBjYWNoZSByZXNvdXJjZXMgbG9hZGVkIG9uIHRoZSBwYWdlIHByaW9yIHRvIHdoZW4gdGhlXG4gICAgICAgKiBzZXJ2aWNlIHdvcmtlciBzdGFydGVkIGNvbnRyb2xsaW5nIGl0LlxuICAgICAgICpcbiAgICAgICAqIFRoZSBmb3JtYXQgb2YgdGhlIG1lc3NhZ2UgZGF0YSBzZW50IGZyb20gdGhlIHdpbmRvdyBzaG91bGQgYmUgYXMgZm9sbG93cy5cbiAgICAgICAqIFdoZXJlIHRoZSBgdXJsc1RvQ2FjaGVgIGFycmF5IG1heSBjb25zaXN0IG9mIFVSTCBzdHJpbmdzIG9yIGFuIGFycmF5IG9mXG4gICAgICAgKiBVUkwgc3RyaW5nICsgYHJlcXVlc3RJbml0YCBvYmplY3QgKHRoZSBzYW1lIGFzIHlvdSdkIHBhc3MgdG8gYGZldGNoKClgKS5cbiAgICAgICAqXG4gICAgICAgKiBgYGBcbiAgICAgICAqIHtcbiAgICAgICAqICAgdHlwZTogJ0NBQ0hFX1VSTFMnLFxuICAgICAgICogICBwYXlsb2FkOiB7XG4gICAgICAgKiAgICAgdXJsc1RvQ2FjaGU6IFtcbiAgICAgICAqICAgICAgICcuL3NjcmlwdDEuanMnLFxuICAgICAgICogICAgICAgJy4vc2NyaXB0Mi5qcycsXG4gICAgICAgKiAgICAgICBbJy4vc2NyaXB0My5qcycsIHttb2RlOiAnbm8tY29ycyd9XSxcbiAgICAgICAqICAgICBdLFxuICAgICAgICogICB9LFxuICAgICAgICogfVxuICAgICAgICogYGBgXG4gICAgICAgKi9cbiAgICAgIGFkZENhY2hlTGlzdGVuZXIoKSB7XG4gICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vTWljcm9zb2Z0L1R5cGVTY3JpcHQvaXNzdWVzLzI4MzU3I2lzc3VlY29tbWVudC00MzY0ODQ3MDVcbiAgICAgICAgc2VsZi5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgZXZlbnQgPT4ge1xuICAgICAgICAgIC8vIGV2ZW50LmRhdGEgaXMgdHlwZSAnYW55J1xuICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLW1lbWJlci1hY2Nlc3NcbiAgICAgICAgICBpZiAoZXZlbnQuZGF0YSAmJiBldmVudC5kYXRhLnR5cGUgPT09ICdDQUNIRV9VUkxTJykge1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtYXNzaWdubWVudFxuICAgICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgICBwYXlsb2FkXG4gICAgICAgICAgICB9ID0gZXZlbnQuZGF0YTtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBDYWNoaW5nIFVSTHMgZnJvbSB0aGUgd2luZG93YCwgcGF5bG9hZC51cmxzVG9DYWNoZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0UHJvbWlzZXMgPSBQcm9taXNlLmFsbChwYXlsb2FkLnVybHNUb0NhY2hlLm1hcChlbnRyeSA9PiB7XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgZW50cnkgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgZW50cnkgPSBbZW50cnldO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdCguLi5lbnRyeSk7XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVJlcXVlc3Qoe1xuICAgICAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICAgICAgZXZlbnRcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIC8vIFRPRE8ocGhpbGlwd2FsdG9uKTogVHlwZVNjcmlwdCBlcnJvcnMgd2l0aG91dCB0aGlzIHR5cGVjYXN0IGZvclxuICAgICAgICAgICAgICAvLyBzb21lIHJlYXNvbiAocHJvYmFibHkgYSBidWcpLiBUaGUgcmVhbCB0eXBlIGhlcmUgc2hvdWxkIHdvcmsgYnV0XG4gICAgICAgICAgICAgIC8vIGRvZXNuJ3Q6IGBBcnJheTxQcm9taXNlPFJlc3BvbnNlPiB8IHVuZGVmaW5lZD5gLlxuICAgICAgICAgICAgfSkpOyAvLyBUeXBlU2NyaXB0XG4gICAgICAgICAgICBldmVudC53YWl0VW50aWwocmVxdWVzdFByb21pc2VzKTtcbiAgICAgICAgICAgIC8vIElmIGEgTWVzc2FnZUNoYW5uZWwgd2FzIHVzZWQsIHJlcGx5IHRvIHRoZSBtZXNzYWdlIG9uIHN1Y2Nlc3MuXG4gICAgICAgICAgICBpZiAoZXZlbnQucG9ydHMgJiYgZXZlbnQucG9ydHNbMF0pIHtcbiAgICAgICAgICAgICAgdm9pZCByZXF1ZXN0UHJvbWlzZXMudGhlbigoKSA9PiBldmVudC5wb3J0c1swXS5wb3N0TWVzc2FnZSh0cnVlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQXBwbHkgdGhlIHJvdXRpbmcgcnVsZXMgdG8gYSBGZXRjaEV2ZW50IG9iamVjdCB0byBnZXQgYSBSZXNwb25zZSBmcm9tIGFuXG4gICAgICAgKiBhcHByb3ByaWF0ZSBSb3V0ZSdzIGhhbmRsZXIuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gb3B0aW9ucy5yZXF1ZXN0IFRoZSByZXF1ZXN0IHRvIGhhbmRsZS5cbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBvcHRpb25zLmV2ZW50IFRoZSBldmVudCB0aGF0IHRyaWdnZXJlZCB0aGVcbiAgICAgICAqICAgICByZXF1ZXN0LlxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZT58dW5kZWZpbmVkfSBBIHByb21pc2UgaXMgcmV0dXJuZWQgaWYgYVxuICAgICAgICogICAgIHJlZ2lzdGVyZWQgcm91dGUgY2FuIGhhbmRsZSB0aGUgcmVxdWVzdC4gSWYgdGhlcmUgaXMgbm8gbWF0Y2hpbmdcbiAgICAgICAqICAgICByb3V0ZSBhbmQgdGhlcmUncyBubyBgZGVmYXVsdEhhbmRsZXJgLCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cbiAgICAgICAqL1xuICAgICAgaGFuZGxlUmVxdWVzdCh7XG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGV2ZW50XG4gICAgICB9KSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNJbnN0YW5jZShyZXF1ZXN0LCBSZXF1ZXN0LCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2hhbmRsZVJlcXVlc3QnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnb3B0aW9ucy5yZXF1ZXN0J1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmVxdWVzdC51cmwsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgICBpZiAoIXVybC5wcm90b2NvbC5zdGFydHNXaXRoKCdodHRwJykpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYFdvcmtib3ggUm91dGVyIG9ubHkgc3VwcG9ydHMgVVJMcyB0aGF0IHN0YXJ0IHdpdGggJ2h0dHAnLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2FtZU9yaWdpbiA9IHVybC5vcmlnaW4gPT09IGxvY2F0aW9uLm9yaWdpbjtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgICByb3V0ZVxuICAgICAgICB9ID0gdGhpcy5maW5kTWF0Y2hpbmdSb3V0ZSh7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICBzYW1lT3JpZ2luLFxuICAgICAgICAgIHVybFxuICAgICAgICB9KTtcbiAgICAgICAgbGV0IGhhbmRsZXIgPSByb3V0ZSAmJiByb3V0ZS5oYW5kbGVyO1xuICAgICAgICBjb25zdCBkZWJ1Z01lc3NhZ2VzID0gW107XG4gICAgICAgIHtcbiAgICAgICAgICBpZiAoaGFuZGxlcikge1xuICAgICAgICAgICAgZGVidWdNZXNzYWdlcy5wdXNoKFtgRm91bmQgYSByb3V0ZSB0byBoYW5kbGUgdGhpcyByZXF1ZXN0OmAsIHJvdXRlXSk7XG4gICAgICAgICAgICBpZiAocGFyYW1zKSB7XG4gICAgICAgICAgICAgIGRlYnVnTWVzc2FnZXMucHVzaChbYFBhc3NpbmcgdGhlIGZvbGxvd2luZyBwYXJhbXMgdG8gdGhlIHJvdXRlJ3MgaGFuZGxlcjpgLCBwYXJhbXNdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgd2UgZG9uJ3QgaGF2ZSBhIGhhbmRsZXIgYmVjYXVzZSB0aGVyZSB3YXMgbm8gbWF0Y2hpbmcgcm91dGUsIHRoZW5cbiAgICAgICAgLy8gZmFsbCBiYWNrIHRvIGRlZmF1bHRIYW5kbGVyIGlmIHRoYXQncyBkZWZpbmVkLlxuICAgICAgICBjb25zdCBtZXRob2QgPSByZXF1ZXN0Lm1ldGhvZDtcbiAgICAgICAgaWYgKCFoYW5kbGVyICYmIHRoaXMuX2RlZmF1bHRIYW5kbGVyTWFwLmhhcyhtZXRob2QpKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgZGVidWdNZXNzYWdlcy5wdXNoKGBGYWlsZWQgdG8gZmluZCBhIG1hdGNoaW5nIHJvdXRlLiBGYWxsaW5nIGAgKyBgYmFjayB0byB0aGUgZGVmYXVsdCBoYW5kbGVyIGZvciAke21ldGhvZH0uYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGhhbmRsZXIgPSB0aGlzLl9kZWZhdWx0SGFuZGxlck1hcC5nZXQobWV0aG9kKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWhhbmRsZXIpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICAvLyBObyBoYW5kbGVyIHNvIFdvcmtib3ggd2lsbCBkbyBub3RoaW5nLiBJZiBsb2dzIGlzIHNldCBvZiBkZWJ1Z1xuICAgICAgICAgICAgLy8gaS5lLiB2ZXJib3NlLCB3ZSBzaG91bGQgcHJpbnQgb3V0IHRoaXMgaW5mb3JtYXRpb24uXG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYE5vIHJvdXRlIGZvdW5kIGZvcjogJHtnZXRGcmllbmRseVVSTCh1cmwpfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIC8vIFdlIGhhdmUgYSBoYW5kbGVyLCBtZWFuaW5nIFdvcmtib3ggaXMgZ29pbmcgdG8gaGFuZGxlIHRoZSByb3V0ZS5cbiAgICAgICAgICAvLyBwcmludCB0aGUgcm91dGluZyBkZXRhaWxzIHRvIHRoZSBjb25zb2xlLlxuICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgUm91dGVyIGlzIHJlc3BvbmRpbmcgdG86ICR7Z2V0RnJpZW5kbHlVUkwodXJsKX1gKTtcbiAgICAgICAgICBkZWJ1Z01lc3NhZ2VzLmZvckVhY2gobXNnID0+IHtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG1zZykpIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmxvZyguLi5tc2cpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmxvZyhtc2cpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFdyYXAgaW4gdHJ5IGFuZCBjYXRjaCBpbiBjYXNlIHRoZSBoYW5kbGUgbWV0aG9kIHRocm93cyBhIHN5bmNocm9ub3VzXG4gICAgICAgIC8vIGVycm9yLiBJdCBzaG91bGQgc3RpbGwgY2FsbGJhY2sgdG8gdGhlIGNhdGNoIGhhbmRsZXIuXG4gICAgICAgIGxldCByZXNwb25zZVByb21pc2U7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzcG9uc2VQcm9taXNlID0gaGFuZGxlci5oYW5kbGUoe1xuICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgcGFyYW1zXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHJlc3BvbnNlUHJvbWlzZSA9IFByb21pc2UucmVqZWN0KGVycik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gR2V0IHJvdXRlJ3MgY2F0Y2ggaGFuZGxlciwgaWYgaXQgZXhpc3RzXG4gICAgICAgIGNvbnN0IGNhdGNoSGFuZGxlciA9IHJvdXRlICYmIHJvdXRlLmNhdGNoSGFuZGxlcjtcbiAgICAgICAgaWYgKHJlc3BvbnNlUHJvbWlzZSBpbnN0YW5jZW9mIFByb21pc2UgJiYgKHRoaXMuX2NhdGNoSGFuZGxlciB8fCBjYXRjaEhhbmRsZXIpKSB7XG4gICAgICAgICAgcmVzcG9uc2VQcm9taXNlID0gcmVzcG9uc2VQcm9taXNlLmNhdGNoKGFzeW5jIGVyciA9PiB7XG4gICAgICAgICAgICAvLyBJZiB0aGVyZSdzIGEgcm91dGUgY2F0Y2ggaGFuZGxlciwgcHJvY2VzcyB0aGF0IGZpcnN0XG4gICAgICAgICAgICBpZiAoY2F0Y2hIYW5kbGVyKSB7XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAvLyBTdGlsbCBpbmNsdWRlIFVSTCBoZXJlIGFzIGl0IHdpbGwgYmUgYXN5bmMgZnJvbSB0aGUgY29uc29sZSBncm91cFxuICAgICAgICAgICAgICAgIC8vIGFuZCBtYXkgbm90IG1ha2Ugc2Vuc2Ugd2l0aG91dCB0aGUgVVJMXG4gICAgICAgICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBFcnJvciB0aHJvd24gd2hlbiByZXNwb25kaW5nIHRvOiBgICsgYCAke2dldEZyaWVuZGx5VVJMKHVybCl9LiBGYWxsaW5nIGJhY2sgdG8gcm91dGUncyBDYXRjaCBIYW5kbGVyLmApO1xuICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihgRXJyb3IgdGhyb3duIGJ5OmAsIHJvdXRlKTtcbiAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCBjYXRjaEhhbmRsZXIuaGFuZGxlKHtcbiAgICAgICAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgICAgIHBhcmFtc1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjYXRjaEVycikge1xuICAgICAgICAgICAgICAgIGlmIChjYXRjaEVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICBlcnIgPSBjYXRjaEVycjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0aGlzLl9jYXRjaEhhbmRsZXIpIHtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vIFN0aWxsIGluY2x1ZGUgVVJMIGhlcmUgYXMgaXQgd2lsbCBiZSBhc3luYyBmcm9tIHRoZSBjb25zb2xlIGdyb3VwXG4gICAgICAgICAgICAgICAgLy8gYW5kIG1heSBub3QgbWFrZSBzZW5zZSB3aXRob3V0IHRoZSBVUkxcbiAgICAgICAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYEVycm9yIHRocm93biB3aGVuIHJlc3BvbmRpbmcgdG86IGAgKyBgICR7Z2V0RnJpZW5kbHlVUkwodXJsKX0uIEZhbGxpbmcgYmFjayB0byBnbG9iYWwgQ2F0Y2ggSGFuZGxlci5gKTtcbiAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIHRocm93biBieTpgLCByb3V0ZSk7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NhdGNoSGFuZGxlci5oYW5kbGUoe1xuICAgICAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgICAgIGV2ZW50XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZVByb21pc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIENoZWNrcyBhIHJlcXVlc3QgYW5kIFVSTCAoYW5kIG9wdGlvbmFsbHkgYW4gZXZlbnQpIGFnYWluc3QgdGhlIGxpc3Qgb2ZcbiAgICAgICAqIHJlZ2lzdGVyZWQgcm91dGVzLCBhbmQgaWYgdGhlcmUncyBhIG1hdGNoLCByZXR1cm5zIHRoZSBjb3JyZXNwb25kaW5nXG4gICAgICAgKiByb3V0ZSBhbG9uZyB3aXRoIGFueSBwYXJhbXMgZ2VuZXJhdGVkIGJ5IHRoZSBtYXRjaC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAgICogQHBhcmFtIHtVUkx9IG9wdGlvbnMudXJsXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IG9wdGlvbnMuc2FtZU9yaWdpbiBUaGUgcmVzdWx0IG9mIGNvbXBhcmluZyBgdXJsLm9yaWdpbmBcbiAgICAgICAqICAgICBhZ2FpbnN0IHRoZSBjdXJyZW50IG9yaWdpbi5cbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gb3B0aW9ucy5yZXF1ZXN0IFRoZSByZXF1ZXN0IHRvIG1hdGNoLlxuICAgICAgICogQHBhcmFtIHtFdmVudH0gb3B0aW9ucy5ldmVudCBUaGUgY29ycmVzcG9uZGluZyBldmVudC5cbiAgICAgICAqIEByZXR1cm4ge09iamVjdH0gQW4gb2JqZWN0IHdpdGggYHJvdXRlYCBhbmQgYHBhcmFtc2AgcHJvcGVydGllcy5cbiAgICAgICAqICAgICBUaGV5IGFyZSBwb3B1bGF0ZWQgaWYgYSBtYXRjaGluZyByb3V0ZSB3YXMgZm91bmQgb3IgYHVuZGVmaW5lZGBcbiAgICAgICAqICAgICBvdGhlcndpc2UuXG4gICAgICAgKi9cbiAgICAgIGZpbmRNYXRjaGluZ1JvdXRlKHtcbiAgICAgICAgdXJsLFxuICAgICAgICBzYW1lT3JpZ2luLFxuICAgICAgICByZXF1ZXN0LFxuICAgICAgICBldmVudFxuICAgICAgfSkge1xuICAgICAgICBjb25zdCByb3V0ZXMgPSB0aGlzLl9yb3V0ZXMuZ2V0KHJlcXVlc3QubWV0aG9kKSB8fCBbXTtcbiAgICAgICAgZm9yIChjb25zdCByb3V0ZSBvZiByb3V0ZXMpIHtcbiAgICAgICAgICBsZXQgcGFyYW1zO1xuICAgICAgICAgIC8vIHJvdXRlLm1hdGNoIHJldHVybnMgdHlwZSBhbnksIG5vdCBwb3NzaWJsZSB0byBjaGFuZ2UgcmlnaHQgbm93LlxuICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLWFzc2lnbm1lbnRcbiAgICAgICAgICBjb25zdCBtYXRjaFJlc3VsdCA9IHJvdXRlLm1hdGNoKHtcbiAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgIHNhbWVPcmlnaW4sXG4gICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnRcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAobWF0Y2hSZXN1bHQpIHtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgLy8gV2FybiBkZXZlbG9wZXJzIHRoYXQgdXNpbmcgYW4gYXN5bmMgbWF0Y2hDYWxsYmFjayBpcyBhbG1vc3QgYWx3YXlzXG4gICAgICAgICAgICAgIC8vIG5vdCB0aGUgcmlnaHQgdGhpbmcgdG8gZG8uXG4gICAgICAgICAgICAgIGlmIChtYXRjaFJlc3VsdCBpbnN0YW5jZW9mIFByb21pc2UpIHtcbiAgICAgICAgICAgICAgICBsb2dnZXIud2FybihgV2hpbGUgcm91dGluZyAke2dldEZyaWVuZGx5VVJMKHVybCl9LCBhbiBhc3luYyBgICsgYG1hdGNoQ2FsbGJhY2sgZnVuY3Rpb24gd2FzIHVzZWQuIFBsZWFzZSBjb252ZXJ0IHRoZSBgICsgYGZvbGxvd2luZyByb3V0ZSB0byB1c2UgYSBzeW5jaHJvbm91cyBtYXRjaENhbGxiYWNrIGZ1bmN0aW9uOmAsIHJvdXRlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjA3OVxuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtYXNzaWdubWVudFxuICAgICAgICAgICAgcGFyYW1zID0gbWF0Y2hSZXN1bHQ7XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwYXJhbXMpICYmIHBhcmFtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgLy8gSW5zdGVhZCBvZiBwYXNzaW5nIGFuIGVtcHR5IGFycmF5IGluIGFzIHBhcmFtcywgdXNlIHVuZGVmaW5lZC5cbiAgICAgICAgICAgICAgcGFyYW1zID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChtYXRjaFJlc3VsdC5jb25zdHJ1Y3RvciA9PT0gT2JqZWN0ICYmXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICAgICAgICBPYmplY3Qua2V5cyhtYXRjaFJlc3VsdCkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgIC8vIEluc3RlYWQgb2YgcGFzc2luZyBhbiBlbXB0eSBvYmplY3QgaW4gYXMgcGFyYW1zLCB1c2UgdW5kZWZpbmVkLlxuICAgICAgICAgICAgICBwYXJhbXMgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBtYXRjaFJlc3VsdCA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgIC8vIEZvciB0aGUgYm9vbGVhbiB2YWx1ZSB0cnVlIChyYXRoZXIgdGhhbiBqdXN0IHNvbWV0aGluZyB0cnV0aC15KSxcbiAgICAgICAgICAgICAgLy8gZG9uJ3Qgc2V0IHBhcmFtcy5cbiAgICAgICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9wdWxsLzIxMzQjaXNzdWVjb21tZW50LTUxMzkyNDM1M1xuICAgICAgICAgICAgICBwYXJhbXMgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBSZXR1cm4gZWFybHkgaWYgaGF2ZSBhIG1hdGNoLlxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgcm91dGUsXG4gICAgICAgICAgICAgIHBhcmFtc1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgbm8gbWF0Y2ggd2FzIGZvdW5kIGFib3ZlLCByZXR1cm4gYW5kIGVtcHR5IG9iamVjdC5cbiAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBEZWZpbmUgYSBkZWZhdWx0IGBoYW5kbGVyYCB0aGF0J3MgY2FsbGVkIHdoZW4gbm8gcm91dGVzIGV4cGxpY2l0bHlcbiAgICAgICAqIG1hdGNoIHRoZSBpbmNvbWluZyByZXF1ZXN0LlxuICAgICAgICpcbiAgICAgICAqIEVhY2ggSFRUUCBtZXRob2QgKCdHRVQnLCAnUE9TVCcsIGV0Yy4pIGdldHMgaXRzIG93biBkZWZhdWx0IGhhbmRsZXIuXG4gICAgICAgKlxuICAgICAgICogV2l0aG91dCBhIGRlZmF1bHQgaGFuZGxlciwgdW5tYXRjaGVkIHJlcXVlc3RzIHdpbGwgZ28gYWdhaW5zdCB0aGVcbiAgICAgICAqIG5ldHdvcmsgYXMgaWYgdGhlcmUgd2VyZSBubyBzZXJ2aWNlIHdvcmtlciBwcmVzZW50LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gaGFuZGxlciBBIGNhbGxiYWNrXG4gICAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc3VsdGluZyBpbiBhIFJlc3BvbnNlLlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFttZXRob2Q9J0dFVCddIFRoZSBIVFRQIG1ldGhvZCB0byBhc3NvY2lhdGUgd2l0aCB0aGlzXG4gICAgICAgKiBkZWZhdWx0IGhhbmRsZXIuIEVhY2ggbWV0aG9kIGhhcyBpdHMgb3duIGRlZmF1bHQuXG4gICAgICAgKi9cbiAgICAgIHNldERlZmF1bHRIYW5kbGVyKGhhbmRsZXIsIG1ldGhvZCA9IGRlZmF1bHRNZXRob2QpIHtcbiAgICAgICAgdGhpcy5fZGVmYXVsdEhhbmRsZXJNYXAuc2V0KG1ldGhvZCwgbm9ybWFsaXplSGFuZGxlcihoYW5kbGVyKSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIElmIGEgUm91dGUgdGhyb3dzIGFuIGVycm9yIHdoaWxlIGhhbmRsaW5nIGEgcmVxdWVzdCwgdGhpcyBgaGFuZGxlcmBcbiAgICAgICAqIHdpbGwgYmUgY2FsbGVkIGFuZCBnaXZlbiBhIGNoYW5jZSB0byBwcm92aWRlIGEgcmVzcG9uc2UuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBoYW5kbGVyIEEgY2FsbGJhY2tcbiAgICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzdWx0aW5nIGluIGEgUmVzcG9uc2UuXG4gICAgICAgKi9cbiAgICAgIHNldENhdGNoSGFuZGxlcihoYW5kbGVyKSB7XG4gICAgICAgIHRoaXMuX2NhdGNoSGFuZGxlciA9IG5vcm1hbGl6ZUhhbmRsZXIoaGFuZGxlcik7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJlZ2lzdGVycyBhIHJvdXRlIHdpdGggdGhlIHJvdXRlci5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZy5Sb3V0ZX0gcm91dGUgVGhlIHJvdXRlIHRvIHJlZ2lzdGVyLlxuICAgICAgICovXG4gICAgICByZWdpc3RlclJvdXRlKHJvdXRlKSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKHJvdXRlLCAnb2JqZWN0Jywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3JvdXRlJ1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5oYXNNZXRob2Qocm91dGUsICdtYXRjaCcsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdyb3V0ZSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKHJvdXRlLmhhbmRsZXIsICdvYmplY3QnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAncm91dGUnXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmhhc01ldGhvZChyb3V0ZS5oYW5kbGVyLCAnaGFuZGxlJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3JvdXRlLmhhbmRsZXInXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShyb3V0ZS5tZXRob2QsICdzdHJpbmcnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAncm91dGUubWV0aG9kJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5fcm91dGVzLmhhcyhyb3V0ZS5tZXRob2QpKSB7XG4gICAgICAgICAgdGhpcy5fcm91dGVzLnNldChyb3V0ZS5tZXRob2QsIFtdKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBHaXZlIHByZWNlZGVuY2UgdG8gYWxsIG9mIHRoZSBlYXJsaWVyIHJvdXRlcyBieSBhZGRpbmcgdGhpcyBhZGRpdGlvbmFsXG4gICAgICAgIC8vIHJvdXRlIHRvIHRoZSBlbmQgb2YgdGhlIGFycmF5LlxuICAgICAgICB0aGlzLl9yb3V0ZXMuZ2V0KHJvdXRlLm1ldGhvZCkucHVzaChyb3V0ZSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFVucmVnaXN0ZXJzIGEgcm91dGUgd2l0aCB0aGUgcm91dGVyLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nLlJvdXRlfSByb3V0ZSBUaGUgcm91dGUgdG8gdW5yZWdpc3Rlci5cbiAgICAgICAqL1xuICAgICAgdW5yZWdpc3RlclJvdXRlKHJvdXRlKSB7XG4gICAgICAgIGlmICghdGhpcy5fcm91dGVzLmhhcyhyb3V0ZS5tZXRob2QpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcigndW5yZWdpc3Rlci1yb3V0ZS1idXQtbm90LWZvdW5kLXdpdGgtbWV0aG9kJywge1xuICAgICAgICAgICAgbWV0aG9kOiByb3V0ZS5tZXRob2RcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByb3V0ZUluZGV4ID0gdGhpcy5fcm91dGVzLmdldChyb3V0ZS5tZXRob2QpLmluZGV4T2Yocm91dGUpO1xuICAgICAgICBpZiAocm91dGVJbmRleCA+IC0xKSB7XG4gICAgICAgICAgdGhpcy5fcm91dGVzLmdldChyb3V0ZS5tZXRob2QpLnNwbGljZShyb3V0ZUluZGV4LCAxKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCd1bnJlZ2lzdGVyLXJvdXRlLXJvdXRlLW5vdC1yZWdpc3RlcmVkJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBsZXQgZGVmYXVsdFJvdXRlcjtcbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgbmV3LCBzaW5nbGV0b24gUm91dGVyIGluc3RhbmNlIGlmIG9uZSBkb2VzIG5vdCBleGlzdC4gSWYgb25lXG4gICAgICogZG9lcyBhbHJlYWR5IGV4aXN0LCB0aGF0IGluc3RhbmNlIGlzIHJldHVybmVkLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAcmV0dXJuIHtSb3V0ZXJ9XG4gICAgICovXG4gICAgY29uc3QgZ2V0T3JDcmVhdGVEZWZhdWx0Um91dGVyID0gKCkgPT4ge1xuICAgICAgaWYgKCFkZWZhdWx0Um91dGVyKSB7XG4gICAgICAgIGRlZmF1bHRSb3V0ZXIgPSBuZXcgUm91dGVyKCk7XG4gICAgICAgIC8vIFRoZSBoZWxwZXJzIHRoYXQgdXNlIHRoZSBkZWZhdWx0IFJvdXRlciBhc3N1bWUgdGhlc2UgbGlzdGVuZXJzIGV4aXN0LlxuICAgICAgICBkZWZhdWx0Um91dGVyLmFkZEZldGNoTGlzdGVuZXIoKTtcbiAgICAgICAgZGVmYXVsdFJvdXRlci5hZGRDYWNoZUxpc3RlbmVyKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGVmYXVsdFJvdXRlcjtcbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogRWFzaWx5IHJlZ2lzdGVyIGEgUmVnRXhwLCBzdHJpbmcsIG9yIGZ1bmN0aW9uIHdpdGggYSBjYWNoaW5nXG4gICAgICogc3RyYXRlZ3kgdG8gYSBzaW5nbGV0b24gUm91dGVyIGluc3RhbmNlLlxuICAgICAqXG4gICAgICogVGhpcyBtZXRob2Qgd2lsbCBnZW5lcmF0ZSBhIFJvdXRlIGZvciB5b3UgaWYgbmVlZGVkIGFuZFxuICAgICAqIGNhbGwge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZXIjcmVnaXN0ZXJSb3V0ZX0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1JlZ0V4cHxzdHJpbmd8d29ya2JveC1yb3V0aW5nLlJvdXRlfm1hdGNoQ2FsbGJhY2t8d29ya2JveC1yb3V0aW5nLlJvdXRlfSBjYXB0dXJlXG4gICAgICogSWYgdGhlIGNhcHR1cmUgcGFyYW0gaXMgYSBgUm91dGVgLCBhbGwgb3RoZXIgYXJndW1lbnRzIHdpbGwgYmUgaWdub3JlZC5cbiAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IFtoYW5kbGVyXSBBIGNhbGxiYWNrXG4gICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXN1bHRpbmcgaW4gYSBSZXNwb25zZS4gVGhpcyBwYXJhbWV0ZXJcbiAgICAgKiBpcyByZXF1aXJlZCBpZiBgY2FwdHVyZWAgaXMgbm90IGEgYFJvdXRlYCBvYmplY3QuXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IFttZXRob2Q9J0dFVCddIFRoZSBIVFRQIG1ldGhvZCB0byBtYXRjaCB0aGUgUm91dGVcbiAgICAgKiBhZ2FpbnN0LlxuICAgICAqIEByZXR1cm4ge3dvcmtib3gtcm91dGluZy5Sb3V0ZX0gVGhlIGdlbmVyYXRlZCBgUm91dGVgLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcm91dGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIHJlZ2lzdGVyUm91dGUoY2FwdHVyZSwgaGFuZGxlciwgbWV0aG9kKSB7XG4gICAgICBsZXQgcm91dGU7XG4gICAgICBpZiAodHlwZW9mIGNhcHR1cmUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IGNhcHR1cmVVcmwgPSBuZXcgVVJMKGNhcHR1cmUsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKCEoY2FwdHVyZS5zdGFydHNXaXRoKCcvJykgfHwgY2FwdHVyZS5zdGFydHNXaXRoKCdodHRwJykpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdpbnZhbGlkLXN0cmluZycsIHtcbiAgICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgICAgIHBhcmFtTmFtZTogJ2NhcHR1cmUnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gV2Ugd2FudCB0byBjaGVjayBpZiBFeHByZXNzLXN0eWxlIHdpbGRjYXJkcyBhcmUgaW4gdGhlIHBhdGhuYW1lIG9ubHkuXG4gICAgICAgICAgLy8gVE9ETzogUmVtb3ZlIHRoaXMgbG9nIG1lc3NhZ2UgaW4gdjQuXG4gICAgICAgICAgY29uc3QgdmFsdWVUb0NoZWNrID0gY2FwdHVyZS5zdGFydHNXaXRoKCdodHRwJykgPyBjYXB0dXJlVXJsLnBhdGhuYW1lIDogY2FwdHVyZTtcbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3BpbGxhcmpzL3BhdGgtdG8tcmVnZXhwI3BhcmFtZXRlcnNcbiAgICAgICAgICBjb25zdCB3aWxkY2FyZHMgPSAnWyo6PytdJztcbiAgICAgICAgICBpZiAobmV3IFJlZ0V4cChgJHt3aWxkY2FyZHN9YCkuZXhlYyh2YWx1ZVRvQ2hlY2spKSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYFRoZSAnJGNhcHR1cmUnIHBhcmFtZXRlciBjb250YWlucyBhbiBFeHByZXNzLXN0eWxlIHdpbGRjYXJkIGAgKyBgY2hhcmFjdGVyICgke3dpbGRjYXJkc30pLiBTdHJpbmdzIGFyZSBub3cgYWx3YXlzIGludGVycHJldGVkIGFzIGAgKyBgZXhhY3QgbWF0Y2hlczsgdXNlIGEgUmVnRXhwIGZvciBwYXJ0aWFsIG9yIHdpbGRjYXJkIG1hdGNoZXMuYCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1hdGNoQ2FsbGJhY2sgPSAoe1xuICAgICAgICAgIHVybFxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgaWYgKHVybC5wYXRobmFtZSA9PT0gY2FwdHVyZVVybC5wYXRobmFtZSAmJiB1cmwub3JpZ2luICE9PSBjYXB0dXJlVXJsLm9yaWdpbikge1xuICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYCR7Y2FwdHVyZX0gb25seSBwYXJ0aWFsbHkgbWF0Y2hlcyB0aGUgY3Jvc3Mtb3JpZ2luIFVSTCBgICsgYCR7dXJsLnRvU3RyaW5nKCl9LiBUaGlzIHJvdXRlIHdpbGwgb25seSBoYW5kbGUgY3Jvc3Mtb3JpZ2luIHJlcXVlc3RzIGAgKyBgaWYgdGhleSBtYXRjaCB0aGUgZW50aXJlIFVSTC5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHVybC5ocmVmID09PSBjYXB0dXJlVXJsLmhyZWY7XG4gICAgICAgIH07XG4gICAgICAgIC8vIElmIGBjYXB0dXJlYCBpcyBhIHN0cmluZyB0aGVuIGBoYW5kbGVyYCBhbmQgYG1ldGhvZGAgbXVzdCBiZSBwcmVzZW50LlxuICAgICAgICByb3V0ZSA9IG5ldyBSb3V0ZShtYXRjaENhbGxiYWNrLCBoYW5kbGVyLCBtZXRob2QpO1xuICAgICAgfSBlbHNlIGlmIChjYXB0dXJlIGluc3RhbmNlb2YgUmVnRXhwKSB7XG4gICAgICAgIC8vIElmIGBjYXB0dXJlYCBpcyBhIGBSZWdFeHBgIHRoZW4gYGhhbmRsZXJgIGFuZCBgbWV0aG9kYCBtdXN0IGJlIHByZXNlbnQuXG4gICAgICAgIHJvdXRlID0gbmV3IFJlZ0V4cFJvdXRlKGNhcHR1cmUsIGhhbmRsZXIsIG1ldGhvZCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBjYXB0dXJlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIElmIGBjYXB0dXJlYCBpcyBhIGZ1bmN0aW9uIHRoZW4gYGhhbmRsZXJgIGFuZCBgbWV0aG9kYCBtdXN0IGJlIHByZXNlbnQuXG4gICAgICAgIHJvdXRlID0gbmV3IFJvdXRlKGNhcHR1cmUsIGhhbmRsZXIsIG1ldGhvZCk7XG4gICAgICB9IGVsc2UgaWYgKGNhcHR1cmUgaW5zdGFuY2VvZiBSb3V0ZSkge1xuICAgICAgICByb3V0ZSA9IGNhcHR1cmU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCd1bnN1cHBvcnRlZC1yb3V0ZS10eXBlJywge1xuICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgcGFyYW1OYW1lOiAnY2FwdHVyZSdcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBkZWZhdWx0Um91dGVyID0gZ2V0T3JDcmVhdGVEZWZhdWx0Um91dGVyKCk7XG4gICAgICBkZWZhdWx0Um91dGVyLnJlZ2lzdGVyUm91dGUocm91dGUpO1xuICAgICAgcmV0dXJuIHJvdXRlO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IF9jYWNoZU5hbWVEZXRhaWxzID0ge1xuICAgICAgZ29vZ2xlQW5hbHl0aWNzOiAnZ29vZ2xlQW5hbHl0aWNzJyxcbiAgICAgIHByZWNhY2hlOiAncHJlY2FjaGUtdjInLFxuICAgICAgcHJlZml4OiAnd29ya2JveCcsXG4gICAgICBydW50aW1lOiAncnVudGltZScsXG4gICAgICBzdWZmaXg6IHR5cGVvZiByZWdpc3RyYXRpb24gIT09ICd1bmRlZmluZWQnID8gcmVnaXN0cmF0aW9uLnNjb3BlIDogJydcbiAgICB9O1xuICAgIGNvbnN0IF9jcmVhdGVDYWNoZU5hbWUgPSBjYWNoZU5hbWUgPT4ge1xuICAgICAgcmV0dXJuIFtfY2FjaGVOYW1lRGV0YWlscy5wcmVmaXgsIGNhY2hlTmFtZSwgX2NhY2hlTmFtZURldGFpbHMuc3VmZml4XS5maWx0ZXIodmFsdWUgPT4gdmFsdWUgJiYgdmFsdWUubGVuZ3RoID4gMCkuam9pbignLScpO1xuICAgIH07XG4gICAgY29uc3QgZWFjaENhY2hlTmFtZURldGFpbCA9IGZuID0+IHtcbiAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKF9jYWNoZU5hbWVEZXRhaWxzKSkge1xuICAgICAgICBmbihrZXkpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgY2FjaGVOYW1lcyA9IHtcbiAgICAgIHVwZGF0ZURldGFpbHM6IGRldGFpbHMgPT4ge1xuICAgICAgICBlYWNoQ2FjaGVOYW1lRGV0YWlsKGtleSA9PiB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBkZXRhaWxzW2tleV0gPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICBfY2FjaGVOYW1lRGV0YWlsc1trZXldID0gZGV0YWlsc1trZXldO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgZ2V0R29vZ2xlQW5hbHl0aWNzTmFtZTogdXNlckNhY2hlTmFtZSA9PiB7XG4gICAgICAgIHJldHVybiB1c2VyQ2FjaGVOYW1lIHx8IF9jcmVhdGVDYWNoZU5hbWUoX2NhY2hlTmFtZURldGFpbHMuZ29vZ2xlQW5hbHl0aWNzKTtcbiAgICAgIH0sXG4gICAgICBnZXRQcmVjYWNoZU5hbWU6IHVzZXJDYWNoZU5hbWUgPT4ge1xuICAgICAgICByZXR1cm4gdXNlckNhY2hlTmFtZSB8fCBfY3JlYXRlQ2FjaGVOYW1lKF9jYWNoZU5hbWVEZXRhaWxzLnByZWNhY2hlKTtcbiAgICAgIH0sXG4gICAgICBnZXRQcmVmaXg6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIF9jYWNoZU5hbWVEZXRhaWxzLnByZWZpeDtcbiAgICAgIH0sXG4gICAgICBnZXRSdW50aW1lTmFtZTogdXNlckNhY2hlTmFtZSA9PiB7XG4gICAgICAgIHJldHVybiB1c2VyQ2FjaGVOYW1lIHx8IF9jcmVhdGVDYWNoZU5hbWUoX2NhY2hlTmFtZURldGFpbHMucnVudGltZSk7XG4gICAgICB9LFxuICAgICAgZ2V0U3VmZml4OiAoKSA9PiB7XG4gICAgICAgIHJldHVybiBfY2FjaGVOYW1lRGV0YWlscy5zdWZmaXg7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBIHV0aWxpdHkgbWV0aG9kIHRoYXQgbWFrZXMgaXQgZWFzaWVyIHRvIHVzZSBgZXZlbnQud2FpdFVudGlsYCB3aXRoXG4gICAgICogYXN5bmMgZnVuY3Rpb25zIGFuZCByZXR1cm4gdGhlIHJlc3VsdC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBldmVudFxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IGFzeW5jRm5cbiAgICAgKiBAcmV0dXJuIHtGdW5jdGlvbn1cbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHdhaXRVbnRpbChldmVudCwgYXN5bmNGbikge1xuICAgICAgY29uc3QgcmV0dXJuUHJvbWlzZSA9IGFzeW5jRm4oKTtcbiAgICAgIGV2ZW50LndhaXRVbnRpbChyZXR1cm5Qcm9taXNlKTtcbiAgICAgIHJldHVybiByZXR1cm5Qcm9taXNlO1xuICAgIH1cblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB0cnkge1xuICAgICAgc2VsZlsnd29ya2JveDpwcmVjYWNoaW5nOjcuNC4wJ10gJiYgXygpO1xuICAgIH0gY2F0Y2ggKGUpIHt9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvLyBOYW1lIG9mIHRoZSBzZWFyY2ggcGFyYW1ldGVyIHVzZWQgdG8gc3RvcmUgcmV2aXNpb24gaW5mby5cbiAgICBjb25zdCBSRVZJU0lPTl9TRUFSQ0hfUEFSQU0gPSAnX19XQl9SRVZJU0lPTl9fJztcbiAgICAvKipcbiAgICAgKiBDb252ZXJ0cyBhIG1hbmlmZXN0IGVudHJ5IGludG8gYSB2ZXJzaW9uZWQgVVJMIHN1aXRhYmxlIGZvciBwcmVjYWNoaW5nLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtPYmplY3R8c3RyaW5nfSBlbnRyeVxuICAgICAqIEByZXR1cm4ge3N0cmluZ30gQSBVUkwgd2l0aCB2ZXJzaW9uaW5nIGluZm8uXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjcmVhdGVDYWNoZUtleShlbnRyeSkge1xuICAgICAgaWYgKCFlbnRyeSkge1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdhZGQtdG8tY2FjaGUtbGlzdC11bmV4cGVjdGVkLXR5cGUnLCB7XG4gICAgICAgICAgZW50cnlcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvLyBJZiBhIHByZWNhY2hlIG1hbmlmZXN0IGVudHJ5IGlzIGEgc3RyaW5nLCBpdCdzIGFzc3VtZWQgdG8gYmUgYSB2ZXJzaW9uZWRcbiAgICAgIC8vIFVSTCwgbGlrZSAnL2FwcC5hYmNkMTIzNC5qcycuIFJldHVybiBhcy1pcy5cbiAgICAgIGlmICh0eXBlb2YgZW50cnkgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IHVybE9iamVjdCA9IG5ldyBVUkwoZW50cnksIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNhY2hlS2V5OiB1cmxPYmplY3QuaHJlZixcbiAgICAgICAgICB1cmw6IHVybE9iamVjdC5ocmVmXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCB7XG4gICAgICAgIHJldmlzaW9uLFxuICAgICAgICB1cmxcbiAgICAgIH0gPSBlbnRyeTtcbiAgICAgIGlmICghdXJsKSB7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2FkZC10by1jYWNoZS1saXN0LXVuZXhwZWN0ZWQtdHlwZScsIHtcbiAgICAgICAgICBlbnRyeVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8vIElmIHRoZXJlJ3MganVzdCBhIFVSTCBhbmQgbm8gcmV2aXNpb24sIHRoZW4gaXQncyBhbHNvIGFzc3VtZWQgdG8gYmUgYVxuICAgICAgLy8gdmVyc2lvbmVkIFVSTC5cbiAgICAgIGlmICghcmV2aXNpb24pIHtcbiAgICAgICAgY29uc3QgdXJsT2JqZWN0ID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNhY2hlS2V5OiB1cmxPYmplY3QuaHJlZixcbiAgICAgICAgICB1cmw6IHVybE9iamVjdC5ocmVmXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICAvLyBPdGhlcndpc2UsIGNvbnN0cnVjdCBhIHByb3Blcmx5IHZlcnNpb25lZCBVUkwgdXNpbmcgdGhlIGN1c3RvbSBXb3JrYm94XG4gICAgICAvLyBzZWFyY2ggcGFyYW1ldGVyIGFsb25nIHdpdGggdGhlIHJldmlzaW9uIGluZm8uXG4gICAgICBjb25zdCBjYWNoZUtleVVSTCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIGNvbnN0IG9yaWdpbmFsVVJMID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgY2FjaGVLZXlVUkwuc2VhcmNoUGFyYW1zLnNldChSRVZJU0lPTl9TRUFSQ0hfUEFSQU0sIHJldmlzaW9uKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNhY2hlS2V5OiBjYWNoZUtleVVSTC5ocmVmLFxuICAgICAgICB1cmw6IG9yaWdpbmFsVVJMLmhyZWZcbiAgICAgIH07XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQSBwbHVnaW4sIGRlc2lnbmVkIHRvIGJlIHVzZWQgd2l0aCBQcmVjYWNoZUNvbnRyb2xsZXIsIHRvIGRldGVybWluZSB0aGVcbiAgICAgKiBvZiBhc3NldHMgdGhhdCB3ZXJlIHVwZGF0ZWQgKG9yIG5vdCB1cGRhdGVkKSBkdXJpbmcgdGhlIGluc3RhbGwgZXZlbnQuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNsYXNzIFByZWNhY2hlSW5zdGFsbFJlcG9ydFBsdWdpbiB7XG4gICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy51cGRhdGVkVVJMcyA9IFtdO1xuICAgICAgICB0aGlzLm5vdFVwZGF0ZWRVUkxzID0gW107XG4gICAgICAgIHRoaXMuaGFuZGxlcldpbGxTdGFydCA9IGFzeW5jICh7XG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICBzdGF0ZVxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgLy8gVE9ETzogYHN0YXRlYCBzaG91bGQgbmV2ZXIgYmUgdW5kZWZpbmVkLi4uXG4gICAgICAgICAgaWYgKHN0YXRlKSB7XG4gICAgICAgICAgICBzdGF0ZS5vcmlnaW5hbFJlcXVlc3QgPSByZXF1ZXN0O1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5jYWNoZWRSZXNwb25zZVdpbGxCZVVzZWQgPSBhc3luYyAoe1xuICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgIHN0YXRlLFxuICAgICAgICAgIGNhY2hlZFJlc3BvbnNlXG4gICAgICAgIH0pID0+IHtcbiAgICAgICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ2luc3RhbGwnKSB7XG4gICAgICAgICAgICBpZiAoc3RhdGUgJiYgc3RhdGUub3JpZ2luYWxSZXF1ZXN0ICYmIHN0YXRlLm9yaWdpbmFsUmVxdWVzdCBpbnN0YW5jZW9mIFJlcXVlc3QpIHtcbiAgICAgICAgICAgICAgLy8gVE9ETzogYHN0YXRlYCBzaG91bGQgbmV2ZXIgYmUgdW5kZWZpbmVkLi4uXG4gICAgICAgICAgICAgIGNvbnN0IHVybCA9IHN0YXRlLm9yaWdpbmFsUmVxdWVzdC51cmw7XG4gICAgICAgICAgICAgIGlmIChjYWNoZWRSZXNwb25zZSkge1xuICAgICAgICAgICAgICAgIHRoaXMubm90VXBkYXRlZFVSTHMucHVzaCh1cmwpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlZFVSTHMucHVzaCh1cmwpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBjYWNoZWRSZXNwb25zZTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBIHBsdWdpbiwgZGVzaWduZWQgdG8gYmUgdXNlZCB3aXRoIFByZWNhY2hlQ29udHJvbGxlciwgdG8gdHJhbnNsYXRlIFVSTHMgaW50b1xuICAgICAqIHRoZSBjb3JyZXNwb25kaW5nIGNhY2hlIGtleSwgYmFzZWQgb24gdGhlIGN1cnJlbnQgcmV2aXNpb24gaW5mby5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY2xhc3MgUHJlY2FjaGVDYWNoZUtleVBsdWdpbiB7XG4gICAgICBjb25zdHJ1Y3Rvcih7XG4gICAgICAgIHByZWNhY2hlQ29udHJvbGxlclxuICAgICAgfSkge1xuICAgICAgICB0aGlzLmNhY2hlS2V5V2lsbEJlVXNlZCA9IGFzeW5jICh7XG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICBwYXJhbXNcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIC8vIFBhcmFtcyBpcyB0eXBlIGFueSwgY2FuJ3QgY2hhbmdlIHJpZ2h0IG5vdy5cbiAgICAgICAgICAvKiBlc2xpbnQtZGlzYWJsZSAqL1xuICAgICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gKHBhcmFtcyA9PT0gbnVsbCB8fCBwYXJhbXMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHBhcmFtcy5jYWNoZUtleSkgfHwgdGhpcy5fcHJlY2FjaGVDb250cm9sbGVyLmdldENhY2hlS2V5Rm9yVVJMKHJlcXVlc3QudXJsKTtcbiAgICAgICAgICAvKiBlc2xpbnQtZW5hYmxlICovXG4gICAgICAgICAgcmV0dXJuIGNhY2hlS2V5ID8gbmV3IFJlcXVlc3QoY2FjaGVLZXksIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3QuaGVhZGVyc1xuICAgICAgICAgIH0pIDogcmVxdWVzdDtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5fcHJlY2FjaGVDb250cm9sbGVyID0gcHJlY2FjaGVDb250cm9sbGVyO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBncm91cFRpdGxlXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSBkZWxldGVkVVJMc1xuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjb25zdCBsb2dHcm91cCA9IChncm91cFRpdGxlLCBkZWxldGVkVVJMcykgPT4ge1xuICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGdyb3VwVGl0bGUpO1xuICAgICAgZm9yIChjb25zdCB1cmwgb2YgZGVsZXRlZFVSTHMpIHtcbiAgICAgICAgbG9nZ2VyLmxvZyh1cmwpO1xuICAgICAgfVxuICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IGRlbGV0ZWRVUkxzXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBwcmludENsZWFudXBEZXRhaWxzKGRlbGV0ZWRVUkxzKSB7XG4gICAgICBjb25zdCBkZWxldGlvbkNvdW50ID0gZGVsZXRlZFVSTHMubGVuZ3RoO1xuICAgICAgaWYgKGRlbGV0aW9uQ291bnQgPiAwKSB7XG4gICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgRHVyaW5nIHByZWNhY2hpbmcgY2xlYW51cCwgYCArIGAke2RlbGV0aW9uQ291bnR9IGNhY2hlZCBgICsgYHJlcXVlc3Qke2RlbGV0aW9uQ291bnQgPT09IDEgPyAnIHdhcycgOiAncyB3ZXJlJ30gZGVsZXRlZC5gKTtcbiAgICAgICAgbG9nR3JvdXAoJ0RlbGV0ZWQgQ2FjaGUgUmVxdWVzdHMnLCBkZWxldGVkVVJMcyk7XG4gICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBncm91cFRpdGxlXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSB1cmxzXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIF9uZXN0ZWRHcm91cChncm91cFRpdGxlLCB1cmxzKSB7XG4gICAgICBpZiAodXJscy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGdyb3VwVGl0bGUpO1xuICAgICAgZm9yIChjb25zdCB1cmwgb2YgdXJscykge1xuICAgICAgICBsb2dnZXIubG9nKHVybCk7XG4gICAgICB9XG4gICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSB1cmxzVG9QcmVjYWNoZVxuICAgICAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nPn0gdXJsc0FscmVhZHlQcmVjYWNoZWRcbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIHByaW50SW5zdGFsbERldGFpbHModXJsc1RvUHJlY2FjaGUsIHVybHNBbHJlYWR5UHJlY2FjaGVkKSB7XG4gICAgICBjb25zdCBwcmVjYWNoZWRDb3VudCA9IHVybHNUb1ByZWNhY2hlLmxlbmd0aDtcbiAgICAgIGNvbnN0IGFscmVhZHlQcmVjYWNoZWRDb3VudCA9IHVybHNBbHJlYWR5UHJlY2FjaGVkLmxlbmd0aDtcbiAgICAgIGlmIChwcmVjYWNoZWRDb3VudCB8fCBhbHJlYWR5UHJlY2FjaGVkQ291bnQpIHtcbiAgICAgICAgbGV0IG1lc3NhZ2UgPSBgUHJlY2FjaGluZyAke3ByZWNhY2hlZENvdW50fSBmaWxlJHtwcmVjYWNoZWRDb3VudCA9PT0gMSA/ICcnIDogJ3MnfS5gO1xuICAgICAgICBpZiAoYWxyZWFkeVByZWNhY2hlZENvdW50ID4gMCkge1xuICAgICAgICAgIG1lc3NhZ2UgKz0gYCAke2FscmVhZHlQcmVjYWNoZWRDb3VudH0gYCArIGBmaWxlJHthbHJlYWR5UHJlY2FjaGVkQ291bnQgPT09IDEgPyAnIGlzJyA6ICdzIGFyZSd9IGFscmVhZHkgY2FjaGVkLmA7XG4gICAgICAgIH1cbiAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKG1lc3NhZ2UpO1xuICAgICAgICBfbmVzdGVkR3JvdXAoYFZpZXcgbmV3bHkgcHJlY2FjaGVkIFVSTHMuYCwgdXJsc1RvUHJlY2FjaGUpO1xuICAgICAgICBfbmVzdGVkR3JvdXAoYFZpZXcgcHJldmlvdXNseSBwcmVjYWNoZWQgVVJMcy5gLCB1cmxzQWxyZWFkeVByZWNhY2hlZCk7XG4gICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGxldCBzdXBwb3J0U3RhdHVzO1xuICAgIC8qKlxuICAgICAqIEEgdXRpbGl0eSBmdW5jdGlvbiB0aGF0IGRldGVybWluZXMgd2hldGhlciB0aGUgY3VycmVudCBicm93c2VyIHN1cHBvcnRzXG4gICAgICogY29uc3RydWN0aW5nIGEgbmV3IGBSZXNwb25zZWAgZnJvbSBhIGByZXNwb25zZS5ib2R5YCBzdHJlYW0uXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtib29sZWFufSBgdHJ1ZWAsIGlmIHRoZSBjdXJyZW50IGJyb3dzZXIgY2FuIHN1Y2Nlc3NmdWxseVxuICAgICAqICAgICBjb25zdHJ1Y3QgYSBgUmVzcG9uc2VgIGZyb20gYSBgcmVzcG9uc2UuYm9keWAgc3RyZWFtLCBgZmFsc2VgIG90aGVyd2lzZS5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZnVuY3Rpb24gY2FuQ29uc3RydWN0UmVzcG9uc2VGcm9tQm9keVN0cmVhbSgpIHtcbiAgICAgIGlmIChzdXBwb3J0U3RhdHVzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY29uc3QgdGVzdFJlc3BvbnNlID0gbmV3IFJlc3BvbnNlKCcnKTtcbiAgICAgICAgaWYgKCdib2R5JyBpbiB0ZXN0UmVzcG9uc2UpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgbmV3IFJlc3BvbnNlKHRlc3RSZXNwb25zZS5ib2R5KTtcbiAgICAgICAgICAgIHN1cHBvcnRTdGF0dXMgPSB0cnVlO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBzdXBwb3J0U3RhdHVzID0gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHN1cHBvcnRTdGF0dXMgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdXBwb3J0U3RhdHVzO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEFsbG93cyBkZXZlbG9wZXJzIHRvIGNvcHkgYSByZXNwb25zZSBhbmQgbW9kaWZ5IGl0cyBgaGVhZGVyc2AsIGBzdGF0dXNgLFxuICAgICAqIG9yIGBzdGF0dXNUZXh0YCB2YWx1ZXMgKHRoZSB2YWx1ZXMgc2V0dGFibGUgdmlhIGFcbiAgICAgKiBbYFJlc3BvbnNlSW5pdGBde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9SZXNwb25zZS9SZXNwb25zZSNTeW50YXh9XG4gICAgICogb2JqZWN0IGluIHRoZSBjb25zdHJ1Y3RvcikuXG4gICAgICogVG8gbW9kaWZ5IHRoZXNlIHZhbHVlcywgcGFzcyBhIGZ1bmN0aW9uIGFzIHRoZSBzZWNvbmQgYXJndW1lbnQuIFRoYXRcbiAgICAgKiBmdW5jdGlvbiB3aWxsIGJlIGludm9rZWQgd2l0aCBhIHNpbmdsZSBvYmplY3Qgd2l0aCB0aGUgcmVzcG9uc2UgcHJvcGVydGllc1xuICAgICAqIGB7aGVhZGVycywgc3RhdHVzLCBzdGF0dXNUZXh0fWAuIFRoZSByZXR1cm4gdmFsdWUgb2YgdGhpcyBmdW5jdGlvbiB3aWxsXG4gICAgICogYmUgdXNlZCBhcyB0aGUgYFJlc3BvbnNlSW5pdGAgZm9yIHRoZSBuZXcgYFJlc3BvbnNlYC4gVG8gY2hhbmdlIHRoZSB2YWx1ZXNcbiAgICAgKiBlaXRoZXIgbW9kaWZ5IHRoZSBwYXNzZWQgcGFyYW1ldGVyKHMpIGFuZCByZXR1cm4gaXQsIG9yIHJldHVybiBhIHRvdGFsbHlcbiAgICAgKiBuZXcgb2JqZWN0LlxuICAgICAqXG4gICAgICogVGhpcyBtZXRob2QgaXMgaW50ZW50aW9uYWxseSBsaW1pdGVkIHRvIHNhbWUtb3JpZ2luIHJlc3BvbnNlcywgcmVnYXJkbGVzcyBvZlxuICAgICAqIHdoZXRoZXIgQ09SUyB3YXMgdXNlZCBvciBub3QuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1Jlc3BvbnNlfSByZXNwb25zZVxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IG1vZGlmaWVyXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtY29yZVxuICAgICAqL1xuICAgIGFzeW5jIGZ1bmN0aW9uIGNvcHlSZXNwb25zZShyZXNwb25zZSwgbW9kaWZpZXIpIHtcbiAgICAgIGxldCBvcmlnaW4gPSBudWxsO1xuICAgICAgLy8gSWYgcmVzcG9uc2UudXJsIGlzbid0IHNldCwgYXNzdW1lIGl0J3MgY3Jvc3Mtb3JpZ2luIGFuZCBrZWVwIG9yaWdpbiBudWxsLlxuICAgICAgaWYgKHJlc3BvbnNlLnVybCkge1xuICAgICAgICBjb25zdCByZXNwb25zZVVSTCA9IG5ldyBVUkwocmVzcG9uc2UudXJsKTtcbiAgICAgICAgb3JpZ2luID0gcmVzcG9uc2VVUkwub3JpZ2luO1xuICAgICAgfVxuICAgICAgaWYgKG9yaWdpbiAhPT0gc2VsZi5sb2NhdGlvbi5vcmlnaW4pIHtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignY3Jvc3Mtb3JpZ2luLWNvcHktcmVzcG9uc2UnLCB7XG4gICAgICAgICAgb3JpZ2luXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgY2xvbmVkUmVzcG9uc2UgPSByZXNwb25zZS5jbG9uZSgpO1xuICAgICAgLy8gQ3JlYXRlIGEgZnJlc2ggYFJlc3BvbnNlSW5pdGAgb2JqZWN0IGJ5IGNsb25pbmcgdGhlIGhlYWRlcnMuXG4gICAgICBjb25zdCByZXNwb25zZUluaXQgPSB7XG4gICAgICAgIGhlYWRlcnM6IG5ldyBIZWFkZXJzKGNsb25lZFJlc3BvbnNlLmhlYWRlcnMpLFxuICAgICAgICBzdGF0dXM6IGNsb25lZFJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgc3RhdHVzVGV4dDogY2xvbmVkUmVzcG9uc2Uuc3RhdHVzVGV4dFxuICAgICAgfTtcbiAgICAgIC8vIEFwcGx5IGFueSB1c2VyIG1vZGlmaWNhdGlvbnMuXG4gICAgICBjb25zdCBtb2RpZmllZFJlc3BvbnNlSW5pdCA9IHJlc3BvbnNlSW5pdDtcbiAgICAgIC8vIENyZWF0ZSB0aGUgbmV3IHJlc3BvbnNlIGZyb20gdGhlIGJvZHkgc3RyZWFtIGFuZCBgUmVzcG9uc2VJbml0YFxuICAgICAgLy8gbW9kaWZpY2F0aW9ucy4gTm90ZTogbm90IGFsbCBicm93c2VycyBzdXBwb3J0IHRoZSBSZXNwb25zZS5ib2R5IHN0cmVhbSxcbiAgICAgIC8vIHNvIGZhbGwgYmFjayB0byByZWFkaW5nIHRoZSBlbnRpcmUgYm9keSBpbnRvIG1lbW9yeSBhcyBhIGJsb2IuXG4gICAgICBjb25zdCBib2R5ID0gY2FuQ29uc3RydWN0UmVzcG9uc2VGcm9tQm9keVN0cmVhbSgpID8gY2xvbmVkUmVzcG9uc2UuYm9keSA6IGF3YWl0IGNsb25lZFJlc3BvbnNlLmJsb2IoKTtcbiAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoYm9keSwgbW9kaWZpZWRSZXNwb25zZUluaXQpO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBmdW5jdGlvbiBzdHJpcFBhcmFtcyhmdWxsVVJMLCBpZ25vcmVQYXJhbXMpIHtcbiAgICAgIGNvbnN0IHN0cmlwcGVkVVJMID0gbmV3IFVSTChmdWxsVVJMKTtcbiAgICAgIGZvciAoY29uc3QgcGFyYW0gb2YgaWdub3JlUGFyYW1zKSB7XG4gICAgICAgIHN0cmlwcGVkVVJMLnNlYXJjaFBhcmFtcy5kZWxldGUocGFyYW0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0cmlwcGVkVVJMLmhyZWY7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE1hdGNoZXMgYW4gaXRlbSBpbiB0aGUgY2FjaGUsIGlnbm9yaW5nIHNwZWNpZmljIFVSTCBwYXJhbXMuIFRoaXMgaXMgc2ltaWxhclxuICAgICAqIHRvIHRoZSBgaWdub3JlU2VhcmNoYCBvcHRpb24sIGJ1dCBpdCBhbGxvd3MgeW91IHRvIGlnbm9yZSBqdXN0IHNwZWNpZmljXG4gICAgICogcGFyYW1zICh3aGlsZSBjb250aW51aW5nIHRvIG1hdGNoIG9uIHRoZSBvdGhlcnMpLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAcGFyYW0ge0NhY2hlfSBjYWNoZVxuICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gcmVxdWVzdFxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSBtYXRjaE9wdGlvbnNcbiAgICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IGlnbm9yZVBhcmFtc1xuICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2V8dW5kZWZpbmVkPn1cbiAgICAgKi9cbiAgICBhc3luYyBmdW5jdGlvbiBjYWNoZU1hdGNoSWdub3JlUGFyYW1zKGNhY2hlLCByZXF1ZXN0LCBpZ25vcmVQYXJhbXMsIG1hdGNoT3B0aW9ucykge1xuICAgICAgY29uc3Qgc3RyaXBwZWRSZXF1ZXN0VVJMID0gc3RyaXBQYXJhbXMocmVxdWVzdC51cmwsIGlnbm9yZVBhcmFtcyk7XG4gICAgICAvLyBJZiB0aGUgcmVxdWVzdCBkb2Vzbid0IGluY2x1ZGUgYW55IGlnbm9yZWQgcGFyYW1zLCBtYXRjaCBhcyBub3JtYWwuXG4gICAgICBpZiAocmVxdWVzdC51cmwgPT09IHN0cmlwcGVkUmVxdWVzdFVSTCkge1xuICAgICAgICByZXR1cm4gY2FjaGUubWF0Y2gocmVxdWVzdCwgbWF0Y2hPcHRpb25zKTtcbiAgICAgIH1cbiAgICAgIC8vIE90aGVyd2lzZSwgbWF0Y2ggYnkgY29tcGFyaW5nIGtleXNcbiAgICAgIGNvbnN0IGtleXNPcHRpb25zID0gT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCBtYXRjaE9wdGlvbnMpLCB7XG4gICAgICAgIGlnbm9yZVNlYXJjaDogdHJ1ZVxuICAgICAgfSk7XG4gICAgICBjb25zdCBjYWNoZUtleXMgPSBhd2FpdCBjYWNoZS5rZXlzKHJlcXVlc3QsIGtleXNPcHRpb25zKTtcbiAgICAgIGZvciAoY29uc3QgY2FjaGVLZXkgb2YgY2FjaGVLZXlzKSB7XG4gICAgICAgIGNvbnN0IHN0cmlwcGVkQ2FjaGVLZXlVUkwgPSBzdHJpcFBhcmFtcyhjYWNoZUtleS51cmwsIGlnbm9yZVBhcmFtcyk7XG4gICAgICAgIGlmIChzdHJpcHBlZFJlcXVlc3RVUkwgPT09IHN0cmlwcGVkQ2FjaGVLZXlVUkwpIHtcbiAgICAgICAgICByZXR1cm4gY2FjaGUubWF0Y2goY2FjaGVLZXksIG1hdGNoT3B0aW9ucyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBUaGUgRGVmZXJyZWQgY2xhc3MgY29tcG9zZXMgUHJvbWlzZXMgaW4gYSB3YXkgdGhhdCBhbGxvd3MgZm9yIHRoZW0gdG8gYmVcbiAgICAgKiByZXNvbHZlZCBvciByZWplY3RlZCBmcm9tIG91dHNpZGUgdGhlIGNvbnN0cnVjdG9yLiBJbiBtb3N0IGNhc2VzIHByb21pc2VzXG4gICAgICogc2hvdWxkIGJlIHVzZWQgZGlyZWN0bHksIGJ1dCBEZWZlcnJlZHMgY2FuIGJlIG5lY2Vzc2FyeSB3aGVuIHRoZSBsb2dpYyB0b1xuICAgICAqIHJlc29sdmUgYSBwcm9taXNlIG11c3QgYmUgc2VwYXJhdGUuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNsYXNzIERlZmVycmVkIHtcbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlcyBhIHByb21pc2UgYW5kIGV4cG9zZXMgaXRzIHJlc29sdmUgYW5kIHJlamVjdCBmdW5jdGlvbnMgYXMgbWV0aG9kcy5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICB0aGlzLnJlc29sdmUgPSByZXNvbHZlO1xuICAgICAgICAgIHRoaXMucmVqZWN0ID0gcmVqZWN0O1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvLyBDYWxsYmFja3MgdG8gYmUgZXhlY3V0ZWQgd2hlbmV2ZXIgdGhlcmUncyBhIHF1b3RhIGVycm9yLlxuICAgIC8vIENhbid0IGNoYW5nZSBGdW5jdGlvbiB0eXBlIHJpZ2h0IG5vdy5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10eXBlc1xuICAgIGNvbnN0IHF1b3RhRXJyb3JDYWxsYmFja3MgPSBuZXcgU2V0KCk7XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBSdW5zIGFsbCBvZiB0aGUgY2FsbGJhY2sgZnVuY3Rpb25zLCBvbmUgYXQgYSB0aW1lIHNlcXVlbnRpYWxseSwgaW4gdGhlIG9yZGVyXG4gICAgICogaW4gd2hpY2ggdGhleSB3ZXJlIHJlZ2lzdGVyZWQuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1jb3JlXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBhc3luYyBmdW5jdGlvbiBleGVjdXRlUXVvdGFFcnJvckNhbGxiYWNrcygpIHtcbiAgICAgIHtcbiAgICAgICAgbG9nZ2VyLmxvZyhgQWJvdXQgdG8gcnVuICR7cXVvdGFFcnJvckNhbGxiYWNrcy5zaXplfSBgICsgYGNhbGxiYWNrcyB0byBjbGVhbiB1cCBjYWNoZXMuYCk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIHF1b3RhRXJyb3JDYWxsYmFja3MpIHtcbiAgICAgICAgYXdhaXQgY2FsbGJhY2soKTtcbiAgICAgICAge1xuICAgICAgICAgIGxvZ2dlci5sb2coY2FsbGJhY2ssICdpcyBjb21wbGV0ZS4nKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAge1xuICAgICAgICBsb2dnZXIubG9nKCdGaW5pc2hlZCBydW5uaW5nIGNhbGxiYWNrcy4nKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyBhbmQgdGhlIHBhc3NlZCBudW1iZXIgb2YgbWlsbGlzZWNvbmRzLlxuICAgICAqIFRoaXMgdXRpbGl0eSBpcyBhbiBhc3luYy9hd2FpdC1mcmllbmRseSB2ZXJzaW9uIG9mIGBzZXRUaW1lb3V0YC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBtc1xuICAgICAqIEByZXR1cm4ge1Byb21pc2V9XG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiB0aW1lb3V0KG1zKSB7XG4gICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIG1zKSk7XG4gICAgfVxuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRyeSB7XG4gICAgICBzZWxmWyd3b3JrYm94OnN0cmF0ZWdpZXM6Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGZ1bmN0aW9uIHRvUmVxdWVzdChpbnB1dCkge1xuICAgICAgcmV0dXJuIHR5cGVvZiBpbnB1dCA9PT0gJ3N0cmluZycgPyBuZXcgUmVxdWVzdChpbnB1dCkgOiBpbnB1dDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQSBjbGFzcyBjcmVhdGVkIGV2ZXJ5IHRpbWUgYSBTdHJhdGVneSBpbnN0YW5jZSBjYWxsc1xuICAgICAqIHtAbGluayB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3l+aGFuZGxlfSBvclxuICAgICAqIHtAbGluayB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3l+aGFuZGxlQWxsfSB0aGF0IHdyYXBzIGFsbCBmZXRjaCBhbmRcbiAgICAgKiBjYWNoZSBhY3Rpb25zIGFyb3VuZCBwbHVnaW4gY2FsbGJhY2tzIGFuZCBrZWVwcyB0cmFjayBvZiB3aGVuIHRoZSBzdHJhdGVneVxuICAgICAqIGlzIFwiZG9uZVwiIChpLmUuIGFsbCBhZGRlZCBgZXZlbnQud2FpdFVudGlsKClgIHByb21pc2VzIGhhdmUgcmVzb2x2ZWQpLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtc3RyYXRlZ2llc1xuICAgICAqL1xuICAgIGNsYXNzIFN0cmF0ZWd5SGFuZGxlciB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2UgYXNzb2NpYXRlZCB3aXRoIHRoZSBwYXNzZWQgc3RyYXRlZ3kgYW5kIGV2ZW50XG4gICAgICAgKiB0aGF0J3MgaGFuZGxpbmcgdGhlIHJlcXVlc3QuXG4gICAgICAgKlxuICAgICAgICogVGhlIGNvbnN0cnVjdG9yIGFsc28gaW5pdGlhbGl6ZXMgdGhlIHN0YXRlIHRoYXQgd2lsbCBiZSBwYXNzZWQgdG8gZWFjaCBvZlxuICAgICAgICogdGhlIHBsdWdpbnMgaGFuZGxpbmcgdGhpcyByZXF1ZXN0LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fSBzdHJhdGVneVxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IG9wdGlvbnMucmVxdWVzdCBBIHJlcXVlc3QgdG8gcnVuIHRoaXMgc3RyYXRlZ3kgZm9yLlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IG9wdGlvbnMuZXZlbnQgVGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGVcbiAgICAgICAqICAgICByZXF1ZXN0LlxuICAgICAgICogQHBhcmFtIHtVUkx9IFtvcHRpb25zLnVybF1cbiAgICAgICAqIEBwYXJhbSB7Kn0gW29wdGlvbnMucGFyYW1zXSBUaGUgcmV0dXJuIHZhbHVlIGZyb20gdGhlXG4gICAgICAgKiAgICAge0BsaW5rIHdvcmtib3gtcm91dGluZ35tYXRjaENhbGxiYWNrfSAoaWYgYXBwbGljYWJsZSkuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKHN0cmF0ZWd5LCBvcHRpb25zKSB7XG4gICAgICAgIHRoaXMuX2NhY2hlS2V5cyA9IHt9O1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHJlcXVlc3QgdGhlIHN0cmF0ZWd5IGlzIHBlcmZvcm1pbmcgKHBhc3NlZCB0byB0aGUgc3RyYXRlZ3knc1xuICAgICAgICAgKiBgaGFuZGxlKClgIG9yIGBoYW5kbGVBbGwoKWAgbWV0aG9kKS5cbiAgICAgICAgICogQG5hbWUgcmVxdWVzdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHR5cGUge1JlcXVlc3R9XG4gICAgICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lIYW5kbGVyXG4gICAgICAgICAqL1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGlzIHJlcXVlc3QuXG4gICAgICAgICAqIEBuYW1lIGV2ZW50XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAdHlwZSB7RXh0ZW5kYWJsZUV2ZW50fVxuICAgICAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlclxuICAgICAgICAgKi9cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEEgYFVSTGAgaW5zdGFuY2Ugb2YgYHJlcXVlc3QudXJsYCAoaWYgcGFzc2VkIHRvIHRoZSBzdHJhdGVneSdzXG4gICAgICAgICAqIGBoYW5kbGUoKWAgb3IgYGhhbmRsZUFsbCgpYCBtZXRob2QpLlxuICAgICAgICAgKiBOb3RlOiB0aGUgYHVybGAgcGFyYW0gd2lsbCBiZSBwcmVzZW50IGlmIHRoZSBzdHJhdGVneSB3YXMgaW52b2tlZFxuICAgICAgICAgKiBmcm9tIGEgd29ya2JveCBgUm91dGVgIG9iamVjdC5cbiAgICAgICAgICogQG5hbWUgdXJsXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAdHlwZSB7VVJMfHVuZGVmaW5lZH1cbiAgICAgICAgICogQG1lbWJlcm9mIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJcbiAgICAgICAgICovXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBBIGBwYXJhbWAgdmFsdWUgKGlmIHBhc3NlZCB0byB0aGUgc3RyYXRlZ3knc1xuICAgICAgICAgKiBgaGFuZGxlKClgIG9yIGBoYW5kbGVBbGwoKWAgbWV0aG9kKS5cbiAgICAgICAgICogTm90ZTogdGhlIGBwYXJhbWAgcGFyYW0gd2lsbCBiZSBwcmVzZW50IGlmIHRoZSBzdHJhdGVneSB3YXMgaW52b2tlZFxuICAgICAgICAgKiBmcm9tIGEgd29ya2JveCBgUm91dGVgIG9iamVjdCBhbmQgdGhlXG4gICAgICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmd+bWF0Y2hDYWxsYmFja30gcmV0dXJuZWRcbiAgICAgICAgICogYSB0cnV0aHkgdmFsdWUgKGl0IHdpbGwgYmUgdGhhdCB2YWx1ZSkuXG4gICAgICAgICAqIEBuYW1lIHBhcmFtc1xuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHR5cGUgeyp8dW5kZWZpbmVkfVxuICAgICAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlclxuICAgICAgICAgKi9cbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0luc3RhbmNlKG9wdGlvbnMuZXZlbnQsIEV4dGVuZGFibGVFdmVudCwge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtc3RyYXRlZ2llcycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdTdHJhdGVneUhhbmRsZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdvcHRpb25zLmV2ZW50J1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcywgb3B0aW9ucyk7XG4gICAgICAgIHRoaXMuZXZlbnQgPSBvcHRpb25zLmV2ZW50O1xuICAgICAgICB0aGlzLl9zdHJhdGVneSA9IHN0cmF0ZWd5O1xuICAgICAgICB0aGlzLl9oYW5kbGVyRGVmZXJyZWQgPSBuZXcgRGVmZXJyZWQoKTtcbiAgICAgICAgdGhpcy5fZXh0ZW5kTGlmZXRpbWVQcm9taXNlcyA9IFtdO1xuICAgICAgICAvLyBDb3B5IHRoZSBwbHVnaW5zIGxpc3QgKHNpbmNlIGl0J3MgbXV0YWJsZSBvbiB0aGUgc3RyYXRlZ3kpLFxuICAgICAgICAvLyBzbyBhbnkgbXV0YXRpb25zIGRvbid0IGFmZmVjdCB0aGlzIGhhbmRsZXIgaW5zdGFuY2UuXG4gICAgICAgIHRoaXMuX3BsdWdpbnMgPSBbLi4uc3RyYXRlZ3kucGx1Z2luc107XG4gICAgICAgIHRoaXMuX3BsdWdpblN0YXRlTWFwID0gbmV3IE1hcCgpO1xuICAgICAgICBmb3IgKGNvbnN0IHBsdWdpbiBvZiB0aGlzLl9wbHVnaW5zKSB7XG4gICAgICAgICAgdGhpcy5fcGx1Z2luU3RhdGVNYXAuc2V0KHBsdWdpbiwge30pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZXZlbnQud2FpdFVudGlsKHRoaXMuX2hhbmRsZXJEZWZlcnJlZC5wcm9taXNlKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogRmV0Y2hlcyBhIGdpdmVuIHJlcXVlc3QgKGFuZCBpbnZva2VzIGFueSBhcHBsaWNhYmxlIHBsdWdpbiBjYWxsYmFja1xuICAgICAgICogbWV0aG9kcykgdXNpbmcgdGhlIGBmZXRjaE9wdGlvbnNgIChmb3Igbm9uLW5hdmlnYXRpb24gcmVxdWVzdHMpIGFuZFxuICAgICAgICogYHBsdWdpbnNgIGRlZmluZWQgb24gdGhlIGBTdHJhdGVneWAgb2JqZWN0LlxuICAgICAgICpcbiAgICAgICAqIFRoZSBmb2xsb3dpbmcgcGx1Z2luIGxpZmVjeWNsZSBtZXRob2RzIGFyZSBpbnZva2VkIHdoZW4gdXNpbmcgdGhpcyBtZXRob2Q6XG4gICAgICAgKiAtIGByZXF1ZXN0V2lsbEZldGNoKClgXG4gICAgICAgKiAtIGBmZXRjaERpZFN1Y2NlZWQoKWBcbiAgICAgICAqIC0gYGZldGNoRGlkRmFpbCgpYFxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IGlucHV0IFRoZSBVUkwgb3IgcmVxdWVzdCB0byBmZXRjaC5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2U+fVxuICAgICAgICovXG4gICAgICBhc3luYyBmZXRjaChpbnB1dCkge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgZXZlbnRcbiAgICAgICAgfSA9IHRoaXM7XG4gICAgICAgIGxldCByZXF1ZXN0ID0gdG9SZXF1ZXN0KGlucHV0KTtcbiAgICAgICAgaWYgKHJlcXVlc3QubW9kZSA9PT0gJ25hdmlnYXRlJyAmJiBldmVudCBpbnN0YW5jZW9mIEZldGNoRXZlbnQgJiYgZXZlbnQucHJlbG9hZFJlc3BvbnNlKSB7XG4gICAgICAgICAgY29uc3QgcG9zc2libGVQcmVsb2FkUmVzcG9uc2UgPSBhd2FpdCBldmVudC5wcmVsb2FkUmVzcG9uc2U7XG4gICAgICAgICAgaWYgKHBvc3NpYmxlUHJlbG9hZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxvZ2dlci5sb2coYFVzaW5nIGEgcHJlbG9hZGVkIG5hdmlnYXRpb24gcmVzcG9uc2UgZm9yIGAgKyBgJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfSdgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBwb3NzaWJsZVByZWxvYWRSZXNwb25zZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlcmUgaXMgYSBmZXRjaERpZEZhaWwgcGx1Z2luLCB3ZSBuZWVkIHRvIHNhdmUgYSBjbG9uZSBvZiB0aGVcbiAgICAgICAgLy8gb3JpZ2luYWwgcmVxdWVzdCBiZWZvcmUgaXQncyBlaXRoZXIgbW9kaWZpZWQgYnkgYSByZXF1ZXN0V2lsbEZldGNoXG4gICAgICAgIC8vIHBsdWdpbiBvciBiZWZvcmUgdGhlIG9yaWdpbmFsIHJlcXVlc3QncyBib2R5IGlzIGNvbnN1bWVkIHZpYSBmZXRjaCgpLlxuICAgICAgICBjb25zdCBvcmlnaW5hbFJlcXVlc3QgPSB0aGlzLmhhc0NhbGxiYWNrKCdmZXRjaERpZEZhaWwnKSA/IHJlcXVlc3QuY2xvbmUoKSA6IG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZm9yIChjb25zdCBjYiBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ3JlcXVlc3RXaWxsRmV0Y2gnKSkge1xuICAgICAgICAgICAgcmVxdWVzdCA9IGF3YWl0IGNiKHtcbiAgICAgICAgICAgICAgcmVxdWVzdDogcmVxdWVzdC5jbG9uZSgpLFxuICAgICAgICAgICAgICBldmVudFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ3BsdWdpbi1lcnJvci1yZXF1ZXN0LXdpbGwtZmV0Y2gnLCB7XG4gICAgICAgICAgICAgIHRocm93bkVycm9yTWVzc2FnZTogZXJyLm1lc3NhZ2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBUaGUgcmVxdWVzdCBjYW4gYmUgYWx0ZXJlZCBieSBwbHVnaW5zIHdpdGggYHJlcXVlc3RXaWxsRmV0Y2hgIG1ha2luZ1xuICAgICAgICAvLyB0aGUgb3JpZ2luYWwgcmVxdWVzdCAobW9zdCBsaWtlbHkgZnJvbSBhIGBmZXRjaGAgZXZlbnQpIGRpZmZlcmVudFxuICAgICAgICAvLyBmcm9tIHRoZSBSZXF1ZXN0IHdlIG1ha2UuIFBhc3MgYm90aCB0byBgZmV0Y2hEaWRGYWlsYCB0byBhaWQgZGVidWdnaW5nLlxuICAgICAgICBjb25zdCBwbHVnaW5GaWx0ZXJlZFJlcXVlc3QgPSByZXF1ZXN0LmNsb25lKCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IGZldGNoUmVzcG9uc2U7XG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMTc5NlxuICAgICAgICAgIGZldGNoUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChyZXF1ZXN0LCByZXF1ZXN0Lm1vZGUgPT09ICduYXZpZ2F0ZScgPyB1bmRlZmluZWQgOiB0aGlzLl9zdHJhdGVneS5mZXRjaE9wdGlvbnMpO1xuICAgICAgICAgIGlmIChcImRldmVsb3BtZW50XCIgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBOZXR3b3JrIHJlcXVlc3QgZm9yIGAgKyBgJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfScgcmV0dXJuZWQgYSByZXNwb25zZSB3aXRoIGAgKyBgc3RhdHVzICcke2ZldGNoUmVzcG9uc2Uuc3RhdHVzfScuYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdmZXRjaERpZFN1Y2NlZWQnKSkge1xuICAgICAgICAgICAgZmV0Y2hSZXNwb25zZSA9IGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIHJlcXVlc3Q6IHBsdWdpbkZpbHRlcmVkUmVxdWVzdCxcbiAgICAgICAgICAgICAgcmVzcG9uc2U6IGZldGNoUmVzcG9uc2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmV0Y2hSZXNwb25zZTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBsb2dnZXIubG9nKGBOZXR3b3JrIHJlcXVlc3QgZm9yIGAgKyBgJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfScgdGhyZXcgYW4gZXJyb3IuYCwgZXJyb3IpO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBgb3JpZ2luYWxSZXF1ZXN0YCB3aWxsIG9ubHkgZXhpc3QgaWYgYSBgZmV0Y2hEaWRGYWlsYCBjYWxsYmFja1xuICAgICAgICAgIC8vIGlzIGJlaW5nIHVzZWQgKHNlZSBhYm92ZSkuXG4gICAgICAgICAgaWYgKG9yaWdpbmFsUmVxdWVzdCkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5ydW5DYWxsYmFja3MoJ2ZldGNoRGlkRmFpbCcsIHtcbiAgICAgICAgICAgICAgZXJyb3I6IGVycm9yLFxuICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgb3JpZ2luYWxSZXF1ZXN0OiBvcmlnaW5hbFJlcXVlc3QuY2xvbmUoKSxcbiAgICAgICAgICAgICAgcmVxdWVzdDogcGx1Z2luRmlsdGVyZWRSZXF1ZXN0LmNsb25lKClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBDYWxscyBgdGhpcy5mZXRjaCgpYCBhbmQgKGluIHRoZSBiYWNrZ3JvdW5kKSBydW5zIGB0aGlzLmNhY2hlUHV0KClgIG9uXG4gICAgICAgKiB0aGUgcmVzcG9uc2UgZ2VuZXJhdGVkIGJ5IGB0aGlzLmZldGNoKClgLlxuICAgICAgICpcbiAgICAgICAqIFRoZSBjYWxsIHRvIGB0aGlzLmNhY2hlUHV0KClgIGF1dG9tYXRpY2FsbHkgaW52b2tlcyBgdGhpcy53YWl0VW50aWwoKWAsXG4gICAgICAgKiBzbyB5b3UgZG8gbm90IGhhdmUgdG8gbWFudWFsbHkgY2FsbCBgd2FpdFVudGlsKClgIG9uIHRoZSBldmVudC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBpbnB1dCBUaGUgcmVxdWVzdCBvciBVUkwgdG8gZmV0Y2ggYW5kIGNhY2hlLlxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZT59XG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGZldGNoQW5kQ2FjaGVQdXQoaW5wdXQpIHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmZldGNoKGlucHV0KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VDbG9uZSA9IHJlc3BvbnNlLmNsb25lKCk7XG4gICAgICAgIHZvaWQgdGhpcy53YWl0VW50aWwodGhpcy5jYWNoZVB1dChpbnB1dCwgcmVzcG9uc2VDbG9uZSkpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIE1hdGNoZXMgYSByZXF1ZXN0IGZyb20gdGhlIGNhY2hlIChhbmQgaW52b2tlcyBhbnkgYXBwbGljYWJsZSBwbHVnaW5cbiAgICAgICAqIGNhbGxiYWNrIG1ldGhvZHMpIHVzaW5nIHRoZSBgY2FjaGVOYW1lYCwgYG1hdGNoT3B0aW9uc2AsIGFuZCBgcGx1Z2luc2BcbiAgICAgICAqIGRlZmluZWQgb24gdGhlIHN0cmF0ZWd5IG9iamVjdC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgZm9sbG93aW5nIHBsdWdpbiBsaWZlY3ljbGUgbWV0aG9kcyBhcmUgaW52b2tlZCB3aGVuIHVzaW5nIHRoaXMgbWV0aG9kOlxuICAgICAgICogLSBjYWNoZUtleVdpbGxCZVVzZWQoKVxuICAgICAgICogLSBjYWNoZWRSZXNwb25zZVdpbGxCZVVzZWQoKVxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IGtleSBUaGUgUmVxdWVzdCBvciBVUkwgdG8gdXNlIGFzIHRoZSBjYWNoZSBrZXkuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlfHVuZGVmaW5lZD59IEEgbWF0Y2hpbmcgcmVzcG9uc2UsIGlmIGZvdW5kLlxuICAgICAgICovXG4gICAgICBhc3luYyBjYWNoZU1hdGNoKGtleSkge1xuICAgICAgICBjb25zdCByZXF1ZXN0ID0gdG9SZXF1ZXN0KGtleSk7XG4gICAgICAgIGxldCBjYWNoZWRSZXNwb25zZTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgICBtYXRjaE9wdGlvbnNcbiAgICAgICAgfSA9IHRoaXMuX3N0cmF0ZWd5O1xuICAgICAgICBjb25zdCBlZmZlY3RpdmVSZXF1ZXN0ID0gYXdhaXQgdGhpcy5nZXRDYWNoZUtleShyZXF1ZXN0LCAncmVhZCcpO1xuICAgICAgICBjb25zdCBtdWx0aU1hdGNoT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgbWF0Y2hPcHRpb25zKSwge1xuICAgICAgICAgIGNhY2hlTmFtZVxuICAgICAgICB9KTtcbiAgICAgICAgY2FjaGVkUmVzcG9uc2UgPSBhd2FpdCBjYWNoZXMubWF0Y2goZWZmZWN0aXZlUmVxdWVzdCwgbXVsdGlNYXRjaE9wdGlvbnMpO1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKGNhY2hlZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYEZvdW5kIGEgY2FjaGVkIHJlc3BvbnNlIGluICcke2NhY2hlTmFtZX0nLmApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYE5vIGNhY2hlZCByZXNwb25zZSBmb3VuZCBpbiAnJHtjYWNoZU5hbWV9Jy5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ2NhY2hlZFJlc3BvbnNlV2lsbEJlVXNlZCcpKSB7XG4gICAgICAgICAgY2FjaGVkUmVzcG9uc2UgPSAoYXdhaXQgY2FsbGJhY2soe1xuICAgICAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICAgICAgbWF0Y2hPcHRpb25zLFxuICAgICAgICAgICAgY2FjaGVkUmVzcG9uc2UsXG4gICAgICAgICAgICByZXF1ZXN0OiBlZmZlY3RpdmVSZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnRcbiAgICAgICAgICB9KSkgfHwgdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjYWNoZWRSZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUHV0cyBhIHJlcXVlc3QvcmVzcG9uc2UgcGFpciBpbiB0aGUgY2FjaGUgKGFuZCBpbnZva2VzIGFueSBhcHBsaWNhYmxlXG4gICAgICAgKiBwbHVnaW4gY2FsbGJhY2sgbWV0aG9kcykgdXNpbmcgdGhlIGBjYWNoZU5hbWVgIGFuZCBgcGx1Z2luc2AgZGVmaW5lZCBvblxuICAgICAgICogdGhlIHN0cmF0ZWd5IG9iamVjdC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgZm9sbG93aW5nIHBsdWdpbiBsaWZlY3ljbGUgbWV0aG9kcyBhcmUgaW52b2tlZCB3aGVuIHVzaW5nIHRoaXMgbWV0aG9kOlxuICAgICAgICogLSBjYWNoZUtleVdpbGxCZVVzZWQoKVxuICAgICAgICogLSBjYWNoZVdpbGxVcGRhdGUoKVxuICAgICAgICogLSBjYWNoZURpZFVwZGF0ZSgpXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fHN0cmluZ30ga2V5IFRoZSByZXF1ZXN0IG9yIFVSTCB0byB1c2UgYXMgdGhlIGNhY2hlIGtleS5cbiAgICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IHJlc3BvbnNlIFRoZSByZXNwb25zZSB0byBjYWNoZS5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8Ym9vbGVhbj59IGBmYWxzZWAgaWYgYSBjYWNoZVdpbGxVcGRhdGUgY2F1c2VkIHRoZSByZXNwb25zZVxuICAgICAgICogbm90IGJlIGNhY2hlZCwgYW5kIGB0cnVlYCBvdGhlcndpc2UuXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGNhY2hlUHV0KGtleSwgcmVzcG9uc2UpIHtcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHRvUmVxdWVzdChrZXkpO1xuICAgICAgICAvLyBSdW4gaW4gdGhlIG5leHQgdGFzayB0byBhdm9pZCBibG9ja2luZyBvdGhlciBjYWNoZSByZWFkcy5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3czYy9TZXJ2aWNlV29ya2VyL2lzc3Vlcy8xMzk3XG4gICAgICAgIGF3YWl0IHRpbWVvdXQoMCk7XG4gICAgICAgIGNvbnN0IGVmZmVjdGl2ZVJlcXVlc3QgPSBhd2FpdCB0aGlzLmdldENhY2hlS2V5KHJlcXVlc3QsICd3cml0ZScpO1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKGVmZmVjdGl2ZVJlcXVlc3QubWV0aG9kICYmIGVmZmVjdGl2ZVJlcXVlc3QubWV0aG9kICE9PSAnR0VUJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYXR0ZW1wdC10by1jYWNoZS1ub24tZ2V0LXJlcXVlc3QnLCB7XG4gICAgICAgICAgICAgIHVybDogZ2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpLFxuICAgICAgICAgICAgICBtZXRob2Q6IGVmZmVjdGl2ZVJlcXVlc3QubWV0aG9kXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjgxOFxuICAgICAgICAgIGNvbnN0IHZhcnkgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnVmFyeScpO1xuICAgICAgICAgIGlmICh2YXJ5KSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYFRoZSByZXNwb25zZSBmb3IgJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9IGAgKyBgaGFzIGEgJ1Zhcnk6ICR7dmFyeX0nIGhlYWRlci4gYCArIGBDb25zaWRlciBzZXR0aW5nIHRoZSB7aWdub3JlVmFyeTogdHJ1ZX0gb3B0aW9uIG9uIHlvdXIgc3RyYXRlZ3kgYCArIGB0byBlbnN1cmUgY2FjaGUgbWF0Y2hpbmcgYW5kIGRlbGV0aW9uIHdvcmtzIGFzIGV4cGVjdGVkLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGBDYW5ub3QgY2FjaGUgbm9uLWV4aXN0ZW50IHJlc3BvbnNlIGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKGVmZmVjdGl2ZVJlcXVlc3QudXJsKX0nLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdjYWNoZS1wdXQtd2l0aC1uby1yZXNwb25zZScsIHtcbiAgICAgICAgICAgIHVybDogZ2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzcG9uc2VUb0NhY2hlID0gYXdhaXQgdGhpcy5fZW5zdXJlUmVzcG9uc2VTYWZlVG9DYWNoZShyZXNwb25zZSk7XG4gICAgICAgIGlmICghcmVzcG9uc2VUb0NhY2hlKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBSZXNwb25zZSAnJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9JyBgICsgYHdpbGwgbm90IGJlIGNhY2hlZC5gLCByZXNwb25zZVRvQ2FjaGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgICBtYXRjaE9wdGlvbnNcbiAgICAgICAgfSA9IHRoaXMuX3N0cmF0ZWd5O1xuICAgICAgICBjb25zdCBjYWNoZSA9IGF3YWl0IHNlbGYuY2FjaGVzLm9wZW4oY2FjaGVOYW1lKTtcbiAgICAgICAgY29uc3QgaGFzQ2FjaGVVcGRhdGVDYWxsYmFjayA9IHRoaXMuaGFzQ2FsbGJhY2soJ2NhY2hlRGlkVXBkYXRlJyk7XG4gICAgICAgIGNvbnN0IG9sZFJlc3BvbnNlID0gaGFzQ2FjaGVVcGRhdGVDYWxsYmFjayA/IGF3YWl0IGNhY2hlTWF0Y2hJZ25vcmVQYXJhbXMoXG4gICAgICAgIC8vIFRPRE8ocGhpbGlwd2FsdG9uKTogdGhlIGBfX1dCX1JFVklTSU9OX19gIHBhcmFtIGlzIGEgcHJlY2FjaGluZ1xuICAgICAgICAvLyBmZWF0dXJlLiBDb25zaWRlciBpbnRvIHdheXMgdG8gb25seSBhZGQgdGhpcyBiZWhhdmlvciBpZiB1c2luZ1xuICAgICAgICAvLyBwcmVjYWNoaW5nLlxuICAgICAgICBjYWNoZSwgZWZmZWN0aXZlUmVxdWVzdC5jbG9uZSgpLCBbJ19fV0JfUkVWSVNJT05fXyddLCBtYXRjaE9wdGlvbnMpIDogbnVsbDtcbiAgICAgICAge1xuICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVXBkYXRpbmcgdGhlICcke2NhY2hlTmFtZX0nIGNhY2hlIHdpdGggYSBuZXcgUmVzcG9uc2UgYCArIGBmb3IgJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9LmApO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2FjaGUucHV0KGVmZmVjdGl2ZVJlcXVlc3QsIGhhc0NhY2hlVXBkYXRlQ2FsbGJhY2sgPyByZXNwb25zZVRvQ2FjaGUuY2xvbmUoKSA6IHJlc3BvbnNlVG9DYWNoZSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIC8vIFNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRE9NRXhjZXB0aW9uI2V4Y2VwdGlvbi1RdW90YUV4Y2VlZGVkRXJyb3JcbiAgICAgICAgICAgIGlmIChlcnJvci5uYW1lID09PSAnUXVvdGFFeGNlZWRlZEVycm9yJykge1xuICAgICAgICAgICAgICBhd2FpdCBleGVjdXRlUXVvdGFFcnJvckNhbGxiYWNrcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdjYWNoZURpZFVwZGF0ZScpKSB7XG4gICAgICAgICAgYXdhaXQgY2FsbGJhY2soe1xuICAgICAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICAgICAgb2xkUmVzcG9uc2UsXG4gICAgICAgICAgICBuZXdSZXNwb25zZTogcmVzcG9uc2VUb0NhY2hlLmNsb25lKCksXG4gICAgICAgICAgICByZXF1ZXN0OiBlZmZlY3RpdmVSZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnRcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQ2hlY2tzIHRoZSBsaXN0IG9mIHBsdWdpbnMgZm9yIHRoZSBgY2FjaGVLZXlXaWxsQmVVc2VkYCBjYWxsYmFjaywgYW5kXG4gICAgICAgKiBleGVjdXRlcyBhbnkgb2YgdGhvc2UgY2FsbGJhY2tzIGZvdW5kIGluIHNlcXVlbmNlLiBUaGUgZmluYWwgYFJlcXVlc3RgXG4gICAgICAgKiBvYmplY3QgcmV0dXJuZWQgYnkgdGhlIGxhc3QgcGx1Z2luIGlzIHRyZWF0ZWQgYXMgdGhlIGNhY2hlIGtleSBmb3IgY2FjaGVcbiAgICAgICAqIHJlYWRzIGFuZC9vciB3cml0ZXMuIElmIG5vIGBjYWNoZUtleVdpbGxCZVVzZWRgIHBsdWdpbiBjYWxsYmFja3MgaGF2ZVxuICAgICAgICogYmVlbiByZWdpc3RlcmVkLCB0aGUgcGFzc2VkIHJlcXVlc3QgaXMgcmV0dXJuZWQgdW5tb2RpZmllZFxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gcmVxdWVzdFxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG1vZGVcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVxdWVzdD59XG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGdldENhY2hlS2V5KHJlcXVlc3QsIG1vZGUpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gYCR7cmVxdWVzdC51cmx9IHwgJHttb2RlfWA7XG4gICAgICAgIGlmICghdGhpcy5fY2FjaGVLZXlzW2tleV0pIHtcbiAgICAgICAgICBsZXQgZWZmZWN0aXZlUmVxdWVzdCA9IHJlcXVlc3Q7XG4gICAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ2NhY2hlS2V5V2lsbEJlVXNlZCcpKSB7XG4gICAgICAgICAgICBlZmZlY3RpdmVSZXF1ZXN0ID0gdG9SZXF1ZXN0KGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgbW9kZSxcbiAgICAgICAgICAgICAgcmVxdWVzdDogZWZmZWN0aXZlUmVxdWVzdCxcbiAgICAgICAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnQsXG4gICAgICAgICAgICAgIC8vIHBhcmFtcyBoYXMgYSB0eXBlIGFueSBjYW4ndCBjaGFuZ2UgcmlnaHQgbm93LlxuICAgICAgICAgICAgICBwYXJhbXM6IHRoaXMucGFyYW1zIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5fY2FjaGVLZXlzW2tleV0gPSBlZmZlY3RpdmVSZXF1ZXN0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jYWNoZUtleXNba2V5XTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBzdHJhdGVneSBoYXMgYXQgbGVhc3Qgb25lIHBsdWdpbiB3aXRoIHRoZSBnaXZlblxuICAgICAgICogY2FsbGJhY2suXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG5hbWUgVGhlIG5hbWUgb2YgdGhlIGNhbGxiYWNrIHRvIGNoZWNrIGZvci5cbiAgICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICAgKi9cbiAgICAgIGhhc0NhbGxiYWNrKG5hbWUpIHtcbiAgICAgICAgZm9yIChjb25zdCBwbHVnaW4gb2YgdGhpcy5fc3RyYXRlZ3kucGx1Z2lucykge1xuICAgICAgICAgIGlmIChuYW1lIGluIHBsdWdpbikge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUnVucyBhbGwgcGx1Z2luIGNhbGxiYWNrcyBtYXRjaGluZyB0aGUgZ2l2ZW4gbmFtZSwgaW4gb3JkZXIsIHBhc3NpbmcgdGhlXG4gICAgICAgKiBnaXZlbiBwYXJhbSBvYmplY3QgKG1lcmdlZCBpdGggdGhlIGN1cnJlbnQgcGx1Z2luIHN0YXRlKSBhcyB0aGUgb25seVxuICAgICAgICogYXJndW1lbnQuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogc2luY2UgdGhpcyBtZXRob2QgcnVucyBhbGwgcGx1Z2lucywgaXQncyBub3Qgc3VpdGFibGUgZm9yIGNhc2VzXG4gICAgICAgKiB3aGVyZSB0aGUgcmV0dXJuIHZhbHVlIG9mIGEgY2FsbGJhY2sgbmVlZHMgdG8gYmUgYXBwbGllZCBwcmlvciB0byBjYWxsaW5nXG4gICAgICAgKiB0aGUgbmV4dCBjYWxsYmFjay4gU2VlXG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlciNpdGVyYXRlQ2FsbGJhY2tzfVxuICAgICAgICogYmVsb3cgZm9yIGhvdyB0byBoYW5kbGUgdGhhdCBjYXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIFRoZSBuYW1lIG9mIHRoZSBjYWxsYmFjayB0byBydW4gd2l0aGluIGVhY2ggcGx1Z2luLlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IHBhcmFtIFRoZSBvYmplY3QgdG8gcGFzcyBhcyB0aGUgZmlyc3QgKGFuZCBvbmx5KSBwYXJhbVxuICAgICAgICogICAgIHdoZW4gZXhlY3V0aW5nIGVhY2ggY2FsbGJhY2suIFRoaXMgb2JqZWN0IHdpbGwgYmUgbWVyZ2VkIHdpdGggdGhlXG4gICAgICAgKiAgICAgY3VycmVudCBwbHVnaW4gc3RhdGUgcHJpb3IgdG8gY2FsbGJhY2sgZXhlY3V0aW9uLlxuICAgICAgICovXG4gICAgICBhc3luYyBydW5DYWxsYmFja3MobmFtZSwgcGFyYW0pIHtcbiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MobmFtZSkpIHtcbiAgICAgICAgICAvLyBUT0RPKHBoaWxpcHdhbHRvbik6IG5vdCBzdXJlIHdoeSBgYW55YCBpcyBuZWVkZWQuIEl0IHNlZW1zIGxpa2VcbiAgICAgICAgICAvLyB0aGlzIHNob3VsZCB3b3JrIHdpdGggYGFzIFdvcmtib3hQbHVnaW5DYWxsYmFja1BhcmFtW0NdYC5cbiAgICAgICAgICBhd2FpdCBjYWxsYmFjayhwYXJhbSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQWNjZXB0cyBhIGNhbGxiYWNrIGFuZCByZXR1cm5zIGFuIGl0ZXJhYmxlIG9mIG1hdGNoaW5nIHBsdWdpbiBjYWxsYmFja3MsXG4gICAgICAgKiB3aGVyZSBlYWNoIGNhbGxiYWNrIGlzIHdyYXBwZWQgd2l0aCB0aGUgY3VycmVudCBoYW5kbGVyIHN0YXRlIChpLmUuIHdoZW5cbiAgICAgICAqIHlvdSBjYWxsIGVhY2ggY2FsbGJhY2ssIHdoYXRldmVyIG9iamVjdCBwYXJhbWV0ZXIgeW91IHBhc3MgaXQgd2lsbFxuICAgICAgICogYmUgbWVyZ2VkIHdpdGggdGhlIHBsdWdpbidzIGN1cnJlbnQgc3RhdGUpLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIFRoZSBuYW1lIGZvIHRoZSBjYWxsYmFjayB0byBydW5cbiAgICAgICAqIEByZXR1cm4ge0FycmF5PEZ1bmN0aW9uPn1cbiAgICAgICAqL1xuICAgICAgKml0ZXJhdGVDYWxsYmFja3MobmFtZSkge1xuICAgICAgICBmb3IgKGNvbnN0IHBsdWdpbiBvZiB0aGlzLl9zdHJhdGVneS5wbHVnaW5zKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBwbHVnaW5bbmFtZV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gdGhpcy5fcGx1Z2luU3RhdGVNYXAuZ2V0KHBsdWdpbik7XG4gICAgICAgICAgICBjb25zdCBzdGF0ZWZ1bENhbGxiYWNrID0gcGFyYW0gPT4ge1xuICAgICAgICAgICAgICBjb25zdCBzdGF0ZWZ1bFBhcmFtID0gT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCBwYXJhbSksIHtcbiAgICAgICAgICAgICAgICBzdGF0ZVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBub3Qgc3VyZSB3aHkgYGFueWAgaXMgbmVlZGVkLiBJdCBzZWVtcyBsaWtlXG4gICAgICAgICAgICAgIC8vIHRoaXMgc2hvdWxkIHdvcmsgd2l0aCBgYXMgV29ya2JveFBsdWdpbkNhbGxiYWNrUGFyYW1bQ11gLlxuICAgICAgICAgICAgICByZXR1cm4gcGx1Z2luW25hbWVdKHN0YXRlZnVsUGFyYW0pO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHlpZWxkIHN0YXRlZnVsQ2FsbGJhY2s7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFkZHMgYSBwcm9taXNlIHRvIHRoZVxuICAgICAgICogW2V4dGVuZCBsaWZldGltZSBwcm9taXNlc117QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2V4dGVuZGFibGVldmVudC1leHRlbmQtbGlmZXRpbWUtcHJvbWlzZXN9XG4gICAgICAgKiBvZiB0aGUgZXZlbnQgYXNzb2NpYXRlZCB3aXRoIHRoZSByZXF1ZXN0IGJlaW5nIGhhbmRsZWQgKHVzdWFsbHkgYVxuICAgICAgICogYEZldGNoRXZlbnRgKS5cbiAgICAgICAqXG4gICAgICAgKiBOb3RlOiB5b3UgY2FuIGF3YWl0XG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlcn5kb25lV2FpdGluZ31cbiAgICAgICAqIHRvIGtub3cgd2hlbiBhbGwgYWRkZWQgcHJvbWlzZXMgaGF2ZSBzZXR0bGVkLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UHJvbWlzZX0gcHJvbWlzZSBBIHByb21pc2UgdG8gYWRkIHRvIHRoZSBleHRlbmQgbGlmZXRpbWUgcHJvbWlzZXNcbiAgICAgICAqICAgICBvZiB0aGUgZXZlbnQgdGhhdCB0cmlnZ2VyZWQgdGhlIHJlcXVlc3QuXG4gICAgICAgKi9cbiAgICAgIHdhaXRVbnRpbChwcm9taXNlKSB7XG4gICAgICAgIHRoaXMuX2V4dGVuZExpZmV0aW1lUHJvbWlzZXMucHVzaChwcm9taXNlKTtcbiAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSBhbGwgcHJvbWlzZXMgcGFzc2VkIHRvXG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlcn53YWl0VW50aWx9XG4gICAgICAgKiBoYXZlIHNldHRsZWQuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogYW55IHdvcmsgZG9uZSBhZnRlciBgZG9uZVdhaXRpbmcoKWAgc2V0dGxlcyBzaG91bGQgYmUgbWFudWFsbHlcbiAgICAgICAqIHBhc3NlZCB0byBhbiBldmVudCdzIGB3YWl0VW50aWwoKWAgbWV0aG9kIChub3QgdGhpcyBoYW5kbGVyJ3NcbiAgICAgICAqIGB3YWl0VW50aWwoKWAgbWV0aG9kKSwgb3RoZXJ3aXNlIHRoZSBzZXJ2aWNlIHdvcmtlciB0aHJlYWQgbWF5IGJlIGtpbGxlZFxuICAgICAgICogcHJpb3IgdG8geW91ciB3b3JrIGNvbXBsZXRpbmcuXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGRvbmVXYWl0aW5nKCkge1xuICAgICAgICB3aGlsZSAodGhpcy5fZXh0ZW5kTGlmZXRpbWVQcm9taXNlcy5sZW5ndGgpIHtcbiAgICAgICAgICBjb25zdCBwcm9taXNlcyA9IHRoaXMuX2V4dGVuZExpZmV0aW1lUHJvbWlzZXMuc3BsaWNlKDApO1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChwcm9taXNlcyk7XG4gICAgICAgICAgY29uc3QgZmlyc3RSZWplY3Rpb24gPSByZXN1bHQuZmluZChpID0+IGkuc3RhdHVzID09PSAncmVqZWN0ZWQnKTtcbiAgICAgICAgICBpZiAoZmlyc3RSZWplY3Rpb24pIHtcbiAgICAgICAgICAgIHRocm93IGZpcnN0UmVqZWN0aW9uLnJlYXNvbjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogU3RvcHMgcnVubmluZyB0aGUgc3RyYXRlZ3kgYW5kIGltbWVkaWF0ZWx5IHJlc29sdmVzIGFueSBwZW5kaW5nXG4gICAgICAgKiBgd2FpdFVudGlsKClgIHByb21pc2VzLlxuICAgICAgICovXG4gICAgICBkZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9oYW5kbGVyRGVmZXJyZWQucmVzb2x2ZShudWxsKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBtZXRob2Qgd2lsbCBjYWxsIGNhY2hlV2lsbFVwZGF0ZSBvbiB0aGUgYXZhaWxhYmxlIHBsdWdpbnMgKG9yIHVzZVxuICAgICAgICogc3RhdHVzID09PSAyMDApIHRvIGRldGVybWluZSBpZiB0aGUgUmVzcG9uc2UgaXMgc2FmZSBhbmQgdmFsaWQgdG8gY2FjaGUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fSBvcHRpb25zLnJlcXVlc3RcbiAgICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IG9wdGlvbnMucmVzcG9uc2VcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2V8dW5kZWZpbmVkPn1cbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBhc3luYyBfZW5zdXJlUmVzcG9uc2VTYWZlVG9DYWNoZShyZXNwb25zZSkge1xuICAgICAgICBsZXQgcmVzcG9uc2VUb0NhY2hlID0gcmVzcG9uc2U7XG4gICAgICAgIGxldCBwbHVnaW5zVXNlZCA9IGZhbHNlO1xuICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIHRoaXMuaXRlcmF0ZUNhbGxiYWNrcygnY2FjaGVXaWxsVXBkYXRlJykpIHtcbiAgICAgICAgICByZXNwb25zZVRvQ2FjaGUgPSAoYXdhaXQgY2FsbGJhY2soe1xuICAgICAgICAgICAgcmVxdWVzdDogdGhpcy5yZXF1ZXN0LFxuICAgICAgICAgICAgcmVzcG9uc2U6IHJlc3BvbnNlVG9DYWNoZSxcbiAgICAgICAgICAgIGV2ZW50OiB0aGlzLmV2ZW50XG4gICAgICAgICAgfSkpIHx8IHVuZGVmaW5lZDtcbiAgICAgICAgICBwbHVnaW5zVXNlZCA9IHRydWU7XG4gICAgICAgICAgaWYgKCFyZXNwb25zZVRvQ2FjaGUpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXBsdWdpbnNVc2VkKSB7XG4gICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZSAmJiByZXNwb25zZVRvQ2FjaGUuc3RhdHVzICE9PSAyMDApIHtcbiAgICAgICAgICAgIHJlc3BvbnNlVG9DYWNoZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICB9XG4gICAgICAgICAge1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZSkge1xuICAgICAgICAgICAgICBpZiAocmVzcG9uc2VUb0NhY2hlLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZS5zdGF0dXMgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgIGxvZ2dlci53YXJuKGBUaGUgcmVzcG9uc2UgZm9yICcke3RoaXMucmVxdWVzdC51cmx9JyBgICsgYGlzIGFuIG9wYXF1ZSByZXNwb25zZS4gVGhlIGNhY2hpbmcgc3RyYXRlZ3kgdGhhdCB5b3UncmUgYCArIGB1c2luZyB3aWxsIG5vdCBjYWNoZSBvcGFxdWUgcmVzcG9uc2VzIGJ5IGRlZmF1bHQuYCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVGhlIHJlc3BvbnNlIGZvciAnJHt0aGlzLnJlcXVlc3QudXJsfScgYCArIGByZXR1cm5lZCBhIHN0YXR1cyBjb2RlIG9mICcke3Jlc3BvbnNlLnN0YXR1c30nIGFuZCB3b24ndCBgICsgYGJlIGNhY2hlZCBhcyBhIHJlc3VsdC5gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlVG9DYWNoZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBbiBhYnN0cmFjdCBiYXNlIGNsYXNzIHRoYXQgYWxsIG90aGVyIHN0cmF0ZWd5IGNsYXNzZXMgbXVzdCBleHRlbmQgZnJvbTpcbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXNcbiAgICAgKi9cbiAgICBjbGFzcyBTdHJhdGVneSB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgdGhlIHN0cmF0ZWd5IGFuZCBzZXRzIGFsbCBkb2N1bWVudGVkIG9wdGlvblxuICAgICAgICogcHJvcGVydGllcyBhcyBwdWJsaWMgaW5zdGFuY2UgcHJvcGVydGllcy5cbiAgICAgICAqXG4gICAgICAgKiBOb3RlOiBpZiBhIGN1c3RvbSBzdHJhdGVneSBjbGFzcyBleHRlbmRzIHRoZSBiYXNlIFN0cmF0ZWd5IGNsYXNzIGFuZCBkb2VzXG4gICAgICAgKiBub3QgbmVlZCBtb3JlIHRoYW4gdGhlc2UgcHJvcGVydGllcywgaXQgZG9lcyBub3QgbmVlZCB0byBkZWZpbmUgaXRzIG93blxuICAgICAgICogY29uc3RydWN0b3IuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLmNhY2hlTmFtZV0gQ2FjaGUgbmFtZSB0byBzdG9yZSBhbmQgcmV0cmlldmVcbiAgICAgICAqIHJlcXVlc3RzLiBEZWZhdWx0cyB0byB0aGUgY2FjaGUgbmFtZXMgcHJvdmlkZWQgYnlcbiAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc30uXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IFtvcHRpb25zLnBsdWdpbnNdIFtQbHVnaW5zXXtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvdG9vbHMvd29ya2JveC9ndWlkZXMvdXNpbmctcGx1Z2luc31cbiAgICAgICAqIHRvIHVzZSBpbiBjb25qdW5jdGlvbiB3aXRoIHRoaXMgY2FjaGluZyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5mZXRjaE9wdGlvbnNdIFZhbHVlcyBwYXNzZWQgYWxvbmcgdG8gdGhlXG4gICAgICAgKiBbYGluaXRgXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2luZG93T3JXb3JrZXJHbG9iYWxTY29wZS9mZXRjaCNQYXJhbWV0ZXJzKVxuICAgICAgICogb2YgW25vbi1uYXZpZ2F0aW9uXShodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzE3OTYpXG4gICAgICAgKiBgZmV0Y2goKWAgcmVxdWVzdHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zLm1hdGNoT3B0aW9uc10gVGhlXG4gICAgICAgKiBbYENhY2hlUXVlcnlPcHRpb25zYF17QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2RpY3RkZWYtY2FjaGVxdWVyeW9wdGlvbnN9XG4gICAgICAgKiBmb3IgYW55IGBjYWNoZS5tYXRjaCgpYCBvciBgY2FjaGUucHV0KClgIGNhbGxzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWNoZSBuYW1lIHRvIHN0b3JlIGFuZCByZXRyaWV2ZVxuICAgICAgICAgKiByZXF1ZXN0cy4gRGVmYXVsdHMgdG8gdGhlIGNhY2hlIG5hbWVzIHByb3ZpZGVkIGJ5XG4gICAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc30uXG4gICAgICAgICAqXG4gICAgICAgICAqIEB0eXBlIHtzdHJpbmd9XG4gICAgICAgICAqL1xuICAgICAgICB0aGlzLmNhY2hlTmFtZSA9IGNhY2hlTmFtZXMuZ2V0UnVudGltZU5hbWUob3B0aW9ucy5jYWNoZU5hbWUpO1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIGxpc3RcbiAgICAgICAgICogW1BsdWdpbnNde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3dlYi90b29scy93b3JrYm94L2d1aWRlcy91c2luZy1wbHVnaW5zfVxuICAgICAgICAgKiB1c2VkIGJ5IHRoaXMgc3RyYXRlZ3kuXG4gICAgICAgICAqXG4gICAgICAgICAqIEB0eXBlIHtBcnJheTxPYmplY3Q+fVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5wbHVnaW5zID0gb3B0aW9ucy5wbHVnaW5zIHx8IFtdO1xuICAgICAgICAvKipcbiAgICAgICAgICogVmFsdWVzIHBhc3NlZCBhbG9uZyB0byB0aGVcbiAgICAgICAgICogW2Bpbml0YF17QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1dpbmRvd09yV29ya2VyR2xvYmFsU2NvcGUvZmV0Y2gjUGFyYW1ldGVyc31cbiAgICAgICAgICogb2YgYWxsIGZldGNoKCkgcmVxdWVzdHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAdHlwZSB7T2JqZWN0fVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5mZXRjaE9wdGlvbnMgPSBvcHRpb25zLmZldGNoT3B0aW9ucztcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZVxuICAgICAgICAgKiBbYENhY2hlUXVlcnlPcHRpb25zYF17QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2RpY3RkZWYtY2FjaGVxdWVyeW9wdGlvbnN9XG4gICAgICAgICAqIGZvciBhbnkgYGNhY2hlLm1hdGNoKClgIG9yIGBjYWNoZS5wdXQoKWAgY2FsbHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAdHlwZSB7T2JqZWN0fVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5tYXRjaE9wdGlvbnMgPSBvcHRpb25zLm1hdGNoT3B0aW9ucztcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUGVyZm9ybSBhIHJlcXVlc3Qgc3RyYXRlZ3kgYW5kIHJldHVybnMgYSBgUHJvbWlzZWAgdGhhdCB3aWxsIHJlc29sdmUgd2l0aFxuICAgICAgICogYSBgUmVzcG9uc2VgLCBpbnZva2luZyBhbGwgcmVsZXZhbnQgcGx1Z2luIGNhbGxiYWNrcy5cbiAgICAgICAqXG4gICAgICAgKiBXaGVuIGEgc3RyYXRlZ3kgaW5zdGFuY2UgaXMgcmVnaXN0ZXJlZCB3aXRoIGEgV29ya2JveFxuICAgICAgICoge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZX0sIHRoaXMgbWV0aG9kIGlzIGF1dG9tYXRpY2FsbHlcbiAgICAgICAqIGNhbGxlZCB3aGVuIHRoZSByb3V0ZSBtYXRjaGVzLlxuICAgICAgICpcbiAgICAgICAqIEFsdGVybmF0aXZlbHksIHRoaXMgbWV0aG9kIGNhbiBiZSB1c2VkIGluIGEgc3RhbmRhbG9uZSBgRmV0Y2hFdmVudGBcbiAgICAgICAqIGxpc3RlbmVyIGJ5IHBhc3NpbmcgaXQgdG8gYGV2ZW50LnJlc3BvbmRXaXRoKClgLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RmV0Y2hFdmVudHxPYmplY3R9IG9wdGlvbnMgQSBgRmV0Y2hFdmVudGAgb3IgYW4gb2JqZWN0IHdpdGggdGhlXG4gICAgICAgKiAgICAgcHJvcGVydGllcyBsaXN0ZWQgYmVsb3cuXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBvcHRpb25zLnJlcXVlc3QgQSByZXF1ZXN0IHRvIHJ1biB0aGlzIHN0cmF0ZWd5IGZvci5cbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBvcHRpb25zLmV2ZW50IFRoZSBldmVudCBhc3NvY2lhdGVkIHdpdGggdGhlXG4gICAgICAgKiAgICAgcmVxdWVzdC5cbiAgICAgICAqIEBwYXJhbSB7VVJMfSBbb3B0aW9ucy51cmxdXG4gICAgICAgKiBAcGFyYW0geyp9IFtvcHRpb25zLnBhcmFtc11cbiAgICAgICAqL1xuICAgICAgaGFuZGxlKG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgW3Jlc3BvbnNlRG9uZV0gPSB0aGlzLmhhbmRsZUFsbChvcHRpb25zKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlRG9uZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogU2ltaWxhciB0byB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fmhhbmRsZX0sIGJ1dFxuICAgICAgICogaW5zdGVhZCBvZiBqdXN0IHJldHVybmluZyBhIGBQcm9taXNlYCB0aGF0IHJlc29sdmVzIHRvIGEgYFJlc3BvbnNlYCBpdFxuICAgICAgICogaXQgd2lsbCByZXR1cm4gYW4gdHVwbGUgb2YgYFtyZXNwb25zZSwgZG9uZV1gIHByb21pc2VzLCB3aGVyZSB0aGUgZm9ybWVyXG4gICAgICAgKiAoYHJlc3BvbnNlYCkgaXMgZXF1aXZhbGVudCB0byB3aGF0IGBoYW5kbGUoKWAgcmV0dXJucywgYW5kIHRoZSBsYXR0ZXIgaXMgYVxuICAgICAgICogUHJvbWlzZSB0aGF0IHdpbGwgcmVzb2x2ZSBvbmNlIGFueSBwcm9taXNlcyB0aGF0IHdlcmUgYWRkZWQgdG9cbiAgICAgICAqIGBldmVudC53YWl0VW50aWwoKWAgYXMgcGFydCBvZiBwZXJmb3JtaW5nIHRoZSBzdHJhdGVneSBoYXZlIGNvbXBsZXRlZC5cbiAgICAgICAqXG4gICAgICAgKiBZb3UgY2FuIGF3YWl0IHRoZSBgZG9uZWAgcHJvbWlzZSB0byBlbnN1cmUgYW55IGV4dHJhIHdvcmsgcGVyZm9ybWVkIGJ5XG4gICAgICAgKiB0aGUgc3RyYXRlZ3kgKHVzdWFsbHkgY2FjaGluZyByZXNwb25zZXMpIGNvbXBsZXRlcyBzdWNjZXNzZnVsbHkuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtGZXRjaEV2ZW50fE9iamVjdH0gb3B0aW9ucyBBIGBGZXRjaEV2ZW50YCBvciBhbiBvYmplY3Qgd2l0aCB0aGVcbiAgICAgICAqICAgICBwcm9wZXJ0aWVzIGxpc3RlZCBiZWxvdy5cbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IG9wdGlvbnMucmVxdWVzdCBBIHJlcXVlc3QgdG8gcnVuIHRoaXMgc3RyYXRlZ3kgZm9yLlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IG9wdGlvbnMuZXZlbnQgVGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGVcbiAgICAgICAqICAgICByZXF1ZXN0LlxuICAgICAgICogQHBhcmFtIHtVUkx9IFtvcHRpb25zLnVybF1cbiAgICAgICAqIEBwYXJhbSB7Kn0gW29wdGlvbnMucGFyYW1zXVxuICAgICAgICogQHJldHVybiB7QXJyYXk8UHJvbWlzZT59IEEgdHVwbGUgb2YgW3Jlc3BvbnNlLCBkb25lXVxuICAgICAgICogICAgIHByb21pc2VzIHRoYXQgY2FuIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHdoZW4gdGhlIHJlc3BvbnNlIHJlc29sdmVzIGFzXG4gICAgICAgKiAgICAgd2VsbCBhcyB3aGVuIHRoZSBoYW5kbGVyIGhhcyBjb21wbGV0ZWQgYWxsIGl0cyB3b3JrLlxuICAgICAgICovXG4gICAgICBoYW5kbGVBbGwob3B0aW9ucykge1xuICAgICAgICAvLyBBbGxvdyBmb3IgZmxleGlibGUgb3B0aW9ucyB0byBiZSBwYXNzZWQuXG4gICAgICAgIGlmIChvcHRpb25zIGluc3RhbmNlb2YgRmV0Y2hFdmVudCkge1xuICAgICAgICAgIG9wdGlvbnMgPSB7XG4gICAgICAgICAgICBldmVudDogb3B0aW9ucyxcbiAgICAgICAgICAgIHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZXZlbnQgPSBvcHRpb25zLmV2ZW50O1xuICAgICAgICBjb25zdCByZXF1ZXN0ID0gdHlwZW9mIG9wdGlvbnMucmVxdWVzdCA9PT0gJ3N0cmluZycgPyBuZXcgUmVxdWVzdChvcHRpb25zLnJlcXVlc3QpIDogb3B0aW9ucy5yZXF1ZXN0O1xuICAgICAgICBjb25zdCBwYXJhbXMgPSAncGFyYW1zJyBpbiBvcHRpb25zID8gb3B0aW9ucy5wYXJhbXMgOiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSBuZXcgU3RyYXRlZ3lIYW5kbGVyKHRoaXMsIHtcbiAgICAgICAgICBldmVudCxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHBhcmFtc1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VEb25lID0gdGhpcy5fZ2V0UmVzcG9uc2UoaGFuZGxlciwgcmVxdWVzdCwgZXZlbnQpO1xuICAgICAgICBjb25zdCBoYW5kbGVyRG9uZSA9IHRoaXMuX2F3YWl0Q29tcGxldGUocmVzcG9uc2VEb25lLCBoYW5kbGVyLCByZXF1ZXN0LCBldmVudCk7XG4gICAgICAgIC8vIFJldHVybiBhbiBhcnJheSBvZiBwcm9taXNlcywgc3VpdGFibGUgZm9yIHVzZSB3aXRoIFByb21pc2UuYWxsKCkuXG4gICAgICAgIHJldHVybiBbcmVzcG9uc2VEb25lLCBoYW5kbGVyRG9uZV07XG4gICAgICB9XG4gICAgICBhc3luYyBfZ2V0UmVzcG9uc2UoaGFuZGxlciwgcmVxdWVzdCwgZXZlbnQpIHtcbiAgICAgICAgYXdhaXQgaGFuZGxlci5ydW5DYWxsYmFja3MoJ2hhbmRsZXJXaWxsU3RhcnQnLCB7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KTtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gdW5kZWZpbmVkO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJlc3BvbnNlID0gYXdhaXQgdGhpcy5faGFuZGxlKHJlcXVlc3QsIGhhbmRsZXIpO1xuICAgICAgICAgIC8vIFRoZSBcIm9mZmljaWFsXCIgU3RyYXRlZ3kgc3ViY2xhc3NlcyBhbGwgdGhyb3cgdGhpcyBlcnJvciBhdXRvbWF0aWNhbGx5LFxuICAgICAgICAgIC8vIGJ1dCBpbiBjYXNlIGEgdGhpcmQtcGFydHkgU3RyYXRlZ3kgZG9lc24ndCwgZW5zdXJlIHRoYXQgd2UgaGF2ZSBhXG4gICAgICAgICAgLy8gY29uc2lzdGVudCBmYWlsdXJlIHdoZW4gdGhlcmUncyBubyByZXNwb25zZSBvciBhbiBlcnJvciByZXNwb25zZS5cbiAgICAgICAgICBpZiAoIXJlc3BvbnNlIHx8IHJlc3BvbnNlLnR5cGUgPT09ICdlcnJvcicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ25vLXJlc3BvbnNlJywge1xuICAgICAgICAgICAgICB1cmw6IHJlcXVlc3QudXJsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgaGFuZGxlci5pdGVyYXRlQ2FsbGJhY2tzKCdoYW5kbGVyRGlkRXJyb3InKSkge1xuICAgICAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhgV2hpbGUgcmVzcG9uZGluZyB0byAnJHtnZXRGcmllbmRseVVSTChyZXF1ZXN0LnVybCl9JywgYCArIGBhbiAke2Vycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci50b1N0cmluZygpIDogJyd9IGVycm9yIG9jY3VycmVkLiBVc2luZyBhIGZhbGxiYWNrIHJlc3BvbnNlIHByb3ZpZGVkIGJ5IGAgKyBgYSBoYW5kbGVyRGlkRXJyb3IgcGx1Z2luLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIGhhbmRsZXIuaXRlcmF0ZUNhbGxiYWNrcygnaGFuZGxlcldpbGxSZXNwb25kJykpIHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgYXN5bmMgX2F3YWl0Q29tcGxldGUocmVzcG9uc2VEb25lLCBoYW5kbGVyLCByZXF1ZXN0LCBldmVudCkge1xuICAgICAgICBsZXQgcmVzcG9uc2U7XG4gICAgICAgIGxldCBlcnJvcjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IHJlc3BvbnNlRG9uZTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAvLyBJZ25vcmUgZXJyb3JzLCBhcyByZXNwb25zZSBlcnJvcnMgc2hvdWxkIGJlIGNhdWdodCB2aWEgdGhlIGByZXNwb25zZWBcbiAgICAgICAgICAvLyBwcm9taXNlIGFib3ZlLiBUaGUgYGRvbmVgIHByb21pc2Ugd2lsbCBvbmx5IHRocm93IGZvciBlcnJvcnMgaW5cbiAgICAgICAgICAvLyBwcm9taXNlcyBwYXNzZWQgdG8gYGhhbmRsZXIud2FpdFVudGlsKClgLlxuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgaGFuZGxlci5ydW5DYWxsYmFja3MoJ2hhbmRsZXJEaWRSZXNwb25kJywge1xuICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgcmVzcG9uc2VcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhd2FpdCBoYW5kbGVyLmRvbmVXYWl0aW5nKCk7XG4gICAgICAgIH0gY2F0Y2ggKHdhaXRVbnRpbEVycm9yKSB7XG4gICAgICAgICAgaWYgKHdhaXRVbnRpbEVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIGVycm9yID0gd2FpdFVudGlsRXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGF3YWl0IGhhbmRsZXIucnVuQ2FsbGJhY2tzKCdoYW5kbGVyRGlkQ29tcGxldGUnLCB7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3JcbiAgICAgICAgfSk7XG4gICAgICAgIGhhbmRsZXIuZGVzdHJveSgpO1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBDbGFzc2VzIGV4dGVuZGluZyB0aGUgYFN0cmF0ZWd5YCBiYXNlZCBjbGFzcyBzaG91bGQgaW1wbGVtZW50IHRoaXMgbWV0aG9kLFxuICAgICAqIGFuZCBsZXZlcmFnZSB0aGUge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ9XG4gICAgICogYXJnIHRvIHBlcmZvcm0gYWxsIGZldGNoaW5nIGFuZCBjYWNoZSBsb2dpYywgd2hpY2ggd2lsbCBlbnN1cmUgYWxsIHJlbGV2YW50XG4gICAgICogY2FjaGUsIGNhY2hlIG9wdGlvbnMsIGZldGNoIG9wdGlvbnMgYW5kIHBsdWdpbnMgYXJlIHVzZWQgKHBlciB0aGUgY3VycmVudFxuICAgICAqIHN0cmF0ZWd5IGluc3RhbmNlKS5cbiAgICAgKlxuICAgICAqIEBuYW1lIF9oYW5kbGVcbiAgICAgKiBAaW5zdGFuY2VcbiAgICAgKiBAYWJzdHJhY3RcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3RcbiAgICAgKiBAcGFyYW0ge3dvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ9IGhhbmRsZXJcbiAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPn1cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lcbiAgICAgKi9cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneX0gaW1wbGVtZW50YXRpb25cbiAgICAgKiBzcGVjaWZpY2FsbHkgZGVzaWduZWQgdG8gd29yayB3aXRoXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXJ9XG4gICAgICogdG8gYm90aCBjYWNoZSBhbmQgZmV0Y2ggcHJlY2FjaGVkIGFzc2V0cy5cbiAgICAgKlxuICAgICAqIE5vdGU6IGFuIGluc3RhbmNlIG9mIHRoaXMgY2xhc3MgaXMgY3JlYXRlZCBhdXRvbWF0aWNhbGx5IHdoZW4gY3JlYXRpbmcgYVxuICAgICAqIGBQcmVjYWNoZUNvbnRyb2xsZXJgOyBpdCdzIGdlbmVyYWxseSBub3QgbmVjZXNzYXJ5IHRvIGNyZWF0ZSB0aGlzIHlvdXJzZWxmLlxuICAgICAqXG4gICAgICogQGV4dGVuZHMgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5XG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGNsYXNzIFByZWNhY2hlU3RyYXRlZ3kgZXh0ZW5kcyBTdHJhdGVneSB7XG4gICAgICAvKipcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdGlvbnMuY2FjaGVOYW1lXSBDYWNoZSBuYW1lIHRvIHN0b3JlIGFuZCByZXRyaWV2ZVxuICAgICAgICogcmVxdWVzdHMuIERlZmF1bHRzIHRvIHRoZSBjYWNoZSBuYW1lcyBwcm92aWRlZCBieVxuICAgICAgICoge0BsaW5rIHdvcmtib3gtY29yZS5jYWNoZU5hbWVzfS5cbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8T2JqZWN0Pn0gW29wdGlvbnMucGx1Z2luc10ge0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3dlYi90b29scy93b3JrYm94L2d1aWRlcy91c2luZy1wbHVnaW5zfFBsdWdpbnN9XG4gICAgICAgKiB0byB1c2UgaW4gY29uanVuY3Rpb24gd2l0aCB0aGlzIGNhY2hpbmcgc3RyYXRlZ3kuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnMuZmV0Y2hPcHRpb25zXSBWYWx1ZXMgcGFzc2VkIGFsb25nIHRvIHRoZVxuICAgICAgICoge0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9XaW5kb3dPcldvcmtlckdsb2JhbFNjb3BlL2ZldGNoI1BhcmFtZXRlcnN8aW5pdH1cbiAgICAgICAqIG9mIGFsbCBmZXRjaCgpIHJlcXVlc3RzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5tYXRjaE9wdGlvbnNdIFRoZVxuICAgICAgICoge0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby9TZXJ2aWNlV29ya2VyLyNkaWN0ZGVmLWNhY2hlcXVlcnlvcHRpb25zfENhY2hlUXVlcnlPcHRpb25zfVxuICAgICAgICogZm9yIGFueSBgY2FjaGUubWF0Y2goKWAgb3IgYGNhY2hlLnB1dCgpYCBjYWxscyBtYWRlIGJ5IHRoaXMgc3RyYXRlZ3kuXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IFtvcHRpb25zLmZhbGxiYWNrVG9OZXR3b3JrPXRydWVdIFdoZXRoZXIgdG8gYXR0ZW1wdCB0b1xuICAgICAgICogZ2V0IHRoZSByZXNwb25zZSBmcm9tIHRoZSBuZXR3b3JrIGlmIHRoZXJlJ3MgYSBwcmVjYWNoZSBtaXNzLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICAgICAgb3B0aW9ucy5jYWNoZU5hbWUgPSBjYWNoZU5hbWVzLmdldFByZWNhY2hlTmFtZShvcHRpb25zLmNhY2hlTmFtZSk7XG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLl9mYWxsYmFja1RvTmV0d29yayA9IG9wdGlvbnMuZmFsbGJhY2tUb05ldHdvcmsgPT09IGZhbHNlID8gZmFsc2UgOiB0cnVlO1xuICAgICAgICAvLyBSZWRpcmVjdGVkIHJlc3BvbnNlcyBjYW5ub3QgYmUgdXNlZCB0byBzYXRpc2Z5IGEgbmF2aWdhdGlvbiByZXF1ZXN0LCBzb1xuICAgICAgICAvLyBhbnkgcmVkaXJlY3RlZCByZXNwb25zZSBtdXN0IGJlIFwiY29waWVkXCIgcmF0aGVyIHRoYW4gY2xvbmVkLCBzbyB0aGUgbmV3XG4gICAgICAgIC8vIHJlc3BvbnNlIGRvZXNuJ3QgY29udGFpbiB0aGUgYHJlZGlyZWN0ZWRgIGZsYWcuIFNlZTpcbiAgICAgICAgLy8gaHR0cHM6Ly9idWdzLmNocm9taXVtLm9yZy9wL2Nocm9taXVtL2lzc3Vlcy9kZXRhaWw/aWQ9NjY5MzYzJmRlc2M9MiNjMVxuICAgICAgICB0aGlzLnBsdWdpbnMucHVzaChQcmVjYWNoZVN0cmF0ZWd5LmNvcHlSZWRpcmVjdGVkQ2FjaGVhYmxlUmVzcG9uc2VzUGx1Z2luKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IHJlcXVlc3QgQSByZXF1ZXN0IHRvIHJ1biB0aGlzIHN0cmF0ZWd5IGZvci5cbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlcn0gaGFuZGxlciBUaGUgZXZlbnQgdGhhdFxuICAgICAgICogICAgIHRyaWdnZXJlZCB0aGUgcmVxdWVzdC5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2U+fVxuICAgICAgICovXG4gICAgICBhc3luYyBfaGFuZGxlKHJlcXVlc3QsIGhhbmRsZXIpIHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBoYW5kbGVyLmNhY2hlTWF0Y2gocmVxdWVzdCk7XG4gICAgICAgIGlmIChyZXNwb25zZSkge1xuICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiB0aGlzIGlzIGFuIGBpbnN0YWxsYCBldmVudCBmb3IgYW4gZW50cnkgdGhhdCBpc24ndCBhbHJlYWR5IGNhY2hlZCxcbiAgICAgICAgLy8gdGhlbiBwb3B1bGF0ZSB0aGUgY2FjaGUuXG4gICAgICAgIGlmIChoYW5kbGVyLmV2ZW50ICYmIGhhbmRsZXIuZXZlbnQudHlwZSA9PT0gJ2luc3RhbGwnKSB7XG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2hhbmRsZUluc3RhbGwocmVxdWVzdCwgaGFuZGxlcik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gR2V0dGluZyBoZXJlIG1lYW5zIHNvbWV0aGluZyB3ZW50IHdyb25nLiBBbiBlbnRyeSB0aGF0IHNob3VsZCBoYXZlIGJlZW5cbiAgICAgICAgLy8gcHJlY2FjaGVkIHdhc24ndCBmb3VuZCBpbiB0aGUgY2FjaGUuXG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9oYW5kbGVGZXRjaChyZXF1ZXN0LCBoYW5kbGVyKTtcbiAgICAgIH1cbiAgICAgIGFzeW5jIF9oYW5kbGVGZXRjaChyZXF1ZXN0LCBoYW5kbGVyKSB7XG4gICAgICAgIGxldCByZXNwb25zZTtcbiAgICAgICAgY29uc3QgcGFyYW1zID0gaGFuZGxlci5wYXJhbXMgfHwge307XG4gICAgICAgIC8vIEZhbGwgYmFjayB0byB0aGUgbmV0d29yayBpZiB3ZSdyZSBjb25maWd1cmVkIHRvIGRvIHNvLlxuICAgICAgICBpZiAodGhpcy5fZmFsbGJhY2tUb05ldHdvcmspIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBsb2dnZXIud2FybihgVGhlIHByZWNhY2hlZCByZXNwb25zZSBmb3IgYCArIGAke2dldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKX0gaW4gJHt0aGlzLmNhY2hlTmFtZX0gd2FzIG5vdCBgICsgYGZvdW5kLiBGYWxsaW5nIGJhY2sgdG8gdGhlIG5ldHdvcmsuYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGludGVncml0eUluTWFuaWZlc3QgPSBwYXJhbXMuaW50ZWdyaXR5O1xuICAgICAgICAgIGNvbnN0IGludGVncml0eUluUmVxdWVzdCA9IHJlcXVlc3QuaW50ZWdyaXR5O1xuICAgICAgICAgIGNvbnN0IG5vSW50ZWdyaXR5Q29uZmxpY3QgPSAhaW50ZWdyaXR5SW5SZXF1ZXN0IHx8IGludGVncml0eUluUmVxdWVzdCA9PT0gaW50ZWdyaXR5SW5NYW5pZmVzdDtcbiAgICAgICAgICAvLyBEbyBub3QgYWRkIGludGVncml0eSBpZiB0aGUgb3JpZ2luYWwgcmVxdWVzdCBpcyBuby1jb3JzXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMzA5NlxuICAgICAgICAgIHJlc3BvbnNlID0gYXdhaXQgaGFuZGxlci5mZXRjaChuZXcgUmVxdWVzdChyZXF1ZXN0LCB7XG4gICAgICAgICAgICBpbnRlZ3JpdHk6IHJlcXVlc3QubW9kZSAhPT0gJ25vLWNvcnMnID8gaW50ZWdyaXR5SW5SZXF1ZXN0IHx8IGludGVncml0eUluTWFuaWZlc3QgOiB1bmRlZmluZWRcbiAgICAgICAgICB9KSk7XG4gICAgICAgICAgLy8gSXQncyBvbmx5IFwic2FmZVwiIHRvIHJlcGFpciB0aGUgY2FjaGUgaWYgd2UncmUgdXNpbmcgU1JJIHRvIGd1YXJhbnRlZVxuICAgICAgICAgIC8vIHRoYXQgdGhlIHJlc3BvbnNlIG1hdGNoZXMgdGhlIHByZWNhY2hlIG1hbmlmZXN0J3MgZXhwZWN0YXRpb25zLFxuICAgICAgICAgIC8vIGFuZCB0aGVyZSdzIGVpdGhlciBhKSBubyBpbnRlZ3JpdHkgcHJvcGVydHkgaW4gdGhlIGluY29taW5nIHJlcXVlc3RcbiAgICAgICAgICAvLyBvciBiKSB0aGVyZSBpcyBhbiBpbnRlZ3JpdHksIGFuZCBpdCBtYXRjaGVzIHRoZSBwcmVjYWNoZSBtYW5pZmVzdC5cbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yODU4XG4gICAgICAgICAgLy8gQWxzbyBpZiB0aGUgb3JpZ2luYWwgcmVxdWVzdCB1c2VycyBuby1jb3JzIHdlIGRvbid0IHVzZSBpbnRlZ3JpdHkuXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMzA5NlxuICAgICAgICAgIGlmIChpbnRlZ3JpdHlJbk1hbmlmZXN0ICYmIG5vSW50ZWdyaXR5Q29uZmxpY3QgJiYgcmVxdWVzdC5tb2RlICE9PSAnbm8tY29ycycpIHtcbiAgICAgICAgICAgIHRoaXMuX3VzZURlZmF1bHRDYWNoZWFiaWxpdHlQbHVnaW5JZk5lZWRlZCgpO1xuICAgICAgICAgICAgY29uc3Qgd2FzQ2FjaGVkID0gYXdhaXQgaGFuZGxlci5jYWNoZVB1dChyZXF1ZXN0LCByZXNwb25zZS5jbG9uZSgpKTtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWYgKHdhc0NhY2hlZCkge1xuICAgICAgICAgICAgICAgIGxvZ2dlci5sb2coYEEgcmVzcG9uc2UgZm9yICR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfSBgICsgYHdhcyB1c2VkIHRvIFwicmVwYWlyXCIgdGhlIHByZWNhY2hlLmApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIFRoaXMgc2hvdWxkbid0IG5vcm1hbGx5IGhhcHBlbiwgYnV0IHRoZXJlIGFyZSBlZGdlIGNhc2VzOlxuICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMTQ0MVxuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ21pc3NpbmctcHJlY2FjaGUtZW50cnknLCB7XG4gICAgICAgICAgICBjYWNoZU5hbWU6IHRoaXMuY2FjaGVOYW1lLFxuICAgICAgICAgICAgdXJsOiByZXF1ZXN0LnVybFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICBjb25zdCBjYWNoZUtleSA9IHBhcmFtcy5jYWNoZUtleSB8fCAoYXdhaXQgaGFuZGxlci5nZXRDYWNoZUtleShyZXF1ZXN0LCAncmVhZCcpKTtcbiAgICAgICAgICAvLyBXb3JrYm94IGlzIGdvaW5nIHRvIGhhbmRsZSB0aGUgcm91dGUuXG4gICAgICAgICAgLy8gcHJpbnQgdGhlIHJvdXRpbmcgZGV0YWlscyB0byB0aGUgY29uc29sZS5cbiAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFByZWNhY2hpbmcgaXMgcmVzcG9uZGluZyB0bzogYCArIGdldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKSk7XG4gICAgICAgICAgbG9nZ2VyLmxvZyhgU2VydmluZyB0aGUgcHJlY2FjaGVkIHVybDogJHtnZXRGcmllbmRseVVSTChjYWNoZUtleSBpbnN0YW5jZW9mIFJlcXVlc3QgPyBjYWNoZUtleS51cmwgOiBjYWNoZUtleSl9YCk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBWaWV3IHJlcXVlc3QgZGV0YWlscyBoZXJlLmApO1xuICAgICAgICAgIGxvZ2dlci5sb2cocmVxdWVzdCk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBWaWV3IHJlc3BvbnNlIGRldGFpbHMgaGVyZS5gKTtcbiAgICAgICAgICBsb2dnZXIubG9nKHJlc3BvbnNlKTtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICBhc3luYyBfaGFuZGxlSW5zdGFsbChyZXF1ZXN0LCBoYW5kbGVyKSB7XG4gICAgICAgIHRoaXMuX3VzZURlZmF1bHRDYWNoZWFiaWxpdHlQbHVnaW5JZk5lZWRlZCgpO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGhhbmRsZXIuZmV0Y2gocmVxdWVzdCk7XG4gICAgICAgIC8vIE1ha2Ugc3VyZSB3ZSBkZWZlciBjYWNoZVB1dCgpIHVudGlsIGFmdGVyIHdlIGtub3cgdGhlIHJlc3BvbnNlXG4gICAgICAgIC8vIHNob3VsZCBiZSBjYWNoZWQ7IHNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzI3MzdcbiAgICAgICAgY29uc3Qgd2FzQ2FjaGVkID0gYXdhaXQgaGFuZGxlci5jYWNoZVB1dChyZXF1ZXN0LCByZXNwb25zZS5jbG9uZSgpKTtcbiAgICAgICAgaWYgKCF3YXNDYWNoZWQpIHtcbiAgICAgICAgICAvLyBUaHJvd2luZyBoZXJlIHdpbGwgbGVhZCB0byB0aGUgYGluc3RhbGxgIGhhbmRsZXIgZmFpbGluZywgd2hpY2hcbiAgICAgICAgICAvLyB3ZSB3YW50IHRvIGRvIGlmICphbnkqIG9mIHRoZSByZXNwb25zZXMgYXJlbid0IHNhZmUgdG8gY2FjaGUuXG4gICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYmFkLXByZWNhY2hpbmctcmVzcG9uc2UnLCB7XG4gICAgICAgICAgICB1cmw6IHJlcXVlc3QudXJsLFxuICAgICAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFRoaXMgbWV0aG9kIGlzIGNvbXBsZXgsIGFzIHRoZXJlIGEgbnVtYmVyIG9mIHRoaW5ncyB0byBhY2NvdW50IGZvcjpcbiAgICAgICAqXG4gICAgICAgKiBUaGUgYHBsdWdpbnNgIGFycmF5IGNhbiBiZSBzZXQgYXQgY29uc3RydWN0aW9uLCBhbmQvb3IgaXQgbWlnaHQgYmUgYWRkZWQgdG9cbiAgICAgICAqIHRvIGF0IGFueSB0aW1lIGJlZm9yZSB0aGUgc3RyYXRlZ3kgaXMgdXNlZC5cbiAgICAgICAqXG4gICAgICAgKiBBdCB0aGUgdGltZSB0aGUgc3RyYXRlZ3kgaXMgdXNlZCAoaS5lLiBkdXJpbmcgYW4gYGluc3RhbGxgIGV2ZW50KSwgdGhlcmVcbiAgICAgICAqIG5lZWRzIHRvIGJlIGF0IGxlYXN0IG9uZSBwbHVnaW4gdGhhdCBpbXBsZW1lbnRzIGBjYWNoZVdpbGxVcGRhdGVgIGluIHRoZVxuICAgICAgICogYXJyYXksIG90aGVyIHRoYW4gYGNvcHlSZWRpcmVjdGVkQ2FjaGVhYmxlUmVzcG9uc2VzUGx1Z2luYC5cbiAgICAgICAqXG4gICAgICAgKiAtIElmIHRoaXMgbWV0aG9kIGlzIGNhbGxlZCBhbmQgdGhlcmUgYXJlIG5vIHN1aXRhYmxlIGBjYWNoZVdpbGxVcGRhdGVgXG4gICAgICAgKiBwbHVnaW5zLCB3ZSBuZWVkIHRvIGFkZCBgZGVmYXVsdFByZWNhY2hlQ2FjaGVhYmlsaXR5UGx1Z2luYC5cbiAgICAgICAqXG4gICAgICAgKiAtIElmIHRoaXMgbWV0aG9kIGlzIGNhbGxlZCBhbmQgdGhlcmUgaXMgZXhhY3RseSBvbmUgYGNhY2hlV2lsbFVwZGF0ZWAsIHRoZW5cbiAgICAgICAqIHdlIGRvbid0IGhhdmUgdG8gZG8gYW55dGhpbmcgKHRoaXMgbWlnaHQgYmUgYSBwcmV2aW91c2x5IGFkZGVkXG4gICAgICAgKiBgZGVmYXVsdFByZWNhY2hlQ2FjaGVhYmlsaXR5UGx1Z2luYCwgb3IgaXQgbWlnaHQgYmUgYSBjdXN0b20gcGx1Z2luKS5cbiAgICAgICAqXG4gICAgICAgKiAtIElmIHRoaXMgbWV0aG9kIGlzIGNhbGxlZCBhbmQgdGhlcmUgaXMgbW9yZSB0aGFuIG9uZSBgY2FjaGVXaWxsVXBkYXRlYCxcbiAgICAgICAqIHRoZW4gd2UgbmVlZCB0byBjaGVjayBpZiBvbmUgaXMgYGRlZmF1bHRQcmVjYWNoZUNhY2hlYWJpbGl0eVBsdWdpbmAuIElmIHNvLFxuICAgICAgICogd2UgbmVlZCB0byByZW1vdmUgaXQuIChUaGlzIHNpdHVhdGlvbiBpcyB1bmxpa2VseSwgYnV0IGl0IGNvdWxkIGhhcHBlbiBpZlxuICAgICAgICogdGhlIHN0cmF0ZWd5IGlzIHVzZWQgbXVsdGlwbGUgdGltZXMsIHRoZSBmaXJzdCB3aXRob3V0IGEgYGNhY2hlV2lsbFVwZGF0ZWAsXG4gICAgICAgKiBhbmQgdGhlbiBsYXRlciBvbiBhZnRlciBtYW51YWxseSBhZGRpbmcgYSBjdXN0b20gYGNhY2hlV2lsbFVwZGF0ZWAuKVxuICAgICAgICpcbiAgICAgICAqIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzI3MzcgZm9yIG1vcmUgY29udGV4dC5cbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBfdXNlRGVmYXVsdENhY2hlYWJpbGl0eVBsdWdpbklmTmVlZGVkKCkge1xuICAgICAgICBsZXQgZGVmYXVsdFBsdWdpbkluZGV4ID0gbnVsbDtcbiAgICAgICAgbGV0IGNhY2hlV2lsbFVwZGF0ZVBsdWdpbkNvdW50ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCBbaW5kZXgsIHBsdWdpbl0gb2YgdGhpcy5wbHVnaW5zLmVudHJpZXMoKSkge1xuICAgICAgICAgIC8vIElnbm9yZSB0aGUgY29weSByZWRpcmVjdGVkIHBsdWdpbiB3aGVuIGRldGVybWluaW5nIHdoYXQgdG8gZG8uXG4gICAgICAgICAgaWYgKHBsdWdpbiA9PT0gUHJlY2FjaGVTdHJhdGVneS5jb3B5UmVkaXJlY3RlZENhY2hlYWJsZVJlc3BvbnNlc1BsdWdpbikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIFNhdmUgdGhlIGRlZmF1bHQgcGx1Z2luJ3MgaW5kZXgsIGluIGNhc2UgaXQgbmVlZHMgdG8gYmUgcmVtb3ZlZC5cbiAgICAgICAgICBpZiAocGx1Z2luID09PSBQcmVjYWNoZVN0cmF0ZWd5LmRlZmF1bHRQcmVjYWNoZUNhY2hlYWJpbGl0eVBsdWdpbikge1xuICAgICAgICAgICAgZGVmYXVsdFBsdWdpbkluZGV4ID0gaW5kZXg7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChwbHVnaW4uY2FjaGVXaWxsVXBkYXRlKSB7XG4gICAgICAgICAgICBjYWNoZVdpbGxVcGRhdGVQbHVnaW5Db3VudCsrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoY2FjaGVXaWxsVXBkYXRlUGx1Z2luQ291bnQgPT09IDApIHtcbiAgICAgICAgICB0aGlzLnBsdWdpbnMucHVzaChQcmVjYWNoZVN0cmF0ZWd5LmRlZmF1bHRQcmVjYWNoZUNhY2hlYWJpbGl0eVBsdWdpbik7XG4gICAgICAgIH0gZWxzZSBpZiAoY2FjaGVXaWxsVXBkYXRlUGx1Z2luQ291bnQgPiAxICYmIGRlZmF1bHRQbHVnaW5JbmRleCAhPT0gbnVsbCkge1xuICAgICAgICAgIC8vIE9ubHkgcmVtb3ZlIHRoZSBkZWZhdWx0IHBsdWdpbjsgbXVsdGlwbGUgY3VzdG9tIHBsdWdpbnMgYXJlIGFsbG93ZWQuXG4gICAgICAgICAgdGhpcy5wbHVnaW5zLnNwbGljZShkZWZhdWx0UGx1Z2luSW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICAgIC8vIE5vdGhpbmcgbmVlZHMgdG8gYmUgZG9uZSBpZiBjYWNoZVdpbGxVcGRhdGVQbHVnaW5Db3VudCBpcyAxXG4gICAgICB9XG4gICAgfVxuICAgIFByZWNhY2hlU3RyYXRlZ3kuZGVmYXVsdFByZWNhY2hlQ2FjaGVhYmlsaXR5UGx1Z2luID0ge1xuICAgICAgYXN5bmMgY2FjaGVXaWxsVXBkYXRlKHtcbiAgICAgICAgcmVzcG9uc2VcbiAgICAgIH0pIHtcbiAgICAgICAgaWYgKCFyZXNwb25zZSB8fCByZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH07XG4gICAgUHJlY2FjaGVTdHJhdGVneS5jb3B5UmVkaXJlY3RlZENhY2hlYWJsZVJlc3BvbnNlc1BsdWdpbiA9IHtcbiAgICAgIGFzeW5jIGNhY2hlV2lsbFVwZGF0ZSh7XG4gICAgICAgIHJlc3BvbnNlXG4gICAgICB9KSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5yZWRpcmVjdGVkID8gYXdhaXQgY29weVJlc3BvbnNlKHJlc3BvbnNlKSA6IHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBQZXJmb3JtcyBlZmZpY2llbnQgcHJlY2FjaGluZyBvZiBhc3NldHMuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgY2xhc3MgUHJlY2FjaGVDb250cm9sbGVyIHtcbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlIGEgbmV3IFByZWNhY2hlQ29udHJvbGxlci5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdGlvbnMuY2FjaGVOYW1lXSBUaGUgY2FjaGUgdG8gdXNlIGZvciBwcmVjYWNoaW5nLlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLnBsdWdpbnNdIFBsdWdpbnMgdG8gdXNlIHdoZW4gcHJlY2FjaGluZyBhcyB3ZWxsXG4gICAgICAgKiBhcyByZXNwb25kaW5nIHRvIGZldGNoIGV2ZW50cyBmb3IgcHJlY2FjaGVkIGFzc2V0cy5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gW29wdGlvbnMuZmFsbGJhY2tUb05ldHdvcms9dHJ1ZV0gV2hldGhlciB0byBhdHRlbXB0IHRvXG4gICAgICAgKiBnZXQgdGhlIHJlc3BvbnNlIGZyb20gdGhlIG5ldHdvcmsgaWYgdGhlcmUncyBhIHByZWNhY2hlIG1pc3MuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKHtcbiAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICBwbHVnaW5zID0gW10sXG4gICAgICAgIGZhbGxiYWNrVG9OZXR3b3JrID0gdHJ1ZVxuICAgICAgfSA9IHt9KSB7XG4gICAgICAgIHRoaXMuX3VybHNUb0NhY2hlS2V5cyA9IG5ldyBNYXAoKTtcbiAgICAgICAgdGhpcy5fdXJsc1RvQ2FjaGVNb2RlcyA9IG5ldyBNYXAoKTtcbiAgICAgICAgdGhpcy5fY2FjaGVLZXlzVG9JbnRlZ3JpdGllcyA9IG5ldyBNYXAoKTtcbiAgICAgICAgdGhpcy5fc3RyYXRlZ3kgPSBuZXcgUHJlY2FjaGVTdHJhdGVneSh7XG4gICAgICAgICAgY2FjaGVOYW1lOiBjYWNoZU5hbWVzLmdldFByZWNhY2hlTmFtZShjYWNoZU5hbWUpLFxuICAgICAgICAgIHBsdWdpbnM6IFsuLi5wbHVnaW5zLCBuZXcgUHJlY2FjaGVDYWNoZUtleVBsdWdpbih7XG4gICAgICAgICAgICBwcmVjYWNoZUNvbnRyb2xsZXI6IHRoaXNcbiAgICAgICAgICB9KV0sXG4gICAgICAgICAgZmFsbGJhY2tUb05ldHdvcmtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIEJpbmQgdGhlIGluc3RhbGwgYW5kIGFjdGl2YXRlIG1ldGhvZHMgdG8gdGhlIGluc3RhbmNlLlxuICAgICAgICB0aGlzLmluc3RhbGwgPSB0aGlzLmluc3RhbGwuYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy5hY3RpdmF0ZSA9IHRoaXMuYWN0aXZhdGUuYmluZCh0aGlzKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHR5cGUge3dvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZVN0cmF0ZWd5fSBUaGUgc3RyYXRlZ3kgY3JlYXRlZCBieSB0aGlzIGNvbnRyb2xsZXIgYW5kXG4gICAgICAgKiB1c2VkIHRvIGNhY2hlIGFzc2V0cyBhbmQgcmVzcG9uZCB0byBmZXRjaCBldmVudHMuXG4gICAgICAgKi9cbiAgICAgIGdldCBzdHJhdGVneSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3N0cmF0ZWd5O1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBZGRzIGl0ZW1zIHRvIHRoZSBwcmVjYWNoZSBsaXN0LCByZW1vdmluZyBhbnkgZHVwbGljYXRlcyBhbmRcbiAgICAgICAqIHN0b3JlcyB0aGUgZmlsZXMgaW4gdGhlXG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1jb3JlLmNhY2hlTmFtZXN8XCJwcmVjYWNoZSBjYWNoZVwifSB3aGVuIHRoZSBzZXJ2aWNlXG4gICAgICAgKiB3b3JrZXIgaW5zdGFsbHMuXG4gICAgICAgKlxuICAgICAgICogVGhpcyBtZXRob2QgY2FuIGJlIGNhbGxlZCBtdWx0aXBsZSB0aW1lcy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdHxzdHJpbmc+fSBbZW50cmllcz1bXV0gQXJyYXkgb2YgZW50cmllcyB0byBwcmVjYWNoZS5cbiAgICAgICAqL1xuICAgICAgcHJlY2FjaGUoZW50cmllcykge1xuICAgICAgICB0aGlzLmFkZFRvQ2FjaGVMaXN0KGVudHJpZXMpO1xuICAgICAgICBpZiAoIXRoaXMuX2luc3RhbGxBbmRBY3RpdmVMaXN0ZW5lcnNBZGRlZCkge1xuICAgICAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignaW5zdGFsbCcsIHRoaXMuaW5zdGFsbCk7XG4gICAgICAgICAgc2VsZi5hZGRFdmVudExpc3RlbmVyKCdhY3RpdmF0ZScsIHRoaXMuYWN0aXZhdGUpO1xuICAgICAgICAgIHRoaXMuX2luc3RhbGxBbmRBY3RpdmVMaXN0ZW5lcnNBZGRlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBtZXRob2Qgd2lsbCBhZGQgaXRlbXMgdG8gdGhlIHByZWNhY2hlIGxpc3QsIHJlbW92aW5nIGR1cGxpY2F0ZXNcbiAgICAgICAqIGFuZCBlbnN1cmluZyB0aGUgaW5mb3JtYXRpb24gaXMgdmFsaWQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtBcnJheTx3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyLlByZWNhY2hlRW50cnl8c3RyaW5nPn0gZW50cmllc1xuICAgICAgICogICAgIEFycmF5IG9mIGVudHJpZXMgdG8gcHJlY2FjaGUuXG4gICAgICAgKi9cbiAgICAgIGFkZFRvQ2FjaGVMaXN0KGVudHJpZXMpIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0FycmF5KGVudHJpZXMsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXByZWNhY2hpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUHJlY2FjaGVDb250cm9sbGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnYWRkVG9DYWNoZUxpc3QnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnZW50cmllcydcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cmxzVG9XYXJuQWJvdXQgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBlbnRyaWVzKSB7XG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjI1OVxuICAgICAgICAgIGlmICh0eXBlb2YgZW50cnkgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICB1cmxzVG9XYXJuQWJvdXQucHVzaChlbnRyeSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChlbnRyeSAmJiBlbnRyeS5yZXZpc2lvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB1cmxzVG9XYXJuQWJvdXQucHVzaChlbnRyeS51cmwpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICBjYWNoZUtleSxcbiAgICAgICAgICAgIHVybFxuICAgICAgICAgIH0gPSBjcmVhdGVDYWNoZUtleShlbnRyeSk7XG4gICAgICAgICAgY29uc3QgY2FjaGVNb2RlID0gdHlwZW9mIGVudHJ5ICE9PSAnc3RyaW5nJyAmJiBlbnRyeS5yZXZpc2lvbiA/ICdyZWxvYWQnIDogJ2RlZmF1bHQnO1xuICAgICAgICAgIGlmICh0aGlzLl91cmxzVG9DYWNoZUtleXMuaGFzKHVybCkgJiYgdGhpcy5fdXJsc1RvQ2FjaGVLZXlzLmdldCh1cmwpICE9PSBjYWNoZUtleSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYWRkLXRvLWNhY2hlLWxpc3QtY29uZmxpY3RpbmctZW50cmllcycsIHtcbiAgICAgICAgICAgICAgZmlyc3RFbnRyeTogdGhpcy5fdXJsc1RvQ2FjaGVLZXlzLmdldCh1cmwpLFxuICAgICAgICAgICAgICBzZWNvbmRFbnRyeTogY2FjaGVLZXlcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodHlwZW9mIGVudHJ5ICE9PSAnc3RyaW5nJyAmJiBlbnRyeS5pbnRlZ3JpdHkpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLl9jYWNoZUtleXNUb0ludGVncml0aWVzLmhhcyhjYWNoZUtleSkgJiYgdGhpcy5fY2FjaGVLZXlzVG9JbnRlZ3JpdGllcy5nZXQoY2FjaGVLZXkpICE9PSBlbnRyeS5pbnRlZ3JpdHkpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYWRkLXRvLWNhY2hlLWxpc3QtY29uZmxpY3RpbmctaW50ZWdyaXRpZXMnLCB7XG4gICAgICAgICAgICAgICAgdXJsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5fY2FjaGVLZXlzVG9JbnRlZ3JpdGllcy5zZXQoY2FjaGVLZXksIGVudHJ5LmludGVncml0eSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuX3VybHNUb0NhY2hlS2V5cy5zZXQodXJsLCBjYWNoZUtleSk7XG4gICAgICAgICAgdGhpcy5fdXJsc1RvQ2FjaGVNb2Rlcy5zZXQodXJsLCBjYWNoZU1vZGUpO1xuICAgICAgICAgIGlmICh1cmxzVG9XYXJuQWJvdXQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29uc3Qgd2FybmluZ01lc3NhZ2UgPSBgV29ya2JveCBpcyBwcmVjYWNoaW5nIFVSTHMgd2l0aG91dCByZXZpc2lvbiBgICsgYGluZm86ICR7dXJsc1RvV2FybkFib3V0LmpvaW4oJywgJyl9XFxuVGhpcyBpcyBnZW5lcmFsbHkgTk9UIHNhZmUuIGAgKyBgTGVhcm4gbW9yZSBhdCBodHRwczovL2JpdC5seS93Yi1wcmVjYWNoZWA7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxvZ2dlci53YXJuKHdhcm5pbmdNZXNzYWdlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUHJlY2FjaGVzIG5ldyBhbmQgdXBkYXRlZCBhc3NldHMuIENhbGwgdGhpcyBtZXRob2QgZnJvbSB0aGUgc2VydmljZSB3b3JrZXJcbiAgICAgICAqIGluc3RhbGwgZXZlbnQuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogdGhpcyBtZXRob2QgY2FsbHMgYGV2ZW50LndhaXRVbnRpbCgpYCBmb3IgeW91LCBzbyB5b3UgZG8gbm90IG5lZWRcbiAgICAgICAqIHRvIGNhbGwgaXQgeW91cnNlbGYgaW4geW91ciBldmVudCBoYW5kbGVycy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0V4dGVuZGFibGVFdmVudH0gZXZlbnRcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8d29ya2JveC1wcmVjYWNoaW5nLkluc3RhbGxSZXN1bHQ+fVxuICAgICAgICovXG4gICAgICBpbnN0YWxsKGV2ZW50KSB7XG4gICAgICAgIC8vIHdhaXRVbnRpbCByZXR1cm5zIFByb21pc2U8YW55PlxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1yZXR1cm5cbiAgICAgICAgcmV0dXJuIHdhaXRVbnRpbChldmVudCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGluc3RhbGxSZXBvcnRQbHVnaW4gPSBuZXcgUHJlY2FjaGVJbnN0YWxsUmVwb3J0UGx1Z2luKCk7XG4gICAgICAgICAgdGhpcy5zdHJhdGVneS5wbHVnaW5zLnB1c2goaW5zdGFsbFJlcG9ydFBsdWdpbik7XG4gICAgICAgICAgLy8gQ2FjaGUgZW50cmllcyBvbmUgYXQgYSB0aW1lLlxuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzI1MjhcbiAgICAgICAgICBmb3IgKGNvbnN0IFt1cmwsIGNhY2hlS2V5XSBvZiB0aGlzLl91cmxzVG9DYWNoZUtleXMpIHtcbiAgICAgICAgICAgIGNvbnN0IGludGVncml0eSA9IHRoaXMuX2NhY2hlS2V5c1RvSW50ZWdyaXRpZXMuZ2V0KGNhY2hlS2V5KTtcbiAgICAgICAgICAgIGNvbnN0IGNhY2hlTW9kZSA9IHRoaXMuX3VybHNUb0NhY2hlTW9kZXMuZ2V0KHVybCk7XG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0ID0gbmV3IFJlcXVlc3QodXJsLCB7XG4gICAgICAgICAgICAgIGludGVncml0eSxcbiAgICAgICAgICAgICAgY2FjaGU6IGNhY2hlTW9kZSxcbiAgICAgICAgICAgICAgY3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbidcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwodGhpcy5zdHJhdGVneS5oYW5kbGVBbGwoe1xuICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICBjYWNoZUtleVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgICBldmVudFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICB1cGRhdGVkVVJMcyxcbiAgICAgICAgICAgIG5vdFVwZGF0ZWRVUkxzXG4gICAgICAgICAgfSA9IGluc3RhbGxSZXBvcnRQbHVnaW47XG4gICAgICAgICAge1xuICAgICAgICAgICAgcHJpbnRJbnN0YWxsRGV0YWlscyh1cGRhdGVkVVJMcywgbm90VXBkYXRlZFVSTHMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdXBkYXRlZFVSTHMsXG4gICAgICAgICAgICBub3RVcGRhdGVkVVJMc1xuICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBEZWxldGVzIGFzc2V0cyB0aGF0IGFyZSBubyBsb25nZXIgcHJlc2VudCBpbiB0aGUgY3VycmVudCBwcmVjYWNoZSBtYW5pZmVzdC5cbiAgICAgICAqIENhbGwgdGhpcyBtZXRob2QgZnJvbSB0aGUgc2VydmljZSB3b3JrZXIgYWN0aXZhdGUgZXZlbnQuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogdGhpcyBtZXRob2QgY2FsbHMgYGV2ZW50LndhaXRVbnRpbCgpYCBmb3IgeW91LCBzbyB5b3UgZG8gbm90IG5lZWRcbiAgICAgICAqIHRvIGNhbGwgaXQgeW91cnNlbGYgaW4geW91ciBldmVudCBoYW5kbGVycy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0V4dGVuZGFibGVFdmVudH0gZXZlbnRcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8d29ya2JveC1wcmVjYWNoaW5nLkNsZWFudXBSZXN1bHQ+fVxuICAgICAgICovXG4gICAgICBhY3RpdmF0ZShldmVudCkge1xuICAgICAgICAvLyB3YWl0VW50aWwgcmV0dXJucyBQcm9taXNlPGFueT5cbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtcmV0dXJuXG4gICAgICAgIHJldHVybiB3YWl0VW50aWwoZXZlbnQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBjYWNoZSA9IGF3YWl0IHNlbGYuY2FjaGVzLm9wZW4odGhpcy5zdHJhdGVneS5jYWNoZU5hbWUpO1xuICAgICAgICAgIGNvbnN0IGN1cnJlbnRseUNhY2hlZFJlcXVlc3RzID0gYXdhaXQgY2FjaGUua2V5cygpO1xuICAgICAgICAgIGNvbnN0IGV4cGVjdGVkQ2FjaGVLZXlzID0gbmV3IFNldCh0aGlzLl91cmxzVG9DYWNoZUtleXMudmFsdWVzKCkpO1xuICAgICAgICAgIGNvbnN0IGRlbGV0ZWRVUkxzID0gW107XG4gICAgICAgICAgZm9yIChjb25zdCByZXF1ZXN0IG9mIGN1cnJlbnRseUNhY2hlZFJlcXVlc3RzKSB7XG4gICAgICAgICAgICBpZiAoIWV4cGVjdGVkQ2FjaGVLZXlzLmhhcyhyZXF1ZXN0LnVybCkpIHtcbiAgICAgICAgICAgICAgYXdhaXQgY2FjaGUuZGVsZXRlKHJlcXVlc3QpO1xuICAgICAgICAgICAgICBkZWxldGVkVVJMcy5wdXNoKHJlcXVlc3QudXJsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAge1xuICAgICAgICAgICAgcHJpbnRDbGVhbnVwRGV0YWlscyhkZWxldGVkVVJMcyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkZWxldGVkVVJMc1xuICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIGEgbWFwcGluZyBvZiBhIHByZWNhY2hlZCBVUkwgdG8gdGhlIGNvcnJlc3BvbmRpbmcgY2FjaGUga2V5LCB0YWtpbmdcbiAgICAgICAqIGludG8gYWNjb3VudCB0aGUgcmV2aXNpb24gaW5mb3JtYXRpb24gZm9yIHRoZSBVUkwuXG4gICAgICAgKlxuICAgICAgICogQHJldHVybiB7TWFwPHN0cmluZywgc3RyaW5nPn0gQSBVUkwgdG8gY2FjaGUga2V5IG1hcHBpbmcuXG4gICAgICAgKi9cbiAgICAgIGdldFVSTHNUb0NhY2hlS2V5cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3VybHNUb0NhY2hlS2V5cztcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyBhIGxpc3Qgb2YgYWxsIHRoZSBVUkxzIHRoYXQgaGF2ZSBiZWVuIHByZWNhY2hlZCBieSB0aGUgY3VycmVudFxuICAgICAgICogc2VydmljZSB3b3JrZXIuXG4gICAgICAgKlxuICAgICAgICogQHJldHVybiB7QXJyYXk8c3RyaW5nPn0gVGhlIHByZWNhY2hlZCBVUkxzLlxuICAgICAgICovXG4gICAgICBnZXRDYWNoZWRVUkxzKCkge1xuICAgICAgICByZXR1cm4gWy4uLnRoaXMuX3VybHNUb0NhY2hlS2V5cy5rZXlzKCldO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIHRoZSBjYWNoZSBrZXkgdXNlZCBmb3Igc3RvcmluZyBhIGdpdmVuIFVSTC4gSWYgdGhhdCBVUkwgaXNcbiAgICAgICAqIHVudmVyc2lvbmVkLCBsaWtlIGAvaW5kZXguaHRtbCcsIHRoZW4gdGhlIGNhY2hlIGtleSB3aWxsIGJlIHRoZSBvcmlnaW5hbFxuICAgICAgICogVVJMIHdpdGggYSBzZWFyY2ggcGFyYW1ldGVyIGFwcGVuZGVkIHRvIGl0LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgQSBVUkwgd2hvc2UgY2FjaGUga2V5IHlvdSB3YW50IHRvIGxvb2sgdXAuXG4gICAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSB2ZXJzaW9uZWQgVVJMIHRoYXQgY29ycmVzcG9uZHMgdG8gYSBjYWNoZSBrZXlcbiAgICAgICAqIGZvciB0aGUgb3JpZ2luYWwgVVJMLCBvciB1bmRlZmluZWQgaWYgdGhhdCBVUkwgaXNuJ3QgcHJlY2FjaGVkLlxuICAgICAgICovXG4gICAgICBnZXRDYWNoZUtleUZvclVSTCh1cmwpIHtcbiAgICAgICAgY29uc3QgdXJsT2JqZWN0ID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgICByZXR1cm4gdGhpcy5fdXJsc1RvQ2FjaGVLZXlzLmdldCh1cmxPYmplY3QuaHJlZik7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgQSBjYWNoZSBrZXkgd2hvc2UgU1JJIHlvdSB3YW50IHRvIGxvb2sgdXAuXG4gICAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSBzdWJyZXNvdXJjZSBpbnRlZ3JpdHkgYXNzb2NpYXRlZCB3aXRoIHRoZSBjYWNoZSBrZXksXG4gICAgICAgKiBvciB1bmRlZmluZWQgaWYgaXQncyBub3Qgc2V0LlxuICAgICAgICovXG4gICAgICBnZXRJbnRlZ3JpdHlGb3JDYWNoZUtleShjYWNoZUtleSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVLZXlzVG9JbnRlZ3JpdGllcy5nZXQoY2FjaGVLZXkpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBUaGlzIGFjdHMgYXMgYSBkcm9wLWluIHJlcGxhY2VtZW50IGZvclxuICAgICAgICogW2BjYWNoZS5tYXRjaCgpYF0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0NhY2hlL21hdGNoKVxuICAgICAgICogd2l0aCB0aGUgZm9sbG93aW5nIGRpZmZlcmVuY2VzOlxuICAgICAgICpcbiAgICAgICAqIC0gSXQga25vd3Mgd2hhdCB0aGUgbmFtZSBvZiB0aGUgcHJlY2FjaGUgaXMsIGFuZCBvbmx5IGNoZWNrcyBpbiB0aGF0IGNhY2hlLlxuICAgICAgICogLSBJdCBhbGxvd3MgeW91IHRvIHBhc3MgaW4gYW4gXCJvcmlnaW5hbFwiIFVSTCB3aXRob3V0IHZlcnNpb25pbmcgcGFyYW1ldGVycyxcbiAgICAgICAqIGFuZCBpdCB3aWxsIGF1dG9tYXRpY2FsbHkgbG9vayB1cCB0aGUgY29ycmVjdCBjYWNoZSBrZXkgZm9yIHRoZSBjdXJyZW50bHlcbiAgICAgICAqIGFjdGl2ZSByZXZpc2lvbiBvZiB0aGF0IFVSTC5cbiAgICAgICAqXG4gICAgICAgKiBFLmcuLCBgbWF0Y2hQcmVjYWNoZSgnaW5kZXguaHRtbCcpYCB3aWxsIGZpbmQgdGhlIGNvcnJlY3QgcHJlY2FjaGVkXG4gICAgICAgKiByZXNwb25zZSBmb3IgdGhlIGN1cnJlbnRseSBhY3RpdmUgc2VydmljZSB3b3JrZXIsIGV2ZW4gaWYgdGhlIGFjdHVhbCBjYWNoZVxuICAgICAgICoga2V5IGlzIGAnL2luZGV4Lmh0bWw/X19XQl9SRVZJU0lPTl9fPTEyMzRhYmNkJ2AuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd8UmVxdWVzdH0gcmVxdWVzdCBUaGUga2V5ICh3aXRob3V0IHJldmlzaW9uaW5nIHBhcmFtZXRlcnMpXG4gICAgICAgKiB0byBsb29rIHVwIGluIHRoZSBwcmVjYWNoZS5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2V8dW5kZWZpbmVkPn1cbiAgICAgICAqL1xuICAgICAgYXN5bmMgbWF0Y2hQcmVjYWNoZShyZXF1ZXN0KSB7XG4gICAgICAgIGNvbnN0IHVybCA9IHJlcXVlc3QgaW5zdGFuY2VvZiBSZXF1ZXN0ID8gcmVxdWVzdC51cmwgOiByZXF1ZXN0O1xuICAgICAgICBjb25zdCBjYWNoZUtleSA9IHRoaXMuZ2V0Q2FjaGVLZXlGb3JVUkwodXJsKTtcbiAgICAgICAgaWYgKGNhY2hlS2V5KSB7XG4gICAgICAgICAgY29uc3QgY2FjaGUgPSBhd2FpdCBzZWxmLmNhY2hlcy5vcGVuKHRoaXMuc3RyYXRlZ3kuY2FjaGVOYW1lKTtcbiAgICAgICAgICByZXR1cm4gY2FjaGUubWF0Y2goY2FjaGVLZXkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgYSBmdW5jdGlvbiB0aGF0IGxvb2tzIHVwIGB1cmxgIGluIHRoZSBwcmVjYWNoZSAodGFraW5nIGludG9cbiAgICAgICAqIGFjY291bnQgcmV2aXNpb24gaW5mb3JtYXRpb24pLCBhbmQgcmV0dXJucyB0aGUgY29ycmVzcG9uZGluZyBgUmVzcG9uc2VgLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgVGhlIHByZWNhY2hlZCBVUkwgd2hpY2ggd2lsbCBiZSB1c2VkIHRvIGxvb2t1cCB0aGVcbiAgICAgICAqIGBSZXNwb25zZWAuXG4gICAgICAgKiBAcmV0dXJuIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfVxuICAgICAgICovXG4gICAgICBjcmVhdGVIYW5kbGVyQm91bmRUb1VSTCh1cmwpIHtcbiAgICAgICAgY29uc3QgY2FjaGVLZXkgPSB0aGlzLmdldENhY2hlS2V5Rm9yVVJMKHVybCk7XG4gICAgICAgIGlmICghY2FjaGVLZXkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdub24tcHJlY2FjaGVkLXVybCcsIHtcbiAgICAgICAgICAgIHVybFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvcHRpb25zID0+IHtcbiAgICAgICAgICBvcHRpb25zLnJlcXVlc3QgPSBuZXcgUmVxdWVzdCh1cmwpO1xuICAgICAgICAgIG9wdGlvbnMucGFyYW1zID0gT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICBjYWNoZUtleVxuICAgICAgICAgIH0sIG9wdGlvbnMucGFyYW1zKTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5zdHJhdGVneS5oYW5kbGUob3B0aW9ucyk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgbGV0IHByZWNhY2hlQ29udHJvbGxlcjtcbiAgICAvKipcbiAgICAgKiBAcmV0dXJuIHtQcmVjYWNoZUNvbnRyb2xsZXJ9XG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjb25zdCBnZXRPckNyZWF0ZVByZWNhY2hlQ29udHJvbGxlciA9ICgpID0+IHtcbiAgICAgIGlmICghcHJlY2FjaGVDb250cm9sbGVyKSB7XG4gICAgICAgIHByZWNhY2hlQ29udHJvbGxlciA9IG5ldyBQcmVjYWNoZUNvbnRyb2xsZXIoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBwcmVjYWNoZUNvbnRyb2xsZXI7XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFJlbW92ZXMgYW55IFVSTCBzZWFyY2ggcGFyYW1ldGVycyB0aGF0IHNob3VsZCBiZSBpZ25vcmVkLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtVUkx9IHVybE9iamVjdCBUaGUgb3JpZ2luYWwgVVJMLlxuICAgICAqIEBwYXJhbSB7QXJyYXk8UmVnRXhwPn0gaWdub3JlVVJMUGFyYW1ldGVyc01hdGNoaW5nIFJlZ0V4cHMgdG8gdGVzdCBhZ2FpbnN0XG4gICAgICogZWFjaCBzZWFyY2ggcGFyYW1ldGVyIG5hbWUuIE1hdGNoZXMgbWVhbiB0aGF0IHRoZSBzZWFyY2ggcGFyYW1ldGVyIHNob3VsZCBiZVxuICAgICAqIGlnbm9yZWQuXG4gICAgICogQHJldHVybiB7VVJMfSBUaGUgVVJMIHdpdGggYW55IGlnbm9yZWQgc2VhcmNoIHBhcmFtZXRlcnMgcmVtb3ZlZC5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIHJlbW92ZUlnbm9yZWRTZWFyY2hQYXJhbXModXJsT2JqZWN0LCBpZ25vcmVVUkxQYXJhbWV0ZXJzTWF0Y2hpbmcgPSBbXSkge1xuICAgICAgLy8gQ29udmVydCB0aGUgaXRlcmFibGUgaW50byBhbiBhcnJheSBhdCB0aGUgc3RhcnQgb2YgdGhlIGxvb3AgdG8gbWFrZSBzdXJlXG4gICAgICAvLyBkZWxldGlvbiBkb2Vzbid0IG1lc3MgdXAgaXRlcmF0aW9uLlxuICAgICAgZm9yIChjb25zdCBwYXJhbU5hbWUgb2YgWy4uLnVybE9iamVjdC5zZWFyY2hQYXJhbXMua2V5cygpXSkge1xuICAgICAgICBpZiAoaWdub3JlVVJMUGFyYW1ldGVyc01hdGNoaW5nLnNvbWUocmVnRXhwID0+IHJlZ0V4cC50ZXN0KHBhcmFtTmFtZSkpKSB7XG4gICAgICAgICAgdXJsT2JqZWN0LnNlYXJjaFBhcmFtcy5kZWxldGUocGFyYW1OYW1lKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHVybE9iamVjdDtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBHZW5lcmF0b3IgZnVuY3Rpb24gdGhhdCB5aWVsZHMgcG9zc2libGUgdmFyaWF0aW9ucyBvbiB0aGUgb3JpZ2luYWwgVVJMIHRvXG4gICAgICogY2hlY2ssIG9uZSBhdCBhIHRpbWUuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uKiBnZW5lcmF0ZVVSTFZhcmlhdGlvbnModXJsLCB7XG4gICAgICBpZ25vcmVVUkxQYXJhbWV0ZXJzTWF0Y2hpbmcgPSBbL151dG1fLywgL15mYmNsaWQkL10sXG4gICAgICBkaXJlY3RvcnlJbmRleCA9ICdpbmRleC5odG1sJyxcbiAgICAgIGNsZWFuVVJMcyA9IHRydWUsXG4gICAgICB1cmxNYW5pcHVsYXRpb25cbiAgICB9ID0ge30pIHtcbiAgICAgIGNvbnN0IHVybE9iamVjdCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIHVybE9iamVjdC5oYXNoID0gJyc7XG4gICAgICB5aWVsZCB1cmxPYmplY3QuaHJlZjtcbiAgICAgIGNvbnN0IHVybFdpdGhvdXRJZ25vcmVkUGFyYW1zID0gcmVtb3ZlSWdub3JlZFNlYXJjaFBhcmFtcyh1cmxPYmplY3QsIGlnbm9yZVVSTFBhcmFtZXRlcnNNYXRjaGluZyk7XG4gICAgICB5aWVsZCB1cmxXaXRob3V0SWdub3JlZFBhcmFtcy5ocmVmO1xuICAgICAgaWYgKGRpcmVjdG9yeUluZGV4ICYmIHVybFdpdGhvdXRJZ25vcmVkUGFyYW1zLnBhdGhuYW1lLmVuZHNXaXRoKCcvJykpIHtcbiAgICAgICAgY29uc3QgZGlyZWN0b3J5VVJMID0gbmV3IFVSTCh1cmxXaXRob3V0SWdub3JlZFBhcmFtcy5ocmVmKTtcbiAgICAgICAgZGlyZWN0b3J5VVJMLnBhdGhuYW1lICs9IGRpcmVjdG9yeUluZGV4O1xuICAgICAgICB5aWVsZCBkaXJlY3RvcnlVUkwuaHJlZjtcbiAgICAgIH1cbiAgICAgIGlmIChjbGVhblVSTHMpIHtcbiAgICAgICAgY29uc3QgY2xlYW5VUkwgPSBuZXcgVVJMKHVybFdpdGhvdXRJZ25vcmVkUGFyYW1zLmhyZWYpO1xuICAgICAgICBjbGVhblVSTC5wYXRobmFtZSArPSAnLmh0bWwnO1xuICAgICAgICB5aWVsZCBjbGVhblVSTC5ocmVmO1xuICAgICAgfVxuICAgICAgaWYgKHVybE1hbmlwdWxhdGlvbikge1xuICAgICAgICBjb25zdCBhZGRpdGlvbmFsVVJMcyA9IHVybE1hbmlwdWxhdGlvbih7XG4gICAgICAgICAgdXJsOiB1cmxPYmplY3RcbiAgICAgICAgfSk7XG4gICAgICAgIGZvciAoY29uc3QgdXJsVG9BdHRlbXB0IG9mIGFkZGl0aW9uYWxVUkxzKSB7XG4gICAgICAgICAgeWllbGQgdXJsVG9BdHRlbXB0LmhyZWY7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBIHN1YmNsYXNzIG9mIHtAbGluayB3b3JrYm94LXJvdXRpbmcuUm91dGV9IHRoYXQgdGFrZXMgYVxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyfVxuICAgICAqIGluc3RhbmNlIGFuZCB1c2VzIGl0IHRvIG1hdGNoIGluY29taW5nIHJlcXVlc3RzIGFuZCBoYW5kbGUgZmV0Y2hpbmdcbiAgICAgKiByZXNwb25zZXMgZnJvbSB0aGUgcHJlY2FjaGUuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICogQGV4dGVuZHMgd29ya2JveC1yb3V0aW5nLlJvdXRlXG4gICAgICovXG4gICAgY2xhc3MgUHJlY2FjaGVSb3V0ZSBleHRlbmRzIFJvdXRlIHtcbiAgICAgIC8qKlxuICAgICAgICogQHBhcmFtIHtQcmVjYWNoZUNvbnRyb2xsZXJ9IHByZWNhY2hlQ29udHJvbGxlciBBIGBQcmVjYWNoZUNvbnRyb2xsZXJgXG4gICAgICAgKiBpbnN0YW5jZSB1c2VkIHRvIGJvdGggbWF0Y2ggcmVxdWVzdHMgYW5kIHJlc3BvbmQgdG8gZmV0Y2ggZXZlbnRzLlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSBPcHRpb25zIHRvIGNvbnRyb2wgaG93IHJlcXVlc3RzIGFyZSBtYXRjaGVkXG4gICAgICAgKiBhZ2FpbnN0IHRoZSBsaXN0IG9mIHByZWNhY2hlZCBVUkxzLlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLmRpcmVjdG9yeUluZGV4PWluZGV4Lmh0bWxdIFRoZSBgZGlyZWN0b3J5SW5kZXhgIHdpbGxcbiAgICAgICAqIGNoZWNrIGNhY2hlIGVudHJpZXMgZm9yIGEgVVJMcyBlbmRpbmcgd2l0aCAnLycgdG8gc2VlIGlmIHRoZXJlIGlzIGEgaGl0IHdoZW5cbiAgICAgICAqIGFwcGVuZGluZyB0aGUgYGRpcmVjdG9yeUluZGV4YCB2YWx1ZS5cbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8UmVnRXhwPn0gW29wdGlvbnMuaWdub3JlVVJMUGFyYW1ldGVyc01hdGNoaW5nPVsvXnV0bV8vLCAvXmZiY2xpZCQvXV0gQW5cbiAgICAgICAqIGFycmF5IG9mIHJlZ2V4J3MgdG8gcmVtb3ZlIHNlYXJjaCBwYXJhbXMgd2hlbiBsb29raW5nIGZvciBhIGNhY2hlIG1hdGNoLlxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy5jbGVhblVSTHM9dHJ1ZV0gVGhlIGBjbGVhblVSTHNgIG9wdGlvbiB3aWxsXG4gICAgICAgKiBjaGVjayB0aGUgY2FjaGUgZm9yIHRoZSBVUkwgd2l0aCBhIGAuaHRtbGAgYWRkZWQgdG8gdGhlIGVuZCBvZiB0aGUgZW5kLlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXByZWNhY2hpbmd+dXJsTWFuaXB1bGF0aW9ufSBbb3B0aW9ucy51cmxNYW5pcHVsYXRpb25dXG4gICAgICAgKiBUaGlzIGlzIGEgZnVuY3Rpb24gdGhhdCBzaG91bGQgdGFrZSBhIFVSTCBhbmQgcmV0dXJuIGFuIGFycmF5IG9mXG4gICAgICAgKiBhbHRlcm5hdGl2ZSBVUkxzIHRoYXQgc2hvdWxkIGJlIGNoZWNrZWQgZm9yIHByZWNhY2hlIG1hdGNoZXMuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKHByZWNhY2hlQ29udHJvbGxlciwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBtYXRjaCA9ICh7XG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgY29uc3QgdXJsc1RvQ2FjaGVLZXlzID0gcHJlY2FjaGVDb250cm9sbGVyLmdldFVSTHNUb0NhY2hlS2V5cygpO1xuICAgICAgICAgIGZvciAoY29uc3QgcG9zc2libGVVUkwgb2YgZ2VuZXJhdGVVUkxWYXJpYXRpb25zKHJlcXVlc3QudXJsLCBvcHRpb25zKSkge1xuICAgICAgICAgICAgY29uc3QgY2FjaGVLZXkgPSB1cmxzVG9DYWNoZUtleXMuZ2V0KHBvc3NpYmxlVVJMKTtcbiAgICAgICAgICAgIGlmIChjYWNoZUtleSkge1xuICAgICAgICAgICAgICBjb25zdCBpbnRlZ3JpdHkgPSBwcmVjYWNoZUNvbnRyb2xsZXIuZ2V0SW50ZWdyaXR5Rm9yQ2FjaGVLZXkoY2FjaGVLZXkpO1xuICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGNhY2hlS2V5LFxuICAgICAgICAgICAgICAgIGludGVncml0eVxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYFByZWNhY2hpbmcgZGlkIG5vdCBmaW5kIGEgbWF0Y2ggZm9yIGAgKyBnZXRGcmllbmRseVVSTChyZXF1ZXN0LnVybCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH07XG4gICAgICAgIHN1cGVyKG1hdGNoLCBwcmVjYWNoZUNvbnRyb2xsZXIuc3RyYXRlZ3kpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBZGQgYSBgZmV0Y2hgIGxpc3RlbmVyIHRvIHRoZSBzZXJ2aWNlIHdvcmtlciB0aGF0IHdpbGxcbiAgICAgKiByZXNwb25kIHRvXG4gICAgICogW25ldHdvcmsgcmVxdWVzdHNde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9TZXJ2aWNlX1dvcmtlcl9BUEkvVXNpbmdfU2VydmljZV9Xb3JrZXJzI0N1c3RvbV9yZXNwb25zZXNfdG9fcmVxdWVzdHN9XG4gICAgICogd2l0aCBwcmVjYWNoZWQgYXNzZXRzLlxuICAgICAqXG4gICAgICogUmVxdWVzdHMgZm9yIGFzc2V0cyB0aGF0IGFyZW4ndCBwcmVjYWNoZWQsIHRoZSBgRmV0Y2hFdmVudGAgd2lsbCBub3QgYmVcbiAgICAgKiByZXNwb25kZWQgdG8sIGFsbG93aW5nIHRoZSBldmVudCB0byBmYWxsIHRocm91Z2ggdG8gb3RoZXIgYGZldGNoYCBldmVudFxuICAgICAqIGxpc3RlbmVycy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gU2VlIHRoZSB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlUm91dGV9XG4gICAgICogb3B0aW9ucy5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBhZGRSb3V0ZShvcHRpb25zKSB7XG4gICAgICBjb25zdCBwcmVjYWNoZUNvbnRyb2xsZXIgPSBnZXRPckNyZWF0ZVByZWNhY2hlQ29udHJvbGxlcigpO1xuICAgICAgY29uc3QgcHJlY2FjaGVSb3V0ZSA9IG5ldyBQcmVjYWNoZVJvdXRlKHByZWNhY2hlQ29udHJvbGxlciwgb3B0aW9ucyk7XG4gICAgICByZWdpc3RlclJvdXRlKHByZWNhY2hlUm91dGUpO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEFkZHMgaXRlbXMgdG8gdGhlIHByZWNhY2hlIGxpc3QsIHJlbW92aW5nIGFueSBkdXBsaWNhdGVzIGFuZFxuICAgICAqIHN0b3JlcyB0aGUgZmlsZXMgaW4gdGhlXG4gICAgICoge0BsaW5rIHdvcmtib3gtY29yZS5jYWNoZU5hbWVzfFwicHJlY2FjaGUgY2FjaGVcIn0gd2hlbiB0aGUgc2VydmljZVxuICAgICAqIHdvcmtlciBpbnN0YWxscy5cbiAgICAgKlxuICAgICAqIFRoaXMgbWV0aG9kIGNhbiBiZSBjYWxsZWQgbXVsdGlwbGUgdGltZXMuXG4gICAgICpcbiAgICAgKiBQbGVhc2Ugbm90ZTogVGhpcyBtZXRob2QgKip3aWxsIG5vdCoqIHNlcnZlIGFueSBvZiB0aGUgY2FjaGVkIGZpbGVzIGZvciB5b3UuXG4gICAgICogSXQgb25seSBwcmVjYWNoZXMgZmlsZXMuIFRvIHJlc3BvbmQgdG8gYSBuZXR3b3JrIHJlcXVlc3QgeW91IGNhbGxcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLmFkZFJvdXRlfS5cbiAgICAgKlxuICAgICAqIElmIHlvdSBoYXZlIGEgc2luZ2xlIGFycmF5IG9mIGZpbGVzIHRvIHByZWNhY2hlLCB5b3UgY2FuIGp1c3QgY2FsbFxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcucHJlY2FjaGVBbmRSb3V0ZX0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdHxzdHJpbmc+fSBbZW50cmllcz1bXV0gQXJyYXkgb2YgZW50cmllcyB0byBwcmVjYWNoZS5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBwcmVjYWNoZShlbnRyaWVzKSB7XG4gICAgICBjb25zdCBwcmVjYWNoZUNvbnRyb2xsZXIgPSBnZXRPckNyZWF0ZVByZWNhY2hlQ29udHJvbGxlcigpO1xuICAgICAgcHJlY2FjaGVDb250cm9sbGVyLnByZWNhY2hlKGVudHJpZXMpO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFRoaXMgbWV0aG9kIHdpbGwgYWRkIGVudHJpZXMgdG8gdGhlIHByZWNhY2hlIGxpc3QgYW5kIGFkZCBhIHJvdXRlIHRvXG4gICAgICogcmVzcG9uZCB0byBmZXRjaCBldmVudHMuXG4gICAgICpcbiAgICAgKiBUaGlzIGlzIGEgY29udmVuaWVuY2UgbWV0aG9kIHRoYXQgd2lsbCBjYWxsXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5wcmVjYWNoZX0gYW5kXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5hZGRSb3V0ZX0gaW4gYSBzaW5nbGUgY2FsbC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7QXJyYXk8T2JqZWN0fHN0cmluZz59IGVudHJpZXMgQXJyYXkgb2YgZW50cmllcyB0byBwcmVjYWNoZS5cbiAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdIFNlZSB0aGVcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlUm91dGV9IG9wdGlvbnMuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gcHJlY2FjaGVBbmRSb3V0ZShlbnRyaWVzLCBvcHRpb25zKSB7XG4gICAgICBwcmVjYWNoZShlbnRyaWVzKTtcbiAgICAgIGFkZFJvdXRlKG9wdGlvbnMpO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IFNVQlNUUklOR19UT19GSU5EID0gJy1wcmVjYWNoZS0nO1xuICAgIC8qKlxuICAgICAqIENsZWFucyB1cCBpbmNvbXBhdGlibGUgcHJlY2FjaGVzIHRoYXQgd2VyZSBjcmVhdGVkIGJ5IG9sZGVyIHZlcnNpb25zIG9mXG4gICAgICogV29ya2JveCwgYnkgYSBzZXJ2aWNlIHdvcmtlciByZWdpc3RlcmVkIHVuZGVyIHRoZSBjdXJyZW50IHNjb3BlLlxuICAgICAqXG4gICAgICogVGhpcyBpcyBtZWFudCB0byBiZSBjYWxsZWQgYXMgcGFydCBvZiB0aGUgYGFjdGl2YXRlYCBldmVudC5cbiAgICAgKlxuICAgICAqIFRoaXMgc2hvdWxkIGJlIHNhZmUgdG8gdXNlIGFzIGxvbmcgYXMgeW91IGRvbid0IGluY2x1ZGUgYHN1YnN0cmluZ1RvRmluZGBcbiAgICAgKiAoZGVmYXVsdGluZyB0byBgLXByZWNhY2hlLWApIGluIHlvdXIgbm9uLXByZWNhY2hlIGNhY2hlIG5hbWVzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGN1cnJlbnRQcmVjYWNoZU5hbWUgVGhlIGNhY2hlIG5hbWUgY3VycmVudGx5IGluIHVzZSBmb3JcbiAgICAgKiBwcmVjYWNoaW5nLiBUaGlzIGNhY2hlIHdvbid0IGJlIGRlbGV0ZWQuXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IFtzdWJzdHJpbmdUb0ZpbmQ9Jy1wcmVjYWNoZS0nXSBDYWNoZSBuYW1lcyB3aGljaCBpbmNsdWRlIHRoaXNcbiAgICAgKiBzdWJzdHJpbmcgd2lsbCBiZSBkZWxldGVkIChleGNsdWRpbmcgYGN1cnJlbnRQcmVjYWNoZU5hbWVgKS5cbiAgICAgKiBAcmV0dXJuIHtBcnJheTxzdHJpbmc+fSBBIGxpc3Qgb2YgYWxsIHRoZSBjYWNoZSBuYW1lcyB0aGF0IHdlcmUgZGVsZXRlZC5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGNvbnN0IGRlbGV0ZU91dGRhdGVkQ2FjaGVzID0gYXN5bmMgKGN1cnJlbnRQcmVjYWNoZU5hbWUsIHN1YnN0cmluZ1RvRmluZCA9IFNVQlNUUklOR19UT19GSU5EKSA9PiB7XG4gICAgICBjb25zdCBjYWNoZU5hbWVzID0gYXdhaXQgc2VsZi5jYWNoZXMua2V5cygpO1xuICAgICAgY29uc3QgY2FjaGVOYW1lc1RvRGVsZXRlID0gY2FjaGVOYW1lcy5maWx0ZXIoY2FjaGVOYW1lID0+IHtcbiAgICAgICAgcmV0dXJuIGNhY2hlTmFtZS5pbmNsdWRlcyhzdWJzdHJpbmdUb0ZpbmQpICYmIGNhY2hlTmFtZS5pbmNsdWRlcyhzZWxmLnJlZ2lzdHJhdGlvbi5zY29wZSkgJiYgY2FjaGVOYW1lICE9PSBjdXJyZW50UHJlY2FjaGVOYW1lO1xuICAgICAgfSk7XG4gICAgICBhd2FpdCBQcm9taXNlLmFsbChjYWNoZU5hbWVzVG9EZWxldGUubWFwKGNhY2hlTmFtZSA9PiBzZWxmLmNhY2hlcy5kZWxldGUoY2FjaGVOYW1lKSkpO1xuICAgICAgcmV0dXJuIGNhY2hlTmFtZXNUb0RlbGV0ZTtcbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQWRkcyBhbiBgYWN0aXZhdGVgIGV2ZW50IGxpc3RlbmVyIHdoaWNoIHdpbGwgY2xlYW4gdXAgaW5jb21wYXRpYmxlXG4gICAgICogcHJlY2FjaGVzIHRoYXQgd2VyZSBjcmVhdGVkIGJ5IG9sZGVyIHZlcnNpb25zIG9mIFdvcmtib3guXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gY2xlYW51cE91dGRhdGVkQ2FjaGVzKCkge1xuICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9NaWNyb3NvZnQvVHlwZVNjcmlwdC9pc3N1ZXMvMjgzNTcjaXNzdWVjb21tZW50LTQzNjQ4NDcwNVxuICAgICAgc2VsZi5hZGRFdmVudExpc3RlbmVyKCdhY3RpdmF0ZScsIGV2ZW50ID0+IHtcbiAgICAgICAgY29uc3QgY2FjaGVOYW1lID0gY2FjaGVOYW1lcy5nZXRQcmVjYWNoZU5hbWUoKTtcbiAgICAgICAgZXZlbnQud2FpdFVudGlsKGRlbGV0ZU91dGRhdGVkQ2FjaGVzKGNhY2hlTmFtZSkudGhlbihjYWNoZXNEZWxldGVkID0+IHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZiAoY2FjaGVzRGVsZXRlZC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgIGxvZ2dlci5sb2coYFRoZSBmb2xsb3dpbmcgb3V0LW9mLWRhdGUgcHJlY2FjaGVzIHdlcmUgY2xlYW5lZCB1cCBgICsgYGF1dG9tYXRpY2FsbHk6YCwgY2FjaGVzRGVsZXRlZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBOYXZpZ2F0aW9uUm91dGUgbWFrZXMgaXQgZWFzeSB0byBjcmVhdGUgYVxuICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmcuUm91dGV9IHRoYXQgbWF0Y2hlcyBmb3IgYnJvd3NlclxuICAgICAqIFtuYXZpZ2F0aW9uIHJlcXVlc3RzXXtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvZnVuZGFtZW50YWxzL3ByaW1lcnMvc2VydmljZS13b3JrZXJzL2hpZ2gtcGVyZm9ybWFuY2UtbG9hZGluZyNmaXJzdF93aGF0X2FyZV9uYXZpZ2F0aW9uX3JlcXVlc3RzfS5cbiAgICAgKlxuICAgICAqIEl0IHdpbGwgb25seSBtYXRjaCBpbmNvbWluZyBSZXF1ZXN0cyB3aG9zZVxuICAgICAqIHtAbGluayBodHRwczovL2ZldGNoLnNwZWMud2hhdHdnLm9yZy8jY29uY2VwdC1yZXF1ZXN0LW1vZGV8bW9kZX1cbiAgICAgKiBpcyBzZXQgdG8gYG5hdmlnYXRlYC5cbiAgICAgKlxuICAgICAqIFlvdSBjYW4gb3B0aW9uYWxseSBvbmx5IGFwcGx5IHRoaXMgcm91dGUgdG8gYSBzdWJzZXQgb2YgbmF2aWdhdGlvbiByZXF1ZXN0c1xuICAgICAqIGJ5IHVzaW5nIG9uZSBvciBib3RoIG9mIHRoZSBgZGVueWxpc3RgIGFuZCBgYWxsb3dsaXN0YCBwYXJhbWV0ZXJzLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcm91dGluZ1xuICAgICAqIEBleHRlbmRzIHdvcmtib3gtcm91dGluZy5Sb3V0ZVxuICAgICAqL1xuICAgIGNsYXNzIE5hdmlnYXRpb25Sb3V0ZSBleHRlbmRzIFJvdXRlIHtcbiAgICAgIC8qKlxuICAgICAgICogSWYgYm90aCBgZGVueWxpc3RgIGFuZCBgYWxsb3dsaXN0YCBhcmUgcHJvdmlkZWQsIHRoZSBgZGVueWxpc3RgIHdpbGxcbiAgICAgICAqIHRha2UgcHJlY2VkZW5jZSBhbmQgdGhlIHJlcXVlc3Qgd2lsbCBub3QgbWF0Y2ggdGhpcyByb3V0ZS5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgcmVndWxhciBleHByZXNzaW9ucyBpbiBgYWxsb3dsaXN0YCBhbmQgYGRlbnlsaXN0YFxuICAgICAgICogYXJlIG1hdGNoZWQgYWdhaW5zdCB0aGUgY29uY2F0ZW5hdGVkXG4gICAgICAgKiBbYHBhdGhuYW1lYF17QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0hUTUxIeXBlcmxpbmtFbGVtZW50VXRpbHMvcGF0aG5hbWV9XG4gICAgICAgKiBhbmQgW2BzZWFyY2hgXXtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvSFRNTEh5cGVybGlua0VsZW1lbnRVdGlscy9zZWFyY2h9XG4gICAgICAgKiBwb3J0aW9ucyBvZiB0aGUgcmVxdWVzdGVkIFVSTC5cbiAgICAgICAqXG4gICAgICAgKiAqTm90ZSo6IFRoZXNlIFJlZ0V4cHMgbWF5IGJlIGV2YWx1YXRlZCBhZ2FpbnN0IGV2ZXJ5IGRlc3RpbmF0aW9uIFVSTCBkdXJpbmdcbiAgICAgICAqIGEgbmF2aWdhdGlvbi4gQXZvaWQgdXNpbmdcbiAgICAgICAqIFtjb21wbGV4IFJlZ0V4cHNdKGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMzA3NyksXG4gICAgICAgKiBvciBlbHNlIHlvdXIgdXNlcnMgbWF5IHNlZSBkZWxheXMgd2hlbiBuYXZpZ2F0aW5nIHlvdXIgc2l0ZS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IGhhbmRsZXIgQSBjYWxsYmFja1xuICAgICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXN1bHRpbmcgaW4gYSBSZXNwb25zZS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PFJlZ0V4cD59IFtvcHRpb25zLmRlbnlsaXN0XSBJZiBhbnkgb2YgdGhlc2UgcGF0dGVybnMgbWF0Y2gsXG4gICAgICAgKiB0aGUgcm91dGUgd2lsbCBub3QgaGFuZGxlIHRoZSByZXF1ZXN0IChldmVuIGlmIGEgYWxsb3dsaXN0IFJlZ0V4cCBtYXRjaGVzKS5cbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8UmVnRXhwPn0gW29wdGlvbnMuYWxsb3dsaXN0PVsvLi9dXSBJZiBhbnkgb2YgdGhlc2UgcGF0dGVybnNcbiAgICAgICAqIG1hdGNoIHRoZSBVUkwncyBwYXRobmFtZSBhbmQgc2VhcmNoIHBhcmFtZXRlciwgdGhlIHJvdXRlIHdpbGwgaGFuZGxlIHRoZVxuICAgICAgICogcmVxdWVzdCAoYXNzdW1pbmcgdGhlIGRlbnlsaXN0IGRvZXNuJ3QgbWF0Y2gpLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihoYW5kbGVyLCB7XG4gICAgICAgIGFsbG93bGlzdCA9IFsvLi9dLFxuICAgICAgICBkZW55bGlzdCA9IFtdXG4gICAgICB9ID0ge30pIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0FycmF5T2ZDbGFzcyhhbGxvd2xpc3QsIFJlZ0V4cCwge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdOYXZpZ2F0aW9uUm91dGUnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdvcHRpb25zLmFsbG93bGlzdCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNBcnJheU9mQ2xhc3MoZGVueWxpc3QsIFJlZ0V4cCwge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdOYXZpZ2F0aW9uUm91dGUnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdvcHRpb25zLmRlbnlsaXN0J1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHN1cGVyKG9wdGlvbnMgPT4gdGhpcy5fbWF0Y2gob3B0aW9ucyksIGhhbmRsZXIpO1xuICAgICAgICB0aGlzLl9hbGxvd2xpc3QgPSBhbGxvd2xpc3Q7XG4gICAgICAgIHRoaXMuX2RlbnlsaXN0ID0gZGVueWxpc3Q7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJvdXRlcyBtYXRjaCBoYW5kbGVyLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgKiBAcGFyYW0ge1VSTH0gb3B0aW9ucy51cmxcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gb3B0aW9ucy5yZXF1ZXN0XG4gICAgICAgKiBAcmV0dXJuIHtib29sZWFufVxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF9tYXRjaCh7XG4gICAgICAgIHVybCxcbiAgICAgICAgcmVxdWVzdFxuICAgICAgfSkge1xuICAgICAgICBpZiAocmVxdWVzdCAmJiByZXF1ZXN0Lm1vZGUgIT09ICduYXZpZ2F0ZScpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGF0aG5hbWVBbmRTZWFyY2ggPSB1cmwucGF0aG5hbWUgKyB1cmwuc2VhcmNoO1xuICAgICAgICBmb3IgKGNvbnN0IHJlZ0V4cCBvZiB0aGlzLl9kZW55bGlzdCkge1xuICAgICAgICAgIGlmIChyZWdFeHAudGVzdChwYXRobmFtZUFuZFNlYXJjaCkpIHtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmxvZyhgVGhlIG5hdmlnYXRpb24gcm91dGUgJHtwYXRobmFtZUFuZFNlYXJjaH0gaXMgbm90IGAgKyBgYmVpbmcgdXNlZCwgc2luY2UgdGhlIFVSTCBtYXRjaGVzIHRoaXMgZGVueWxpc3QgcGF0dGVybjogYCArIGAke3JlZ0V4cC50b1N0cmluZygpfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5fYWxsb3dsaXN0LnNvbWUocmVnRXhwID0+IHJlZ0V4cC50ZXN0KHBhdGhuYW1lQW5kU2VhcmNoKSkpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYFRoZSBuYXZpZ2F0aW9uIHJvdXRlICR7cGF0aG5hbWVBbmRTZWFyY2h9IGAgKyBgaXMgYmVpbmcgdXNlZC5gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIGxvZ2dlci5sb2coYFRoZSBuYXZpZ2F0aW9uIHJvdXRlICR7cGF0aG5hbWVBbmRTZWFyY2h9IGlzIG5vdCBgICsgYGJlaW5nIHVzZWQsIHNpbmNlIHRoZSBVUkwgYmVpbmcgbmF2aWdhdGVkIHRvIGRvZXNuJ3QgYCArIGBtYXRjaCB0aGUgYWxsb3dsaXN0LmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBIZWxwZXIgZnVuY3Rpb24gdGhhdCBjYWxsc1xuICAgICAqIHtAbGluayBQcmVjYWNoZUNvbnRyb2xsZXIjY3JlYXRlSGFuZGxlckJvdW5kVG9VUkx9IG9uIHRoZSBkZWZhdWx0XG4gICAgICoge0BsaW5rIFByZWNhY2hlQ29udHJvbGxlcn0gaW5zdGFuY2UuXG4gICAgICpcbiAgICAgKiBJZiB5b3UgYXJlIGNyZWF0aW5nIHlvdXIgb3duIHtAbGluayBQcmVjYWNoZUNvbnRyb2xsZXJ9LCB0aGVuIGNhbGwgdGhlXG4gICAgICoge0BsaW5rIFByZWNhY2hlQ29udHJvbGxlciNjcmVhdGVIYW5kbGVyQm91bmRUb1VSTH0gb24gdGhhdCBpbnN0YW5jZSxcbiAgICAgKiBpbnN0ZWFkIG9mIHVzaW5nIHRoaXMgZnVuY3Rpb24uXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsIFRoZSBwcmVjYWNoZWQgVVJMIHdoaWNoIHdpbGwgYmUgdXNlZCB0byBsb29rdXAgdGhlXG4gICAgICogYFJlc3BvbnNlYC5cbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IFtmYWxsYmFja1RvTmV0d29yaz10cnVlXSBXaGV0aGVyIHRvIGF0dGVtcHQgdG8gZ2V0IHRoZVxuICAgICAqIHJlc3BvbnNlIGZyb20gdGhlIG5ldHdvcmsgaWYgdGhlcmUncyBhIHByZWNhY2hlIG1pc3MuXG4gICAgICogQHJldHVybiB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja31cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjcmVhdGVIYW5kbGVyQm91bmRUb1VSTCh1cmwpIHtcbiAgICAgIGNvbnN0IHByZWNhY2hlQ29udHJvbGxlciA9IGdldE9yQ3JlYXRlUHJlY2FjaGVDb250cm9sbGVyKCk7XG4gICAgICByZXR1cm4gcHJlY2FjaGVDb250cm9sbGVyLmNyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMKHVybCk7XG4gICAgfVxuXG4gICAgZXhwb3J0cy5OYXZpZ2F0aW9uUm91dGUgPSBOYXZpZ2F0aW9uUm91dGU7XG4gICAgZXhwb3J0cy5jbGVhbnVwT3V0ZGF0ZWRDYWNoZXMgPSBjbGVhbnVwT3V0ZGF0ZWRDYWNoZXM7XG4gICAgZXhwb3J0cy5jbGllbnRzQ2xhaW0gPSBjbGllbnRzQ2xhaW07XG4gICAgZXhwb3J0cy5jcmVhdGVIYW5kbGVyQm91bmRUb1VSTCA9IGNyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMO1xuICAgIGV4cG9ydHMucHJlY2FjaGVBbmRSb3V0ZSA9IHByZWNhY2hlQW5kUm91dGU7XG4gICAgZXhwb3J0cy5yZWdpc3RlclJvdXRlID0gcmVnaXN0ZXJSb3V0ZTtcblxufSkpO1xuIl19